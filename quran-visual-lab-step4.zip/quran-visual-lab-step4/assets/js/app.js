const form = document.getElementById('qvl-form');
const surahSelect = document.getElementById('surahSelect');
const ayahInput = document.getElementById('ayahNumber');
const surahHelp = document.getElementById('surahHelp');
const feedbackBox = document.getElementById('feedbackBox');
const resultPlaceholder = document.getElementById('resultPlaceholder');
const resultCard = document.getElementById('resultCard');
const surahBadge = document.getElementById('surahBadge');
const ayahBadge = document.getElementById('ayahBadge');
const revelationBadge = document.getElementById('revelationBadge');
const sourceBadge = document.getElementById('sourceBadge');
const surahTitle = document.getElementById('surahTitle');
const surahSubtitle = document.getElementById('surahSubtitle');
const ayahArabic = document.getElementById('ayahArabic');
const ayahTranslation = document.getElementById('ayahTranslation');
const generatePromptBtn = document.getElementById('generatePromptBtn');
const copyPromptBtn = document.getElementById('copyPromptBtn');
const copyAyahBtn = document.getElementById('copyAyahBtn');
const exportTxtBtn = document.getElementById('exportTxtBtn');
const promptOutput = document.getElementById('promptOutput');
const themeSelect = document.getElementById('themeSelect');
const formatSelect = document.getElementById('formatSelect');
const toneSelect = document.getElementById('toneSelect');

const visualFormatSelect = document.getElementById('visualFormatSelect');
const visualThemeSelect = document.getElementById('visualThemeSelect');
const visualOrnamentSelect = document.getElementById('visualOrnamentSelect');
const signatureInput = document.getElementById('signatureInput');
const showReferenceCheck = document.getElementById('showReferenceCheck');
const showTranslationCheck = document.getElementById('showTranslationCheck');
const showBrandCheck = document.getElementById('showBrandCheck');
const createVisualBtn = document.getElementById('createVisualBtn');
const exportSvgBtn = document.getElementById('exportSvgBtn');
const exportPngBtn = document.getElementById('exportPngBtn');
const copyCaptionBtn = document.getElementById('copyCaptionBtn');
const visualMeta = document.getElementById('visualMeta');
const visualPlaceholder = document.getElementById('visualPlaceholder');
const visualStage = document.getElementById('visualStage');
const visualPreview = document.getElementById('visualPreview');
const svgSourceOutput = document.getElementById('svgSourceOutput');

const audioEditionSelect = document.getElementById('audioEditionSelect');
const audioBitrateSelect = document.getElementById('audioBitrateSelect');
const memoryLevelSelect = document.getElementById('memoryLevelSelect');
const noteInput = document.getElementById('noteInput');
const buildLearningBtn = document.getElementById('buildLearningBtn');
const toggleFavoriteBtn = document.getElementById('toggleFavoriteBtn');
const saveLearningBtn = document.getElementById('saveLearningBtn');
const learningMeta = document.getElementById('learningMeta');
const learningPlaceholder = document.getElementById('learningPlaceholder');
const learningStage = document.getElementById('learningStage');
const learningReference = document.getElementById('learningReference');
const learningAudioMeta = document.getElementById('learningAudioMeta');
const learningAudio = document.getElementById('learningAudio');
const favoriteBadge = document.getElementById('favoriteBadge');
const progressBadge = document.getElementById('progressBadge');
const repetitionSteps = document.getElementById('repetitionSteps');
const maskedAyahText = document.getElementById('maskedAyahText');
const revealMaskBtn = document.getElementById('revealMaskBtn');
const copyMaskedBtn = document.getElementById('copyMaskedBtn');
const maskHint = document.getElementById('maskHint');
const quizContainer = document.getElementById('quizContainer');
const checkQuizBtn = document.getElementById('checkQuizBtn');
const quizResultBox = document.getElementById('quizResultBox');

let surahCatalog = [];
let currentAyah = null;
let visualCatalog = { themes: [], formats: {} };
let currentVisualConfig = null;
let currentSvgMarkup = '';
let learningCatalog = { audio_editions: [], presets: {}, default: { edition: 'ar.alafasy', bitrate: 128 } };
let currentLearning = null;
let learningState = { favorites: {}, notes: {}, progress: {} };

function showFeedback(message, type = 'success') {
  feedbackBox.textContent = message;
  feedbackBox.className = `alert alert-${type} mt-3 mb-0`;
  feedbackBox.classList.remove('d-none');
}

function hideFeedback() {
  feedbackBox.classList.add('d-none');
}

function getAyahKey() {
  return currentAyah ? `${currentAyah.surah.number}:${currentAyah.ayah.number}` : '';
}

function getSessionId() {
  let sessionId = localStorage.getItem('qvl_session_id');
  if (!sessionId) {
    sessionId = `qvl-${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem('qvl_session_id', sessionId);
  }
  return sessionId;
}

function loadLearningState() {
  try {
    learningState = JSON.parse(localStorage.getItem('qvl_learning_state') || '{}');
  } catch {
    learningState = {};
  }
  learningState.favorites = learningState.favorites || {};
  learningState.notes = learningState.notes || {};
  learningState.progress = learningState.progress || {};
}

function persistLearningState() {
  localStorage.setItem('qvl_learning_state', JSON.stringify(learningState));
}

function resetResult() {
  currentAyah = null;
  resultCard.classList.add('d-none');
  resultPlaceholder.classList.remove('d-none');
  generatePromptBtn.disabled = true;
  copyPromptBtn.disabled = true;
  copyAyahBtn.disabled = true;
  exportTxtBtn.disabled = true;
  resetVisual();
  resetLearning();
}

function resetVisual() {
  currentVisualConfig = null;
  currentSvgMarkup = '';
  visualMeta.innerHTML = '';
  svgSourceOutput.value = '';
  visualPreview.innerHTML = '';
  visualStage.classList.add('d-none');
  visualPlaceholder.classList.remove('d-none');
  createVisualBtn.disabled = !currentAyah;
  exportSvgBtn.disabled = true;
  exportPngBtn.disabled = true;
  copyCaptionBtn.disabled = true;
}

function resetLearning() {
  currentLearning = null;
  learningMeta.innerHTML = '';
  learningReference.textContent = '';
  learningAudioMeta.textContent = '';
  learningAudio.removeAttribute('src');
  learningAudio.load();
  repetitionSteps.innerHTML = '';
  maskedAyahText.textContent = '';
  maskHint.textContent = '';
  quizContainer.innerHTML = '';
  quizResultBox.classList.add('d-none');
  quizResultBox.textContent = '';
  learningStage.classList.add('d-none');
  learningPlaceholder.classList.remove('d-none');
  buildLearningBtn.disabled = !currentAyah;
  toggleFavoriteBtn.disabled = !currentAyah;
  saveLearningBtn.disabled = !currentAyah;
  revealMaskBtn.disabled = true;
  copyMaskedBtn.disabled = true;
  checkQuizBtn.disabled = true;
}

function getSelectedSurahMeta() {
  const surahNumber = Number(surahSelect.value || 0);
  return surahCatalog.find(item => Number(item.number) === surahNumber) || null;
}

function updateAyahLimit() {
  const meta = getSelectedSurahMeta();

  if (!meta) {
    surahHelp.textContent = 'Choisissez une sourate pour afficher le nombre maximal de versets.';
    ayahInput.removeAttribute('max');
    return;
  }

  ayahInput.max = meta.ayah_count;
  ayahInput.placeholder = `Entre 1 et ${meta.ayah_count}`;
  surahHelp.textContent = `${meta.name_fr} · ${meta.name_ar} · ${meta.ayah_count} versets · ${meta.revelation_type}`;

  if (ayahInput.value && Number(ayahInput.value) > Number(meta.ayah_count)) {
    ayahInput.value = meta.ayah_count;
  }
}

function populateSurahs(list) {
  surahSelect.innerHTML = '<option value="">Sélectionner une sourate</option>';
  list.forEach(item => {
    const option = document.createElement('option');
    option.value = item.number;
    option.textContent = `${item.number}. ${item.name_fr} · ${item.name_ar}`;
    surahSelect.appendChild(option);
  });
}

function populateVisualThemes(themes) {
  visualThemeSelect.innerHTML = '';
  themes.forEach((theme, index) => {
    const option = document.createElement('option');
    option.value = theme.code;
    option.textContent = theme.label;
    if (index === 0) option.selected = true;
    visualThemeSelect.appendChild(option);
  });
}

function populateAudioEditions(editions) {
  audioEditionSelect.innerHTML = '';
  editions.forEach(edition => {
    const option = document.createElement('option');
    option.value = edition.code;
    option.textContent = edition.label;
    if (edition.default) option.selected = true;
    audioEditionSelect.appendChild(option);
  });
}

function updateBitrateOptions() {
  const selected = learningCatalog.audio_editions.find(item => item.code === audioEditionSelect.value) || learningCatalog.audio_editions[0];
  const bitrates = selected?.bitrate_options || [128, 64];
  const current = Number(audioBitrateSelect.value || 0);
  audioBitrateSelect.innerHTML = '';
  bitrates.forEach(rate => {
    const option = document.createElement('option');
    option.value = rate;
    option.textContent = `${rate} kbps`;
    if (rate === current || (!current && rate === (learningCatalog.default?.bitrate || 128))) option.selected = true;
    audioBitrateSelect.appendChild(option);
  });
}

async function loadSurahs() {
  const response = await fetch('data/surahs.json', { headers: { Accept: 'application/json' } });
  const data = await response.json();
  if (!response.ok || !Array.isArray(data)) {
    throw new Error('Impossible de charger la liste des sourates.');
  }
  surahCatalog = data;
  populateSurahs(data);
}

async function loadVisualCatalog() {
  const response = await fetch('api/visual.php', { headers: { Accept: 'application/json' } });
  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de charger le catalogue visuel.');
  }

  visualCatalog = {
    themes: Array.isArray(data.themes) ? data.themes : [],
    formats: typeof data.formats === 'object' && data.formats !== null ? data.formats : {}
  };

  populateVisualThemes(visualCatalog.themes);
}

async function loadLearningCatalog() {
  const response = await fetch('api/learning.php', { headers: { Accept: 'application/json' } });
  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de charger le catalogue Learning.');
  }

  learningCatalog = data;
  populateAudioEditions(Array.isArray(data.audio_editions) ? data.audio_editions : []);
  updateBitrateOptions();
}

function validateInput(surah, ayah) {
  if (!surah || !ayah) {
    return 'Veuillez choisir une sourate et saisir un numéro de verset.';
  }

  const meta = surahCatalog.find(item => Number(item.number) === Number(surah));
  if (!meta) {
    return 'La sourate choisie est invalide.';
  }

  if (Number(ayah) < 1 || Number(ayah) > Number(meta.ayah_count)) {
    return `Le verset doit être compris entre 1 et ${meta.ayah_count} pour cette sourate.`;
  }

  return '';
}

async function fetchAyah(surah, ayah) {
  const url = `api/ayah.php?surah=${encodeURIComponent(surah)}&ayah=${encodeURIComponent(ayah)}`;
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de récupérer ce verset.');
  }

  return data;
}

async function generatePromptFromApi() {
  if (!currentAyah) {
    throw new Error('Aucun verset n’est chargé pour le moment.');
  }

  const payload = {
    template_code: 'prompt_master_visual',
    surah_name: currentAyah.surah.name_fr,
    surah_name_ar: currentAyah.surah.name_ar,
    ayah_number: currentAyah.ayah.number,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr || '',
    theme: themeSelect.value,
    output_format: formatSelect.value,
    tone: toneSelect.value
  };

  const response = await fetch('api/prompt.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de générer le prompt.');
  }

  return data.prompt;
}

async function buildVisualConfig() {
  if (!currentAyah) {
    throw new Error('Chargez d’abord un verset.');
  }

  const payload = {
    surah: currentAyah.surah.number,
    ayah: currentAyah.ayah.number,
    surah_name: currentAyah.surah.name_fr,
    surah_name_ar: currentAyah.surah.name_ar,
    revelation_type: currentAyah.surah.revelation_type,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr || '',
    format: visualFormatSelect.value,
    theme: visualThemeSelect.value,
    ornament: visualOrnamentSelect.value,
    signature: signatureInput.value.trim(),
    show_reference: showReferenceCheck.checked,
    show_translation: showTranslationCheck.checked,
    show_brand: showBrandCheck.checked
  };

  const response = await fetch('api/visual.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de construire le visuel.');
  }

  return data.visual_config;
}

async function buildLearningModule() {
  if (!currentAyah) {
    throw new Error('Chargez d’abord un verset.');
  }

  const payload = {
    surah: currentAyah.surah.number,
    ayah: currentAyah.ayah.number,
    surah_name: currentAyah.surah.name_fr,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr || '',
    global_ayah_number: currentAyah.ayah.global_number,
    ayah_count: currentAyah.surah.ayah_count,
    revelation_type: currentAyah.surah.revelation_type,
    edition: audioEditionSelect.value,
    bitrate: Number(audioBitrateSelect.value || 128)
  };

  const response = await fetch('api/learning.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de construire le module Learning.');
  }

  return data.learning;
}

async function saveLearningProgressRemote() {
  const key = getAyahKey();
  if (!key || !currentAyah) {
    throw new Error('Aucun verset chargé.');
  }

  const progress = {
    ayah_key: key,
    favorite: Boolean(learningState.favorites[key]),
    note: learningState.notes[key] || '',
    memory_level: Number(learningState.progress[key] || 0),
    reference: `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`
  };

  const response = await fetch('api/learning.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({
      action: 'save_progress',
      session_id: getSessionId(),
      progress
    })
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Enregistrement distant impossible.');
  }

  return data;
}

function renderAyah(data) {
  surahBadge.textContent = `Sourate ${data.surah.number}`;
  ayahBadge.textContent = `Verset ${data.ayah.number}`;
  revelationBadge.textContent = data.surah.revelation_type || 'Révélation non précisée';
  sourceBadge.textContent = data.meta?.source_label || 'Source non précisée';
  surahTitle.textContent = `${data.surah.name_fr} · ${data.surah.name_ar}`;
  surahSubtitle.textContent = `${data.surah.name_en} · ${data.surah.ayah_count} versets`;
  ayahArabic.textContent = data.ayah.text_ar;
  ayahTranslation.textContent = data.ayah.translation_fr || 'Traduction non renseignée.';

  resultPlaceholder.classList.add('d-none');
  resultCard.classList.remove('d-none');
  generatePromptBtn.disabled = false;
  copyAyahBtn.disabled = false;
  exportTxtBtn.disabled = false;
  createVisualBtn.disabled = false;
  buildLearningBtn.disabled = false;
  toggleFavoriteBtn.disabled = false;
  saveLearningBtn.disabled = false;
}

function getAyahPlainText() {
  if (!currentAyah) {
    return '';
  }

  return [
    `${currentAyah.surah.name_fr} (${currentAyah.surah.name_ar})`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    '',
    currentAyah.ayah.text_ar,
    '',
    currentAyah.ayah.translation_fr || 'Traduction non renseignée.'
  ].join('\n');
}

function exportCurrentTxt() {
  if (!currentAyah) {
    return;
  }

  const lines = [
    'Quran-Visual-Lab · Export texte',
    `${currentAyah.surah.name_fr} (${currentAyah.surah.name_ar})`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    `Source : ${currentAyah.meta?.source_label || 'non précisée'}`,
    '',
    'Texte arabe :',
    currentAyah.ayah.text_ar,
    '',
    'Traduction française :',
    currentAyah.ayah.translation_fr || 'Traduction non renseignée.',
    '',
    'Prompt Maître :',
    promptOutput.value.trim() || 'Non généré'
  ];

  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  triggerDownload(blob, `qvl-s${currentAyah.surah.number}-v${currentAyah.ayah.number}.txt`);
}

function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function escapeXml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function wrapText(text, maxCharsPerLine) {
  const source = String(text || '').trim();
  if (!source) return [];

  const words = source.split(/\s+/);
  const lines = [];
  let currentLine = '';

  words.forEach(word => {
    const candidate = currentLine ? `${currentLine} ${word}` : word;
    if (candidate.length <= maxCharsPerLine || !currentLine) {
      currentLine = candidate;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  });

  if (currentLine) lines.push(currentLine);
  return lines;
}

function getFontScale(formatCode) {
  const map = {
    square: { title: 40, ref: 24, arabic: 58, translation: 26, footer: 20, lineHeightArabic: 84, lineHeightTranslation: 38 },
    story: { title: 44, ref: 26, arabic: 60, translation: 28, footer: 22, lineHeightArabic: 88, lineHeightTranslation: 40 },
    landscape: { title: 44, ref: 24, arabic: 54, translation: 24, footer: 20, lineHeightArabic: 80, lineHeightTranslation: 36 },
    a4: { title: 38, ref: 24, arabic: 52, translation: 24, footer: 20, lineHeightArabic: 76, lineHeightTranslation: 34 }
  };
  return map[formatCode] || map.square;
}

function buildOrnaments(config) {
  const { width, height } = config.format;
  const accent = config.theme.accent;
  const accentSoft = config.theme.accent_soft;
  const border = config.theme.border;

  if (config.ornament === 'minimal') {
    return `
      <rect x="24" y="24" width="${width - 48}" height="${height - 48}" rx="28" fill="none" stroke="${border}" stroke-width="2" />
    `;
  }

  if (config.ornament === 'rays') {
    return `
      <g opacity="0.22" stroke="${accentSoft}" stroke-width="2">
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.5} 0" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.28} ${height * 0.04}" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.72} ${height * 0.04}" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.16} ${height * 0.12}" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.84} ${height * 0.12}" />
      </g>
      <circle cx="${width * 0.5}" cy="${height * 0.18}" r="92" fill="none" stroke="${accent}" stroke-opacity="0.18" stroke-width="3" />
    `;
  }

  if (config.ornament === 'mihrab') {
    return `
      <path d="M ${width * 0.22} ${height * 0.26} Q ${width * 0.5} ${height * 0.04} ${width * 0.78} ${height * 0.26}" fill="none" stroke="${accent}" stroke-opacity="0.35" stroke-width="5" />
      <path d="M ${width * 0.26} ${height * 0.28} L ${width * 0.26} ${height * 0.82}" fill="none" stroke="${border}" stroke-opacity="0.3" stroke-width="2" />
      <path d="M ${width * 0.74} ${height * 0.28} L ${width * 0.74} ${height * 0.82}" fill="none" stroke="${border}" stroke-opacity="0.3" stroke-width="2" />
      <rect x="${width * 0.18}" y="${height * 0.18}" width="${width * 0.64}" height="${height * 0.66}" rx="36" fill="none" stroke="${border}" stroke-opacity="0.2" stroke-width="2" />
    `;
  }

  return `
    <g opacity="0.18">
      <circle cx="${width * 0.16}" cy="${height * 0.12}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <circle cx="${width * 0.84}" cy="${height * 0.12}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <circle cx="${width * 0.16}" cy="${height * 0.88}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <circle cx="${width * 0.84}" cy="${height * 0.88}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <path d="M ${width * 0.1} ${height * 0.5} L ${width * 0.9} ${height * 0.5}" stroke="${border}" stroke-opacity="0.12" stroke-width="2" />
      <path d="M ${width * 0.5} ${height * 0.1} L ${width * 0.5} ${height * 0.9}" stroke="${border}" stroke-opacity="0.12" stroke-width="2" />
    </g>
  `;
}

function buildSvgMarkup(config) {
  const { width, height } = config.format;
  const scale = getFontScale(config.format.code);
  const arabicMaxChars = config.format.code === 'story' ? 21 : config.format.code === 'landscape' ? 28 : 24;
  const translationMaxChars = config.format.code === 'story' ? 38 : config.format.code === 'landscape' ? 62 : 42;
  const arabicLines = wrapText(config.text_ar, arabicMaxChars).slice(0, 8);
  const translationLines = config.show_translation ? wrapText(config.translation_fr, translationMaxChars).slice(0, 7) : [];
  const arabicBlockHeight = Math.max(arabicLines.length, 1) * scale.lineHeightArabic;
  const translationBlockHeight = translationLines.length * scale.lineHeightTranslation;
  const centerY = config.format.code === 'story' ? 620 : height * 0.42;
  const arabicStartY = centerY;
  const translationStartY = arabicStartY + arabicBlockHeight + (config.show_translation ? 48 : 0);
  const footerY = height - 68;
  const arabicX = width / 2;
  const titleY = 110;
  const refY = titleY + 48;
  const ornaments = buildOrnaments(config);
  const titleText = escapeXml(`سورة ${config.surah_name_ar}`);
  const refText = escapeXml(`${config.surah_name} · ${config.reference}`);
  const footerText = escapeXml(config.signature || 'QVL');

  const arabicTspans = arabicLines.map((line, index) => {
    const dy = index === 0 ? 0 : scale.lineHeightArabic;
    return `<tspan x="${arabicX}" dy="${dy}">${escapeXml(line)}</tspan>`;
  }).join('');

  const translationTspans = translationLines.map((line, index) => {
    const dy = index === 0 ? 0 : scale.lineHeightTranslation;
    return `<tspan x="${arabicX}" dy="${dy}">${escapeXml(line)}</tspan>`;
  }).join('');

  const translationBlock = config.show_translation ? `
    <text x="${arabicX}" y="${translationStartY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.translation}" font-weight="500" fill="${config.theme.text_soft}" letter-spacing="0.2">
      ${translationTspans}
    </text>
  ` : '';

  const referenceBlock = config.show_reference ? `
    <text x="${arabicX}" y="${refY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.ref}" font-weight="700" fill="${config.theme.text_soft}" letter-spacing="0.5">${refText}</text>
  ` : '';

  const brandBlock = config.show_brand ? `
    <text x="${arabicX}" y="${footerY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.footer}" font-weight="700" fill="${config.theme.text_muted}" letter-spacing="1.2">${footerText}</text>
  ` : '';

  return `
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeXml(config.reference)}">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${config.theme.bg_start}" />
      <stop offset="100%" stop-color="${config.theme.bg_end}" />
    </linearGradient>
    <radialGradient id="haloGrad" cx="50%" cy="24%" r="48%">
      <stop offset="0%" stop-color="${config.theme.accent}" stop-opacity="0.42" />
      <stop offset="100%" stop-color="${config.theme.accent}" stop-opacity="0" />
    </radialGradient>
    <filter id="shadowSoft" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="18" flood-color="#000000" flood-opacity="0.24" />
    </filter>
  </defs>

  <rect width="100%" height="100%" rx="36" fill="url(#bgGrad)" />
  <rect x="22" y="22" width="${width - 44}" height="${height - 44}" rx="30" fill="none" stroke="${config.theme.border}" stroke-width="2" opacity="0.6" />
  <circle cx="${width / 2}" cy="${Math.max((config.format.code === 'story' ? 280 : 170) - 34, 120)}" r="${config.format.code === 'story' ? 270 : 190}" fill="url(#haloGrad)" />
  ${ornaments}

  <g filter="url(#shadowSoft)">
    <rect x="70" y="${config.format.code === 'story' ? 220 : 180}" width="${width - 140}" height="${Math.min(height * 0.52, arabicBlockHeight + translationBlockHeight + 180)}" rx="32" fill="${config.theme.panel}" fill-opacity="0.26" stroke="${config.theme.border}" stroke-opacity="0.28" />
  </g>

  <text x="${arabicX}" y="${titleY}" text-anchor="middle" font-family="Amiri, serif" font-size="${scale.title}" font-weight="700" fill="${config.theme.text_main}" letter-spacing="0.2">${titleText}</text>
  ${referenceBlock}

  <text x="${arabicX}" y="${arabicStartY}" text-anchor="middle" font-family="Amiri, serif" font-size="${scale.arabic}" font-weight="700" fill="${config.theme.text_main}" direction="rtl" unicode-bidi="plaintext">
    ${arabicTspans}
  </text>

  ${translationBlock}
  ${brandBlock}
</svg>`.trim();
}

function renderVisualMeta(config) {
  visualMeta.innerHTML = '';
  const pills = [
    config.format.label,
    config.theme.label,
    config.ornament_label,
    config.reference
  ];

  pills.forEach(text => {
    const span = document.createElement('span');
    span.className = 'visual-pill';
    span.textContent = text;
    visualMeta.appendChild(span);
  });
}

function renderVisual(config) {
  currentVisualConfig = config;
  currentSvgMarkup = buildSvgMarkup(config);
  visualPreview.innerHTML = currentSvgMarkup;
  svgSourceOutput.value = currentSvgMarkup;
  renderVisualMeta(config);
  visualPlaceholder.classList.add('d-none');
  visualStage.classList.remove('d-none');
  exportSvgBtn.disabled = false;
  exportPngBtn.disabled = false;
  copyCaptionBtn.disabled = false;
}

function exportSvg() {
  if (!currentSvgMarkup || !currentVisualConfig) return;
  const blob = new Blob([currentSvgMarkup], { type: 'image/svg+xml;charset=utf-8' });
  triggerDownload(blob, currentVisualConfig.export_base + '.svg');
}

function exportPng() {
  if (!currentSvgMarkup || !currentVisualConfig) return;

  const svgBlob = new Blob([currentSvgMarkup], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(svgBlob);
  const img = new Image();
  img.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = currentVisualConfig.format.width;
    canvas.height = currentVisualConfig.format.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    canvas.toBlob(blob => {
      if (blob) {
        triggerDownload(blob, currentVisualConfig.export_base + '.png');
      } else {
        showFeedback('Export PNG impossible sur ce navigateur.', 'danger');
      }
      URL.revokeObjectURL(url);
    }, 'image/png');
  };
  img.onerror = () => {
    URL.revokeObjectURL(url);
    showFeedback('Le visuel SVG n’a pas pu être converti en PNG.', 'danger');
  };
  img.src = url;
}

function buildCaptionText() {
  if (!currentAyah) return '';
  const parts = [
    `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar}`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    '',
    currentAyah.ayah.text_ar
  ];

  if (showTranslationCheck.checked && currentAyah.ayah.translation_fr) {
    parts.push('', currentAyah.ayah.translation_fr);
  }

  parts.push('', 'Carte générée avec Quran-Visual-Lab · QVL');
  return parts.join('\n');
}

function updateLearningWidgets() {
  const key = getAyahKey();
  const favorite = Boolean(learningState.favorites[key]);
  const level = Number(learningState.progress[key] || 0);
  const note = learningState.notes[key] || '';

  noteInput.value = note;
  memoryLevelSelect.value = String(level);
  favoriteBadge.textContent = `Favori : ${favorite ? 'oui' : 'non'}`;
  progressBadge.textContent = `Progression : ${memoryLevelSelect.options[memoryLevelSelect.selectedIndex]?.textContent || 'non commencé'}`;
  toggleFavoriteBtn.textContent = favorite ? 'Retirer des favoris' : 'Ajouter aux favoris';
}

function renderLearningMeta() {
  learningMeta.innerHTML = '';
  if (!currentAyah || !currentLearning) return;

  [
    currentLearning.reference,
    `Audio ${currentLearning.audio.edition}`,
    `${currentLearning.audio.bitrate} kbps`
  ].forEach(text => {
    const span = document.createElement('span');
    span.className = 'visual-pill';
    span.textContent = text;
    learningMeta.appendChild(span);
  });
}

function renderQuiz(quiz) {
  quizContainer.innerHTML = '';
  quiz.forEach((item, index) => {
    const card = document.createElement('div');
    card.className = 'quiz-card';
    card.dataset.questionId = item.id;
    card.dataset.answer = typeof item.answer === 'string' ? item.answer : JSON.stringify(item.answer);
    card.dataset.type = item.type;

    const title = document.createElement('p');
    title.className = 'quiz-question';
    title.textContent = `${index + 1}. ${item.question}`;
    card.appendChild(title);

    if (item.prompt) {
      const prompt = document.createElement('p');
      prompt.className = 'masked-ayah mb-3';
      prompt.textContent = item.prompt;
      card.appendChild(prompt);
    }

    if (item.type === 'mcq') {
      const wrapper = document.createElement('div');
      wrapper.className = 'quiz-options';
      (item.options || []).forEach(optionValue => {
        const label = document.createElement('label');
        label.className = 'quiz-option';
        const radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = item.id;
        radio.value = optionValue;
        label.appendChild(radio);
        const span = document.createElement('span');
        span.textContent = optionValue;
        label.appendChild(span);
        wrapper.appendChild(label);
      });
      card.appendChild(wrapper);
    } else {
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'quiz-input';
      input.name = item.id;
      input.placeholder = item.type === 'short' ? 'Votre réponse...' : 'Complétez ici...';
      card.appendChild(input);
    }

    if (item.hint) {
      const hint = document.createElement('p');
      hint.className = 'quiz-answer-note';
      hint.textContent = `Indice : ${item.hint}`;
      card.appendChild(hint);
    }

    quizContainer.appendChild(card);
  });
  checkQuizBtn.disabled = false;
}

function renderLearning(learning) {
  currentLearning = learning;
  learningReference.textContent = currentLearning.reference;
  learningAudioMeta.textContent = `Édition ${learning.audio.edition} · ${learning.audio.bitrate} kbps · Ayah global ${learning.audio.global_ayah_number}`;
  learningAudio.src = learning.audio.url;
  repetitionSteps.innerHTML = '';
  learning.repetition_steps.forEach(step => {
    const li = document.createElement('li');
    li.textContent = step;
    repetitionSteps.appendChild(li);
  });
  maskedAyahText.textContent = learning.mask_exercise.masked_text || currentAyah.ayah.text_ar;
  maskHint.textContent = learning.mask_exercise.hidden_word ? 'Le mot masqué sera révélé à la demande.' : 'Aucun masquage disponible pour ce texte.';
  renderQuiz(learning.quiz || []);
  renderLearningMeta();
  learningPlaceholder.classList.add('d-none');
  learningStage.classList.remove('d-none');
  revealMaskBtn.disabled = !(learning.mask_exercise.hidden_word);
  copyMaskedBtn.disabled = false;
  updateLearningWidgets();
}

function checkQuizAnswers() {
  if (!currentLearning) return;

  let total = 0;
  let correct = 0;

  (currentLearning.quiz || []).forEach(item => {
    total += 1;
    const card = quizContainer.querySelector(`[data-question-id="${item.id}"]`);
    if (!card) return;

    let userAnswer = '';
    if (item.type === 'mcq') {
      const selected = card.querySelector(`input[name="${item.id}"]:checked`);
      userAnswer = selected ? selected.value : '';
    } else {
      const input = card.querySelector(`input[name="${item.id}"]`);
      userAnswer = input ? input.value.trim() : '';
    }

    const expected = String(item.answer).trim().toLowerCase();
    const actual = String(userAnswer).trim().toLowerCase();
    const ok = expected !== '' && actual === expected;

    card.style.borderColor = ok ? 'rgba(74, 222, 128, 0.45)' : 'rgba(248, 113, 113, 0.45)';

    let note = card.querySelector('.quiz-eval');
    if (!note) {
      note = document.createElement('p');
      note.className = 'quiz-answer-note quiz-eval';
      card.appendChild(note);
    }
    note.textContent = ok ? 'Réponse correcte.' : `Réponse attendue : ${item.answer}`;

    if (ok) correct += 1;
  });

  quizResultBox.classList.remove('d-none');
  quizResultBox.innerHTML = `<p class="mb-1"><strong>Résultat :</strong> ${correct} / ${total}</p><p class="mb-0">Utilisez ce score pour décider si vous passez à l’étape suivante de mémorisation.</p>`;
}

function updateLearningStateFromInputs() {
  const key = getAyahKey();
  if (!key) return;
  learningState.notes[key] = noteInput.value.trim();
  learningState.progress[key] = Number(memoryLevelSelect.value || 0);
  persistLearningState();
  updateLearningWidgets();
}

async function copyToClipboard(text, successMessage) {
  try {
    await navigator.clipboard.writeText(text);
    showFeedback(successMessage, 'success');
  } catch (error) {
    showFeedback('Copie impossible dans ce navigateur.', 'danger');
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  hideFeedback();
  promptOutput.value = '';
  copyPromptBtn.disabled = true;

  const surah = surahSelect.value.trim();
  const ayah = ayahInput.value.trim();
  const validationError = validateInput(surah, ayah);

  if (validationError) {
    resetResult();
    showFeedback(validationError, 'danger');
    return;
  }

  try {
    showFeedback('Chargement du verset en cours...', 'success');
    const data = await fetchAyah(surah, ayah);
    currentAyah = data;
    renderAyah(data);
    resetVisual();
    resetLearning();
    createVisualBtn.disabled = false;
    buildLearningBtn.disabled = false;
    toggleFavoriteBtn.disabled = false;
    saveLearningBtn.disabled = false;
    updateLearningWidgets();
    showFeedback('Verset récupéré avec succès.', 'success');
  } catch (error) {
    resetResult();
    showFeedback(error.message, 'danger');
  }
});

generatePromptBtn.addEventListener('click', async () => {
  try {
    const prompt = await generatePromptFromApi();
    promptOutput.value = prompt;
    copyPromptBtn.disabled = false;
    showFeedback('Prompt Maître avancé généré.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

copyPromptBtn.addEventListener('click', async () => {
  if (!promptOutput.value.trim()) {
    showFeedback('Le champ du prompt est vide.', 'danger');
    return;
  }

  await copyToClipboard(promptOutput.value, 'Prompt copié dans le presse-papiers.');
});

copyAyahBtn.addEventListener('click', async () => {
  const text = getAyahPlainText();
  if (!text) {
    showFeedback('Aucun verset à copier.', 'danger');
    return;
  }

  await copyToClipboard(text, 'Verset copié dans le presse-papiers.');
});

exportTxtBtn.addEventListener('click', () => {
  exportCurrentTxt();
  showFeedback('Export TXT déclenché.', 'success');
});

createVisualBtn.addEventListener('click', async () => {
  try {
    showFeedback('Construction du visuel en cours...', 'success');
    const config = await buildVisualConfig();
    renderVisual(config);
    showFeedback('Visuel QVL généré avec succès.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

buildLearningBtn.addEventListener('click', async () => {
  try {
    updateLearningStateFromInputs();
    showFeedback('Préparation du module Learning...', 'success');
    const learning = await buildLearningModule();
    renderLearning(learning);
    showFeedback('Learning Lab prêt pour ce verset.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

exportSvgBtn.addEventListener('click', () => {
  exportSvg();
  showFeedback('Export SVG déclenché.', 'success');
});

exportPngBtn.addEventListener('click', () => {
  exportPng();
  showFeedback('Conversion PNG en cours...', 'success');
});

copyCaptionBtn.addEventListener('click', async () => {
  const caption = buildCaptionText();
  if (!caption) {
    showFeedback('Aucune légende à copier.', 'danger');
    return;
  }
  await copyToClipboard(caption, 'Légende copiée dans le presse-papiers.');
});

revealMaskBtn.addEventListener('click', () => {
  if (!currentLearning?.mask_exercise?.hidden_word) return;
  maskedAyahText.textContent = currentAyah?.ayah?.text_ar || currentLearning.mask_exercise.masked_text;
  maskHint.textContent = `Mot révélé : ${currentLearning.mask_exercise.hidden_word}`;
});

copyMaskedBtn.addEventListener('click', async () => {
  const text = maskedAyahText.textContent.trim();
  if (!text) {
    showFeedback('Aucun exercice à copier.', 'danger');
    return;
  }
  await copyToClipboard(text, 'Exercice copié dans le presse-papiers.');
});

checkQuizBtn.addEventListener('click', () => {
  checkQuizAnswers();
  showFeedback('Quiz corrigé.', 'success');
});

surahSelect.addEventListener('change', updateAyahLimit);
audioEditionSelect.addEventListener('change', updateBitrateOptions);
memoryLevelSelect.addEventListener('change', updateLearningStateFromInputs);
noteInput.addEventListener('input', updateLearningStateFromInputs);

[visualFormatSelect, visualThemeSelect, visualOrnamentSelect, signatureInput, showReferenceCheck, showTranslationCheck, showBrandCheck].forEach(element => {
  element.addEventListener('change', () => {
    if (currentAyah && currentVisualConfig) {
      createVisualBtn.click();
    }
  });
});

toggleFavoriteBtn.addEventListener('click', () => {
  const key = getAyahKey();
  if (!key) return;
  learningState.favorites[key] = !learningState.favorites[key];
  persistLearningState();
  updateLearningWidgets();
  showFeedback(learningState.favorites[key] ? 'Verset ajouté aux favoris.' : 'Verset retiré des favoris.', 'success');
});

saveLearningBtn.addEventListener('click', async () => {
  try {
    updateLearningStateFromInputs();
    const result = await saveLearningProgressRemote();
    showFeedback(`Progression enregistrée (${result.file}).`, 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

document.querySelectorAll('.chip-btn').forEach(button => {
  button.addEventListener('click', () => {
    surahSelect.value = button.dataset.surah;
    updateAyahLimit();
    ayahInput.value = button.dataset.ayah;
    form.requestSubmit();
  });
});

(async function init() {
  try {
    loadLearningState();
    await Promise.all([loadSurahs(), loadVisualCatalog(), loadLearningCatalog()]);
    updateAyahLimit();
    showFeedback('QVL Étape 4 prêt. Vous pouvez consulter un verset puis activer le Learning Lab.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
})();
