<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function loadJsonFile(string $path): array
{
    if (!is_file($path)) {
        return [];
    }

    $content = file_get_contents($path);
    $decoded = json_decode((string) $content, true);

    return is_array($decoded) ? $decoded : [];
}

function findSurah(array $surahs, int $surahNumber): ?array
{
    foreach ($surahs as $surah) {
        if ((int) ($surah['number'] ?? 0) === $surahNumber) {
            return $surah;
        }
    }

    return null;
}

function getGlobalAyahNumber(array $surahs, int $surahNumber, int $ayahNumber): int
{
    $total = 0;
    foreach ($surahs as $surah) {
        $number = (int) ($surah['number'] ?? 0);
        $count = (int) ($surah['ayah_count'] ?? 0);
        if ($number < $surahNumber) {
            $total += $count;
        }
    }

    return $total + $ayahNumber;
}

function buildAudioMeta(int $globalAyahNumber, int $surahNumber): array
{
    $defaultEdition = 'ar.alafasy';
    $defaultBitrate = 128;

    return [
        'default_edition' => $defaultEdition,
        'default_bitrate' => $defaultBitrate,
        'global_ayah_number' => $globalAyahNumber,
        'ayah_cdn_url' => sprintf('https://cdn.islamic.network/quran/audio/%d/%s/%d.mp3', $defaultBitrate, $defaultEdition, $globalAyahNumber),
        'surah_cdn_url' => sprintf('https://cdn.islamic.network/quran/audio-surah/%d/%s/%d.mp3', $defaultBitrate, $defaultEdition, $surahNumber),
    ];
}

function fetchRemoteJson(string $url): ?array
{
    $body = null;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'User-Agent: QVL-Step4/1.0'
            ],
        ]);
        $body = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $httpCode >= 400) {
            $body = null;
        }
    }

    if ($body === null && ini_get('allow_url_fopen')) {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 15,
                'header' => "Accept: application/json\r\nUser-Agent: QVL-Step4/1.0\r\n",
            ],
        ]);

        $body = @file_get_contents($url, false, $context);
    }

    if (!is_string($body) || trim($body) === '') {
        return null;
    }

    $decoded = json_decode($body, true);

    return is_array($decoded) ? $decoded : null;
}

function normalizeRemoteSurah(array $remoteData, array $surahMeta, array $surahs): ?array
{
    $editions = $remoteData['data'] ?? null;
    if (!is_array($editions) || count($editions) < 1) {
        return null;
    }

    $arabicEdition = null;
    $frenchEdition = null;

    foreach ($editions as $edition) {
        $identifier = (string) ($edition['edition']['identifier'] ?? '');
        if ($identifier === 'quran-uthmani') {
            $arabicEdition = $edition;
        }
        if ($identifier === 'fr.hamidullah') {
            $frenchEdition = $edition;
        }
    }

    if (!is_array($arabicEdition)) {
        $arabicEdition = $editions[0] ?? null;
    }

    if (!is_array($arabicEdition) || !is_array($arabicEdition['ayahs'] ?? null)) {
        return null;
    }

    $surahNumber = (int) ($surahMeta['number'] ?? ($arabicEdition['number'] ?? 0));
    $ayahs = [];
    foreach ($arabicEdition['ayahs'] as $index => $ayahItem) {
        $ayahNumber = (int) ($ayahItem['numberInSurah'] ?? 0);
        if ($ayahNumber < 1) {
            continue;
        }

        $translationText = '';
        if (is_array($frenchEdition['ayahs'] ?? null) && isset($frenchEdition['ayahs'][$index]['text'])) {
            $translationText = trim((string) $frenchEdition['ayahs'][$index]['text']);
        }

        $globalNumber = getGlobalAyahNumber($surahs, $surahNumber, $ayahNumber);

        $ayahs[$ayahNumber] = [
            'number' => $ayahNumber,
            'global_number' => $globalNumber,
            'text_ar' => trim((string) ($ayahItem['text'] ?? '')),
            'translation_fr' => $translationText,
            'transliteration' => '',
            'audio' => buildAudioMeta($globalNumber, $surahNumber),
        ];
    }

    if ($ayahs === []) {
        return null;
    }

    return [
        'surah' => [
            'number' => $surahNumber,
            'name_ar' => (string) ($surahMeta['name_ar'] ?? ($arabicEdition['name'] ?? '')),
            'name_fr' => (string) ($surahMeta['name_fr'] ?? ($arabicEdition['englishName'] ?? '')),
            'name_en' => (string) ($surahMeta['name_en'] ?? ($arabicEdition['englishNameTranslation'] ?? '')),
            'ayah_count' => (int) ($surahMeta['ayah_count'] ?? ($arabicEdition['numberOfAyahs'] ?? 0)),
            'revelation_type' => (string) ($surahMeta['revelation_type'] ?? ($arabicEdition['revelationType'] ?? '')),
        ],
        'ayahs' => $ayahs,
        'meta' => [
            'source' => 'remote-cache',
            'source_label' => 'API distante + cache local',
            'provider' => 'alquran.cloud',
            'fetched_at' => gmdate('c'),
        ],
    ];
}

function loadLocalFallbackAyah(string $ayahsPath, array $surahData, array $surahs, int $surah, int $ayah): ?array
{
    $ayahs = loadJsonFile($ayahsPath);
    foreach ($ayahs as $item) {
        if ((int) ($item['surah'] ?? 0) === $surah && (int) ($item['ayah'] ?? 0) === $ayah) {
            $globalNumber = getGlobalAyahNumber($surahs, $surah, $ayah);
            return [
                'success' => true,
                'surah' => [
                    'number' => (int) $surahData['number'],
                    'name_ar' => (string) $surahData['name_ar'],
                    'name_fr' => (string) $surahData['name_fr'],
                    'name_en' => (string) $surahData['name_en'],
                    'ayah_count' => (int) $surahData['ayah_count'],
                    'revelation_type' => (string) $surahData['revelation_type'],
                ],
                'ayah' => [
                    'number' => (int) $item['ayah'],
                    'global_number' => $globalNumber,
                    'text_ar' => (string) $item['text_ar'],
                    'translation_fr' => (string) ($item['translation_fr'] ?? ''),
                    'transliteration' => (string) ($item['transliteration'] ?? ''),
                    'audio' => buildAudioMeta($globalNumber, $surah),
                ],
                'meta' => [
                    'source' => 'local-fallback',
                    'source_label' => 'Jeu local de secours',
                ],
            ];
        }
    }

    return null;
}

$surah = filter_input(INPUT_GET, 'surah', FILTER_VALIDATE_INT);
$ayah = filter_input(INPUT_GET, 'ayah', FILTER_VALIDATE_INT);
$refresh = filter_input(INPUT_GET, 'refresh', FILTER_VALIDATE_BOOLEAN);

if (!$surah || !$ayah || $surah < 1 || $surah > 114 || $ayah < 1) {
    respond(422, [
        'success' => false,
        'message' => 'Les paramètres sourate et verset doivent être des entiers positifs valides.'
    ]);
}

$baseDir = dirname(__DIR__);
$surahsPath = $baseDir . '/data/surahs.json';
$ayahsPath = $baseDir . '/data/ayahs.json';
$cacheDir = $baseDir . '/cache';

if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0775, true);
}

$surahs = loadJsonFile($surahsPath);
if ($surahs === []) {
    respond(500, [
        'success' => false,
        'message' => 'Le fichier des sourates est introuvable ou invalide.'
    ]);
}

$surahData = findSurah($surahs, $surah);
if ($surahData === null) {
    respond(404, [
        'success' => false,
        'message' => 'Cette sourate est introuvable dans le catalogue local.'
    ]);
}

$maxAyah = (int) ($surahData['ayah_count'] ?? 0);
if ($ayah > $maxAyah) {
    respond(422, [
        'success' => false,
        'message' => sprintf('Le verset demandé dépasse la limite de cette sourate. Maximum autorisé : %d.', $maxAyah)
    ]);
}

$cachePath = sprintf('%s/surah_%03d.fr-hamidullah.json', $cacheDir, $surah);
$combinedSurah = null;

if (!$refresh && is_file($cachePath)) {
    $combinedSurah = loadJsonFile($cachePath);
}

if (!is_array($combinedSurah) || !isset($combinedSurah['ayahs'])) {
    $remoteUrl = sprintf('https://api.alquran.cloud/v1/surah/%d/editions/quran-uthmani,fr.hamidullah', $surah);
    $remoteJson = fetchRemoteJson($remoteUrl);
    if (is_array($remoteJson)) {
        $combinedSurah = normalizeRemoteSurah($remoteJson, $surahData, $surahs);
        if (is_array($combinedSurah)) {
            @file_put_contents($cachePath, json_encode($combinedSurah, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        }
    }
}

if (is_array($combinedSurah) && isset($combinedSurah['ayahs'][$ayah])) {
    respond(200, [
        'success' => true,
        'surah' => $combinedSurah['surah'],
        'ayah' => $combinedSurah['ayahs'][$ayah],
        'meta' => $combinedSurah['meta'] ?? [
            'source' => 'remote-cache',
            'source_label' => 'API distante + cache local',
        ],
    ]);
}

$localFallback = loadLocalFallbackAyah($ayahsPath, $surahData, $surahs, $surah, $ayah);
if ($localFallback !== null) {
    respond(200, $localFallback);
}

respond(404, [
    'success' => false,
    'message' => 'Le verset demandé est introuvable dans le cache, la source distante et le jeu local de secours.'
]);
