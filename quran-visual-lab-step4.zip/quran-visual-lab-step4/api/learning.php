<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function loadJsonFile(string $path): array
{
    if (!is_file($path)) {
        return [];
    }

    $content = file_get_contents($path);
    $decoded = json_decode((string) $content, true);
    return is_array($decoded) ? $decoded : [];
}

function buildAudioUrl(string $edition, int $bitrate, int $globalAyahNumber): string
{
    return sprintf('https://cdn.islamic.network/quran/audio/%d/%s/%d.mp3', $bitrate, $edition, $globalAyahNumber);
}

function normalizeWords(string $text): array
{
    $clean = trim(preg_replace('/\s+/u', ' ', $text));
    if ($clean === '') {
        return [];
    }

    return preg_split('/\s+/u', $clean) ?: [];
}

function buildMaskExercise(string $text): array
{
    $words = normalizeWords($text);
    if (count($words) < 3) {
        return [
            'masked_text' => $text,
            'hidden_word' => '',
            'hidden_index' => -1,
        ];
    }

    $index = max(1, (int) floor(count($words) / 2));
    $hiddenWord = $words[$index] ?? '';
    $words[$index] = '_____';

    return [
        'masked_text' => implode(' ', $words),
        'hidden_word' => $hiddenWord,
        'hidden_index' => $index,
    ];
}

function pickDecoySurahs(array $surahs, int $currentSurah, int $count = 3): array
{
    $pool = [];
    foreach ($surahs as $surah) {
        $number = (int) ($surah['number'] ?? 0);
        if ($number !== $currentSurah) {
            $pool[] = $surah;
        }
    }

    shuffle($pool);
    return array_slice($pool, 0, $count);
}

function buildQuiz(array $payload, array $surahs): array
{
    $surahNumber = (int) ($payload['surah'] ?? 0);
    $ayahNumber = (int) ($payload['ayah'] ?? 0);
    $surahName = trim((string) ($payload['surah_name'] ?? ''));
    $ayahCount = (int) ($payload['ayah_count'] ?? 0);
    $revelationType = trim((string) ($payload['revelation_type'] ?? ''));
    $translation = trim((string) ($payload['translation_fr'] ?? ''));
    $textAr = trim((string) ($payload['text_ar'] ?? ''));

    $decoys = pickDecoySurahs($surahs, $surahNumber, 3);
    $surahOptions = array_map(static fn($item) => (string) ($item['name_fr'] ?? ''), $decoys);
    $surahOptions[] = $surahName;
    shuffle($surahOptions);

    $countOptions = array_unique(array_filter([
        $ayahCount,
        max(1, $ayahCount - 5),
        $ayahCount + 5,
        max(1, $ayahCount + 12),
    ], static fn($value) => (int) $value > 0));
    $countOptions = array_slice(array_map('intval', $countOptions), 0, 4);
    while (count($countOptions) < 4) {
        $countOptions[] = end($countOptions) + 3;
    }
    shuffle($countOptions);

    $mask = buildMaskExercise($textAr);

    return [
        [
            'id' => 'surah-name',
            'type' => 'mcq',
            'question' => 'Dans quelle sourate se trouve ce verset ?',
            'options' => $surahOptions,
            'answer' => $surahName,
        ],
        [
            'id' => 'revelation-type',
            'type' => 'mcq',
            'question' => 'Type de révélation de cette sourate',
            'options' => array_values(array_unique(array_filter([$revelationType, 'Mecquoise', 'Médinoise']))),
            'answer' => $revelationType,
        ],
        [
            'id' => 'ayah-count',
            'type' => 'mcq',
            'question' => 'Combien de versets compte cette sourate ?',
            'options' => $countOptions,
            'answer' => $ayahCount,
        ],
        [
            'id' => 'masked-ayah',
            'type' => 'fill',
            'question' => 'Complétez le mot masqué dans le texte arabe.',
            'prompt' => $mask['masked_text'],
            'answer' => $mask['hidden_word'],
            'hint' => $translation !== '' ? $translation : 'Relisez le verset avant de répondre.',
        ],
        [
            'id' => 'reference',
            'type' => 'short',
            'question' => 'Rappelez la référence complète du verset.',
            'answer' => sprintf('Sourate %d · Verset %d', $surahNumber, $ayahNumber),
        ],
    ];
}

$baseDir = dirname(__DIR__);
$audioEditionsPath = $baseDir . '/data/audio_editions.json';
$presetsPath = $baseDir . '/data/learning_presets.json';
$surahsPath = $baseDir . '/data/surahs.json';
$progressDir = $baseDir . '/cache/progress';

if (!is_dir($progressDir)) {
    @mkdir($progressDir, 0775, true);
}

$audioEditions = loadJsonFile($audioEditionsPath);
$presets = loadJsonFile($presetsPath);
$surahs = loadJsonFile($surahsPath);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    respond(200, [
        'success' => true,
        'audio_editions' => $audioEditions,
        'presets' => $presets,
        'default' => [
            'edition' => 'ar.alafasy',
            'bitrate' => 128,
        ],
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, [
        'success' => false,
        'message' => 'Utilisez GET pour le catalogue ou POST pour construire le module d’apprentissage.'
    ]);
}

$payload = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($payload)) {
    respond(422, [
        'success' => false,
        'message' => 'Corps JSON invalide.'
    ]);
}

$action = trim((string) ($payload['action'] ?? 'build'));

if ($action === 'save_progress') {
    $sessionId = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($payload['session_id'] ?? 'guest'));
    $progress = $payload['progress'] ?? [];
    if (!is_array($progress)) {
        respond(422, [
            'success' => false,
            'message' => 'Le bloc de progression doit être un objet JSON.'
        ]);
    }

    $record = [
        'session_id' => $sessionId !== '' ? $sessionId : 'guest',
        'progress' => $progress,
        'updated_at' => gmdate('c'),
    ];

    $target = $progressDir . '/' . ($record['session_id']) . '.json';
    @file_put_contents($target, json_encode($record, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    respond(200, [
        'success' => true,
        'message' => 'Progression enregistrée.',
        'file' => basename($target),
    ]);
}

$surah = (int) ($payload['surah'] ?? 0);
$ayah = (int) ($payload['ayah'] ?? 0);
$surahName = trim((string) ($payload['surah_name'] ?? ''));
$textAr = trim((string) ($payload['text_ar'] ?? ''));
$translation = trim((string) ($payload['translation_fr'] ?? ''));
$globalAyahNumber = (int) ($payload['global_ayah_number'] ?? 0);
$ayahCount = (int) ($payload['ayah_count'] ?? 0);
$revelationType = trim((string) ($payload['revelation_type'] ?? ''));
$edition = trim((string) ($payload['edition'] ?? 'ar.alafasy'));
$bitrate = (int) ($payload['bitrate'] ?? 128);

if ($surah < 1 || $ayah < 1 || $globalAyahNumber < 1 || $surahName === '' || $textAr === '') {
    respond(422, [
        'success' => false,
        'message' => 'Données insuffisantes pour préparer le module Learning.'
    ]);
}

$audioUrl = buildAudioUrl($edition, $bitrate, $globalAyahNumber);
$mask = buildMaskExercise($textAr);
$quiz = buildQuiz([
    'surah' => $surah,
    'ayah' => $ayah,
    'surah_name' => $surahName,
    'ayah_count' => $ayahCount,
    'revelation_type' => $revelationType,
    'translation_fr' => $translation,
    'text_ar' => $textAr,
], $surahs);

respond(200, [
    'success' => true,
    'learning' => [
        'reference' => sprintf('Sourate %d · Verset %d', $surah, $ayah),
        'audio' => [
            'edition' => $edition,
            'bitrate' => $bitrate,
            'global_ayah_number' => $globalAyahNumber,
            'url' => $audioUrl,
        ],
        'repetition_steps' => [
            'Écoutez le verset une première fois en suivant le texte arabe.',
            'Relisez le verset à voix basse trois fois.',
            'Masquez un mot puis récitez sans regarder.',
            'Validez avec le mini quiz et enregistrez votre progression.',
        ],
        'mask_exercise' => $mask,
        'quiz' => $quiz,
    ],
]);
