const form = document.getElementById('qvl-form');
const surahSelect = document.getElementById('surahSelect');
const ayahInput = document.getElementById('ayahNumber');
const surahHelp = document.getElementById('surahHelp');
const feedbackBox = document.getElementById('feedbackBox');
const resultPlaceholder = document.getElementById('resultPlaceholder');
const resultCard = document.getElementById('resultCard');
const surahBadge = document.getElementById('surahBadge');
const ayahBadge = document.getElementById('ayahBadge');
const revelationBadge = document.getElementById('revelationBadge');
const sourceBadge = document.getElementById('sourceBadge');
const surahTitle = document.getElementById('surahTitle');
const surahSubtitle = document.getElementById('surahSubtitle');
const ayahArabic = document.getElementById('ayahArabic');
const ayahTranslation = document.getElementById('ayahTranslation');
const generatePromptBtn = document.getElementById('generatePromptBtn');
const copyPromptBtn = document.getElementById('copyPromptBtn');
const copyAyahBtn = document.getElementById('copyAyahBtn');
const exportTxtBtn = document.getElementById('exportTxtBtn');
const promptOutput = document.getElementById('promptOutput');
const themeSelect = document.getElementById('themeSelect');
const formatSelect = document.getElementById('formatSelect');
const toneSelect = document.getElementById('toneSelect');

const visualFormatSelect = document.getElementById('visualFormatSelect');
const visualThemeSelect = document.getElementById('visualThemeSelect');
const visualOrnamentSelect = document.getElementById('visualOrnamentSelect');
const signatureInput = document.getElementById('signatureInput');
const showReferenceCheck = document.getElementById('showReferenceCheck');
const showTranslationCheck = document.getElementById('showTranslationCheck');
const showBrandCheck = document.getElementById('showBrandCheck');
const createVisualBtn = document.getElementById('createVisualBtn');
const exportSvgBtn = document.getElementById('exportSvgBtn');
const exportPngBtn = document.getElementById('exportPngBtn');
const copyCaptionBtn = document.getElementById('copyCaptionBtn');
const visualMeta = document.getElementById('visualMeta');
const visualPlaceholder = document.getElementById('visualPlaceholder');
const visualStage = document.getElementById('visualStage');
const visualPreview = document.getElementById('visualPreview');
const svgSourceOutput = document.getElementById('svgSourceOutput');

const audioEditionSelect = document.getElementById('audioEditionSelect');
const audioBitrateSelect = document.getElementById('audioBitrateSelect');
const memoryLevelSelect = document.getElementById('memoryLevelSelect');
const noteInput = document.getElementById('noteInput');
const buildLearningBtn = document.getElementById('buildLearningBtn');
const toggleFavoriteBtn = document.getElementById('toggleFavoriteBtn');
const saveLearningBtn = document.getElementById('saveLearningBtn');
const learningMeta = document.getElementById('learningMeta');
const learningPlaceholder = document.getElementById('learningPlaceholder');
const learningStage = document.getElementById('learningStage');
const learningReference = document.getElementById('learningReference');
const learningAudioMeta = document.getElementById('learningAudioMeta');
const learningAudio = document.getElementById('learningAudio');
const favoriteBadge = document.getElementById('favoriteBadge');
const progressBadge = document.getElementById('progressBadge');
const repetitionSteps = document.getElementById('repetitionSteps');
const maskedAyahText = document.getElementById('maskedAyahText');
const revealMaskBtn = document.getElementById('revealMaskBtn');
const copyMaskedBtn = document.getElementById('copyMaskedBtn');
const maskHint = document.getElementById('maskHint');
const quizContainer = document.getElementById('quizContainer');
const checkQuizBtn = document.getElementById('checkQuizBtn');
const quizResultBox = document.getElementById('quizResultBox');

const statConsulted = document.getElementById('statConsulted');
const statFavorites = document.getElementById('statFavorites');
const statPrompts = document.getElementById('statPrompts');
const statVisuals = document.getElementById('statVisuals');
const statLearning = document.getElementById('statLearning');
const statStudyTime = document.getElementById('statStudyTime');
const historyList = document.getElementById('historyList');
const favoriteList = document.getElementById('favoriteList');
const serverSnapshot = document.getElementById('serverSnapshot');
const verseOfDayCard = document.getElementById('verseOfDayCard');
const seriesGrid = document.getElementById('seriesGrid');
const teacherSpace = document.getElementById('teacherSpace');
const communityStatusBadge = document.getElementById('communityStatusBadge');
const loadVerseOfDayBtn = document.getElementById('loadVerseOfDayBtn');
const copyVerseOfDayBtn = document.getElementById('copyVerseOfDayBtn');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

let surahCatalog = [];
let currentAyah = null;
let visualCatalog = { themes: [], formats: {} };
let currentVisualConfig = null;
let currentSvgMarkup = '';
let learningCatalog = { audio_editions: [], presets: {}, default: { edition: 'ar.alafasy', bitrate: 128 } };
let currentLearning = null;
let learningState = { favorites: {}, notes: {}, progress: {} };
let activityState = { history: [], metrics: { prompts: 0, visuals: 0, learning: 0, consulted: 0, study_minutes: 0 } };
let dashboardCatalog = { verse_of_day: null, series: [], teacher_space: [], snapshot: null, stats: {} };

function showFeedback(message, type = 'success') {
  feedbackBox.textContent = message;
  feedbackBox.className = `alert alert-${type} mt-3 mb-0`;
  feedbackBox.classList.remove('d-none');
}

function hideFeedback() {
  feedbackBox.classList.add('d-none');
}

function getAyahKey() {
  return currentAyah ? `${currentAyah.surah.number}:${currentAyah.ayah.number}` : '';
}

function getSessionId() {
  let sessionId = localStorage.getItem('qvl_session_id');
  if (!sessionId) {
    sessionId = `qvl-${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem('qvl_session_id', sessionId);
  }
  return sessionId;
}

function loadLearningState() {
  try {
    learningState = JSON.parse(localStorage.getItem('qvl_learning_state') || '{}');
  } catch {
    learningState = {};
  }
  learningState.favorites = learningState.favorites || {};
  learningState.notes = learningState.notes || {};
  learningState.progress = learningState.progress || {};
}

function persistLearningState() {
  localStorage.setItem('qvl_learning_state', JSON.stringify(learningState));
}

function loadActivityState() {
  try {
    activityState = JSON.parse(localStorage.getItem('qvl_activity_state') || '{}');
  } catch {
    activityState = {};
  }
  activityState.history = Array.isArray(activityState.history) ? activityState.history : [];
  activityState.metrics = activityState.metrics || {};
  activityState.metrics.prompts = Number(activityState.metrics.prompts || 0);
  activityState.metrics.visuals = Number(activityState.metrics.visuals || 0);
  activityState.metrics.learning = Number(activityState.metrics.learning || 0);
  activityState.metrics.consulted = Number(activityState.metrics.consulted || 0);
  activityState.metrics.study_minutes = Number(activityState.metrics.study_minutes || 0);
}

function persistActivityState() {
  localStorage.setItem('qvl_activity_state', JSON.stringify(activityState));
}

function resetResult() {
  currentAyah = null;
  resultCard.classList.add('d-none');
  resultPlaceholder.classList.remove('d-none');
  generatePromptBtn.disabled = true;
  copyPromptBtn.disabled = true;
  copyAyahBtn.disabled = true;
  exportTxtBtn.disabled = true;
  createVisualBtn.disabled = true;
  buildLearningBtn.disabled = true;
  toggleFavoriteBtn.disabled = true;
  saveLearningBtn.disabled = true;
}

function resetVisual() {
  currentVisualConfig = null;
  currentSvgMarkup = '';
  svgSourceOutput.value = '';
  visualMeta.innerHTML = '';
  visualStage.classList.add('d-none');
  visualPlaceholder.classList.remove('d-none');
  exportSvgBtn.disabled = true;
  exportPngBtn.disabled = true;
  copyCaptionBtn.disabled = true;
}

function resetLearning() {
  currentLearning = null;
  learningMeta.innerHTML = '';
  learningStage.classList.add('d-none');
  learningPlaceholder.classList.remove('d-none');
  learningAudio.removeAttribute('src');
  learningAudio.load();
  repetitionSteps.innerHTML = '';
  maskedAyahText.textContent = '';
  maskHint.textContent = '';
  quizContainer.innerHTML = '';
  quizResultBox.classList.add('d-none');
}

function updateAyahLimit() {
  const surahNumber = Number(surahSelect.value || 0);
  const match = surahCatalog.find(item => Number(item.number) === surahNumber);
  if (!match) {
    surahHelp.textContent = 'Choisissez une sourate pour afficher le nombre maximum de versets.';
    ayahInput.max = '';
    return;
  }

  ayahInput.max = String(match.ayah_count);
  surahHelp.textContent = `${match.name_fr} · ${match.name_ar} · ${match.ayah_count} versets · révélation ${match.revelation_type.toLowerCase()}.`;
}

function validateInput(surah, ayah) {
  const surahNumber = Number(surah);
  const ayahNumber = Number(ayah);
  if (!surahNumber || !ayahNumber) {
    return 'Veuillez renseigner une sourate et un verset.';
  }

  const match = surahCatalog.find(item => Number(item.number) === surahNumber);
  if (!match) {
    return 'Numéro de sourate invalide.';
  }

  if (ayahNumber < 1 || ayahNumber > Number(match.ayah_count)) {
    return `Le verset ${ayahNumber} n’existe pas dans la sourate ${match.name_fr}.`;
  }

  return '';
}

async function loadSurahs() {
  const response = await fetch('data/surahs.json');
  if (!response.ok) {
    throw new Error('Impossible de charger la liste des sourates.');
  }

  surahCatalog = await response.json();
  surahSelect.innerHTML = '<option value="">Choisir une sourate</option>';
  surahCatalog.forEach(surah => {
    const option = document.createElement('option');
    option.value = String(surah.number);
    option.textContent = `${surah.number}. ${surah.name_fr} · ${surah.name_ar}`;
    surahSelect.appendChild(option);
  });
}

async function loadVisualCatalog() {
  const response = await fetch('api/visual.php');
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de charger le catalogue visuel.');
  }

  visualCatalog = data;
  visualThemeSelect.innerHTML = '';
  data.themes.forEach(theme => {
    const option = document.createElement('option');
    option.value = theme.code;
    option.textContent = theme.label;
    visualThemeSelect.appendChild(option);
  });
}

async function loadLearningCatalog() {
  const response = await fetch('api/learning.php');
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de charger le catalogue audio.');
  }

  learningCatalog = data;
  audioEditionSelect.innerHTML = '';
  learningCatalog.audio_editions.forEach(item => {
    const option = document.createElement('option');
    option.value = item.code;
    option.textContent = item.label;
    audioEditionSelect.appendChild(option);
  });

  audioEditionSelect.value = learningCatalog.default.edition;
  updateBitrateOptions();
}

async function loadDashboardCatalog() {
  const response = await fetch(`api/dashboard.php?session_id=${encodeURIComponent(getSessionId())}`);
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de charger le dashboard QVL.');
  }
  dashboardCatalog = {
    verse_of_day: data.verse_of_day || null,
    series: data.series || [],
    teacher_space: data.teacher_space || [],
    snapshot: data.snapshot || null,
    stats: data.stats || {},
  };
  communityStatusBadge.textContent = data.snapshot ? 'Dashboard + snapshot serveur' : 'Dashboard local actif';
}

function updateBitrateOptions() {
  const code = audioEditionSelect.value;
  const edition = (learningCatalog.audio_editions || []).find(item => item.code === code);
  const bitrates = edition?.bitrates || [128, 64];
  const previousValue = audioBitrateSelect.value;
  audioBitrateSelect.innerHTML = '';
  bitrates.forEach(value => {
    const option = document.createElement('option');
    option.value = String(value);
    option.textContent = `${value} kbps`;
    audioBitrateSelect.appendChild(option);
  });
  audioBitrateSelect.value = bitrates.includes(Number(previousValue)) ? previousValue : String(bitrates[0]);
}

async function fetchAyah(surah, ayah) {
  const response = await fetch(`api/ayah.php?surah=${encodeURIComponent(surah)}&ayah=${encodeURIComponent(ayah)}`);
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de récupérer le verset demandé.');
  }
  return data;
}

function renderAyah(data) {
  resultPlaceholder.classList.add('d-none');
  resultCard.classList.remove('d-none');
  generatePromptBtn.disabled = false;
  copyAyahBtn.disabled = false;
  exportTxtBtn.disabled = false;
  surahBadge.textContent = `Sourate ${data.surah.number}`;
  ayahBadge.textContent = `Verset ${data.ayah.number}`;
  revelationBadge.textContent = data.surah.revelation_type;
  sourceBadge.textContent = data.source || 'local';
  surahTitle.textContent = `${data.surah.name_fr} · ${data.surah.name_ar}`;
  surahSubtitle.textContent = `${data.surah.ayah_count} versets · ${data.surah.revelation_type} · translittération : ${data.ayah.transliteration || 'non renseignée'}`;
  ayahArabic.textContent = data.ayah.text_ar;
  ayahTranslation.textContent = data.ayah.translation_fr || 'Traduction non disponible pour cette version de départ.';
}

function getAyahPlainText() {
  if (!currentAyah) return '';
  return [
    `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar}`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    '',
    currentAyah.ayah.text_ar,
    '',
    currentAyah.ayah.translation_fr || ''
  ].join('\n').trim();
}

function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function exportCurrentTxt() {
  if (!currentAyah) return;
  const content = getAyahPlainText();
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const fileName = `qvl-${currentAyah.surah.number}-${currentAyah.ayah.number}.txt`;
  triggerDownload(blob, fileName);
}

async function generatePromptFromApi() {
  if (!currentAyah) {
    throw new Error('Chargez d’abord un verset.');
  }

  const payload = {
    surah: currentAyah.surah.number,
    ayah: currentAyah.ayah.number,
    surah_name: currentAyah.surah.name_fr,
    surah_name_ar: currentAyah.surah.name_ar,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr,
    theme: themeSelect.value,
    output_format: formatSelect.value,
    tone: toneSelect.value
  };

  const response = await fetch('api/prompt.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de générer le Prompt Maître avancé.');
  }

  return data.prompt;
}

function lookupSurahMeta(surahNumber) {
  return surahCatalog.find(item => Number(item.number) === Number(surahNumber)) || null;
}

function buildReferenceText(surahNumber, ayahNumber) {
  const surahMeta = lookupSurahMeta(surahNumber);
  if (!surahMeta) return `Sourate ${surahNumber} · Verset ${ayahNumber}`;
  return `${surahMeta.name_fr} · ${surahMeta.name_ar} · ${surahNumber}:${ayahNumber}`;
}

function createHistoryEntry(kind, payload = {}) {
  return {
    id: `${kind}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    kind,
    surah: Number(payload.surah || 0),
    ayah: Number(payload.ayah || 0),
    reference: payload.reference || '',
    surah_name: payload.surah_name || '',
    note: payload.note || '',
    created_at: new Date().toISOString(),
  };
}

function pushHistory(kind, payload = {}) {
  activityState.history.unshift(createHistoryEntry(kind, payload));
  activityState.history = activityState.history.slice(0, 18);
  persistActivityState();
  renderDashboard();
}

function openAyahFromReference(surahNumber, ayahNumber) {
  if (!surahNumber || !ayahNumber) return;
  surahSelect.value = String(surahNumber);
  updateAyahLimit();
  ayahInput.value = String(ayahNumber);
  form.requestSubmit();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function wrapText(text, maxCharsPerLine) {
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (!clean) return [''];
  const words = clean.split(' ');
  const lines = [];
  let currentLine = '';
  words.forEach(word => {
    const candidate = currentLine ? `${currentLine} ${word}` : word;
    if (candidate.length <= maxCharsPerLine || !currentLine) {
      currentLine = candidate;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  });
  if (currentLine) lines.push(currentLine);
  return lines;
}

function escapeXml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function buildVisualConfig() {
  if (!currentAyah) {
    throw new Error('Chargez d’abord un verset.');
  }

  const payload = {
    surah: currentAyah.surah.number,
    ayah: currentAyah.ayah.number,
    surah_name: currentAyah.surah.name_fr,
    surah_name_ar: currentAyah.surah.name_ar,
    reference: `${currentAyah.surah.number}:${currentAyah.ayah.number}`,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr,
    theme_code: visualThemeSelect.value,
    format_code: visualFormatSelect.value,
    ornament_code: visualOrnamentSelect.value,
    signature: signatureInput.value.trim(),
    show_reference: showReferenceCheck.checked,
    show_translation: showTranslationCheck.checked,
    show_brand: showBrandCheck.checked,
  };

  const response = await fetch('api/visual.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de préparer la configuration visuelle.');
  }

  return data.visual;
}

function getFontScale(formatCode) {
  const scales = {
    square: { title: 42, ref: 22, arabic: 54, translation: 24, footer: 16, lineHeightArabic: 70, lineHeightTranslation: 34 },
    story: { title: 54, ref: 24, arabic: 60, translation: 26, footer: 18, lineHeightArabic: 78, lineHeightTranslation: 36 },
    landscape: { title: 36, ref: 19, arabic: 42, translation: 21, footer: 15, lineHeightArabic: 58, lineHeightTranslation: 30 },
    a4: { title: 34, ref: 20, arabic: 48, translation: 20, footer: 14, lineHeightArabic: 62, lineHeightTranslation: 28 },
  };
  return scales[formatCode] || scales.square;
}

function buildOrnaments(config) {
  const { width, height } = config.format;
  const accentSoft = config.theme.accent_soft;
  const border = config.theme.border;
  if (config.ornament_code === 'arch') {
    return `<path d="M ${width * 0.22} ${height * 0.28} Q ${width * 0.5} ${height * 0.06} ${width * 0.78} ${height * 0.28}" fill="none" stroke="${accentSoft}" stroke-width="4" stroke-opacity="0.28" />`;
  }
  if (config.ornament_code === 'stars') {
    return `<g fill="${accentSoft}" fill-opacity="0.18"><circle cx="${width * 0.17}" cy="${height * 0.16}" r="6" /><circle cx="${width * 0.82}" cy="${height * 0.2}" r="5" /><circle cx="${width * 0.74}" cy="${height * 0.84}" r="6" /><circle cx="${width * 0.24}" cy="${height * 0.79}" r="5" /></g>`;
  }
  if (config.ornament_code === 'geometry') {
    return `<rect x="${width * 0.12}" y="${height * 0.12}" width="${width * 0.76}" height="${height * 0.76}" rx="24" fill="none" stroke="${border}" stroke-opacity="0.2" stroke-width="2" />`;
  }
  return `<g opacity="0.18"><circle cx="${width * 0.16}" cy="${height * 0.12}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" /><circle cx="${width * 0.84}" cy="${height * 0.12}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" /><circle cx="${width * 0.16}" cy="${height * 0.88}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" /><circle cx="${width * 0.84}" cy="${height * 0.88}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" /></g>`;
}

function buildSvgMarkup(config) {
  const { width, height } = config.format;
  const scale = getFontScale(config.format.code);
  const arabicMaxChars = config.format.code === 'story' ? 21 : config.format.code === 'landscape' ? 28 : 24;
  const translationMaxChars = config.format.code === 'story' ? 38 : config.format.code === 'landscape' ? 62 : 42;
  const arabicLines = wrapText(config.text_ar, arabicMaxChars).slice(0, 8);
  const translationLines = config.show_translation ? wrapText(config.translation_fr, translationMaxChars).slice(0, 7) : [];
  const arabicBlockHeight = Math.max(arabicLines.length, 1) * scale.lineHeightArabic;
  const translationBlockHeight = translationLines.length * scale.lineHeightTranslation;
  const centerY = config.format.code === 'story' ? 620 : height * 0.42;
  const arabicStartY = centerY;
  const translationStartY = arabicStartY + arabicBlockHeight + (config.show_translation ? 48 : 0);
  const footerY = height - 68;
  const arabicX = width / 2;
  const titleY = 110;
  const refY = titleY + 48;
  const ornaments = buildOrnaments(config);
  const titleText = escapeXml(`سورة ${config.surah_name_ar}`);
  const refText = escapeXml(`${config.surah_name} · ${config.reference}`);
  const footerText = escapeXml(config.signature || 'QVL');
  const arabicTspans = arabicLines.map((line, index) => `<tspan x="${arabicX}" dy="${index === 0 ? 0 : scale.lineHeightArabic}">${escapeXml(line)}</tspan>`).join('');
  const translationTspans = translationLines.map((line, index) => `<tspan x="${arabicX}" dy="${index === 0 ? 0 : scale.lineHeightTranslation}">${escapeXml(line)}</tspan>`).join('');
  const translationBlock = config.show_translation ? `<text x="${arabicX}" y="${translationStartY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.translation}" font-weight="500" fill="${config.theme.text_soft}">${translationTspans}</text>` : '';
  const referenceBlock = config.show_reference ? `<text x="${arabicX}" y="${refY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.ref}" font-weight="700" fill="${config.theme.text_soft}">${refText}</text>` : '';
  const brandBlock = config.show_brand ? `<text x="${arabicX}" y="${footerY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.footer}" font-weight="700" fill="${config.theme.text_muted}">${footerText}</text>` : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeXml(config.reference)}"><defs><linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${config.theme.bg_start}" /><stop offset="100%" stop-color="${config.theme.bg_end}" /></linearGradient><radialGradient id="haloGrad" cx="50%" cy="24%" r="48%"><stop offset="0%" stop-color="${config.theme.accent}" stop-opacity="0.42" /><stop offset="100%" stop-color="${config.theme.accent}" stop-opacity="0" /></radialGradient></defs><rect width="100%" height="100%" rx="36" fill="url(#bgGrad)" /><rect x="22" y="22" width="${width - 44}" height="${height - 44}" rx="30" fill="none" stroke="${config.theme.border}" stroke-width="2" opacity="0.6" /><circle cx="${width / 2}" cy="${Math.max((config.format.code === 'story' ? 280 : 170) - 34, 120)}" r="${config.format.code === 'story' ? 270 : 190}" fill="url(#haloGrad)" />${ornaments}<rect x="70" y="${config.format.code === 'story' ? 220 : 180}" width="${width - 140}" height="${Math.min(height * 0.52, arabicBlockHeight + translationBlockHeight + 180)}" rx="32" fill="${config.theme.panel}" fill-opacity="0.26" stroke="${config.theme.border}" stroke-opacity="0.28" /><text x="${arabicX}" y="${titleY}" text-anchor="middle" font-family="Amiri, serif" font-size="${scale.title}" font-weight="700" fill="${config.theme.text_main}">${titleText}</text>${referenceBlock}<text x="${arabicX}" y="${arabicStartY}" text-anchor="middle" font-family="Amiri, serif" font-size="${scale.arabic}" font-weight="700" fill="${config.theme.text_main}" direction="rtl" unicode-bidi="plaintext">${arabicTspans}</text>${translationBlock}${brandBlock}</svg>`;
}

function renderVisualMeta(config) {
  visualMeta.innerHTML = '';
  [config.format.label, config.theme.label, config.ornament_label, config.reference].forEach(text => {
    const span = document.createElement('span');
    span.className = 'visual-pill';
    span.textContent = text;
    visualMeta.appendChild(span);
  });
}

function renderVisual(config) {
  currentVisualConfig = config;
  currentSvgMarkup = buildSvgMarkup(config);
  visualPreview.innerHTML = currentSvgMarkup;
  svgSourceOutput.value = currentSvgMarkup;
  renderVisualMeta(config);
  visualPlaceholder.classList.add('d-none');
  visualStage.classList.remove('d-none');
  exportSvgBtn.disabled = false;
  exportPngBtn.disabled = false;
  copyCaptionBtn.disabled = false;
}

function exportSvg() {
  if (!currentSvgMarkup || !currentVisualConfig) return;
  triggerDownload(new Blob([currentSvgMarkup], { type: 'image/svg+xml;charset=utf-8' }), currentVisualConfig.export_base + '.svg');
}

function exportPng() {
  if (!currentSvgMarkup || !currentVisualConfig) return;
  const svgBlob = new Blob([currentSvgMarkup], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(svgBlob);
  const img = new Image();
  img.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = currentVisualConfig.format.width;
    canvas.height = currentVisualConfig.format.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    canvas.toBlob(blob => {
      if (blob) triggerDownload(blob, currentVisualConfig.export_base + '.png');
      else showFeedback('Export PNG impossible sur ce navigateur.', 'danger');
      URL.revokeObjectURL(url);
    }, 'image/png');
  };
  img.onerror = () => { URL.revokeObjectURL(url); showFeedback('Le visuel SVG n’a pas pu être converti en PNG.', 'danger'); };
  img.src = url;
}

function buildCaptionText() {
  if (!currentAyah) return '';
  const parts = [
    `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar}`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    '',
    currentAyah.ayah.text_ar
  ];
  if (showTranslationCheck.checked && currentAyah.ayah.translation_fr) parts.push('', currentAyah.ayah.translation_fr);
  parts.push('', 'Carte générée avec Quran-Visual-Lab · QVL');
  return parts.join('\n');
}

async function buildLearningModule() {
  if (!currentAyah) throw new Error('Chargez d’abord un verset.');
  const payload = {
    surah: currentAyah.surah.number,
    ayah: currentAyah.ayah.number,
    surah_name: currentAyah.surah.name_fr,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr,
    global_ayah_number: currentAyah.ayah.global_number,
    ayah_count: currentAyah.surah.ayah_count,
    revelation_type: currentAyah.surah.revelation_type,
    edition: audioEditionSelect.value,
    bitrate: Number(audioBitrateSelect.value),
  };
  const response = await fetch('api/learning.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.message || 'Impossible de préparer le module Learning.');
  return data.learning;
}

function renderLearningMeta() {
  learningMeta.innerHTML = '';
  if (!currentAyah || !currentLearning) return;
  [currentLearning.reference, `Audio ${currentLearning.audio.edition}`, `${currentLearning.audio.bitrate} kbps`].forEach(text => {
    const span = document.createElement('span');
    span.className = 'visual-pill';
    span.textContent = text;
    learningMeta.appendChild(span);
  });
}

function renderQuiz(quiz) {
  quizContainer.innerHTML = '';
  quiz.forEach((item, index) => {
    const card = document.createElement('div');
    card.className = 'quiz-card';
    const title = document.createElement('p');
    title.className = 'quiz-question';
    title.textContent = `${index + 1}. ${item.question}`;
    card.appendChild(title);
    if (item.prompt) {
      const prompt = document.createElement('p');
      prompt.className = 'masked-ayah mb-3';
      prompt.textContent = item.prompt;
      card.appendChild(prompt);
    }
    if (item.type === 'mcq') {
      const wrapper = document.createElement('div');
      wrapper.className = 'quiz-options';
      (item.options || []).forEach(optionValue => {
        const label = document.createElement('label');
        label.className = 'quiz-option';
        const input = document.createElement('input');
        input.type = 'radio';
        input.name = item.id;
        input.value = String(optionValue);
        label.appendChild(input);
        label.append(document.createTextNode(` ${optionValue}`));
        wrapper.appendChild(label);
      });
      card.appendChild(wrapper);
    } else {
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'quiz-input';
      input.placeholder = 'Votre réponse';
      card.appendChild(input);
    }
    if (item.hint) {
      const hint = document.createElement('p');
      hint.className = 'quiz-answer-note';
      hint.textContent = `Indice : ${item.hint}`;
      card.appendChild(hint);
    }
    quizContainer.appendChild(card);
  });
}

function renderLearning(learning) {
  currentLearning = learning;
  learningPlaceholder.classList.add('d-none');
  learningStage.classList.remove('d-none');
  learningReference.textContent = learning.reference;
  learningAudioMeta.textContent = `${learning.audio.edition} · ${learning.audio.bitrate} kbps`;
  learningAudio.src = learning.audio.url;
  repetitionSteps.innerHTML = '';
  (learning.repetition_steps || []).forEach(step => {
    const li = document.createElement('li');
    li.textContent = step;
    repetitionSteps.appendChild(li);
  });
  maskedAyahText.textContent = learning.mask_exercise.masked_text || '';
  maskHint.textContent = learning.mask_exercise.hidden_word ? 'Essayez de retrouver le mot masqué avant de le révéler.' : 'Aucun mot masqué disponible pour ce verset.';
  renderQuiz(learning.quiz || []);
  renderLearningMeta();
  updateLearningWidgets();
}

function getProgressLabel(level) {
  return {
    0: 'Non commencé',
    1: 'Écouté',
    2: 'Relu',
    3: 'En cours de mémorisation',
    4: 'Maîtrisé',
  }[Number(level)] || 'Non commencé';
}

function updateLearningWidgets() {
  const key = getAyahKey();
  const favorite = Boolean(learningState.favorites[key]);
  const level = Number(learningState.progress[key] || 0);
  const note = learningState.notes[key] || '';
  noteInput.value = note;
  memoryLevelSelect.value = String(level);
  favoriteBadge.textContent = `Favori : ${favorite ? 'oui' : 'non'}`;
  progressBadge.textContent = `Progression : ${getProgressLabel(level)}`;
  toggleFavoriteBtn.textContent = favorite ? 'Retirer des favoris' : 'Ajouter aux favoris';
}

function updateLearningStateFromInputs() {
  const key = getAyahKey();
  if (!key) return;
  learningState.notes[key] = noteInput.value.trim();
  learningState.progress[key] = Number(memoryLevelSelect.value || 0);
  persistLearningState();
  updateLearningWidgets();
  renderDashboard();
}

async function saveLearningProgressRemote() {
  const payload = { action: 'save_progress', session_id: getSessionId(), progress: learningState.progress };
  const response = await fetch('api/learning.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.message || 'Impossible d’enregistrer la progression.');
  return data;
}

function checkQuizAnswers() {
  const cards = [...quizContainer.querySelectorAll('.quiz-card')];
  if (!cards.length || !currentLearning?.quiz) {
    showFeedback('Aucun quiz n’est prêt.', 'danger');
    return;
  }
  let correct = 0;
  const total = cards.length;
  cards.forEach((card, index) => {
    const item = currentLearning.quiz[index];
    const expected = String(item.answer || '').trim().toLowerCase();
    let actual = '';
    if (item.type === 'mcq') actual = String(card.querySelector('input:checked')?.value || '').trim().toLowerCase();
    else actual = String(card.querySelector('input')?.value || '').trim().toLowerCase();
    const ok = expected !== '' && actual === expected;
    card.style.borderColor = ok ? 'rgba(74, 222, 128, 0.45)' : 'rgba(248, 113, 113, 0.45)';
    let note = card.querySelector('.quiz-eval');
    if (!note) {
      note = document.createElement('p');
      note.className = 'quiz-answer-note quiz-eval';
      card.appendChild(note);
    }
    note.textContent = ok ? 'Réponse correcte.' : `Réponse attendue : ${item.answer}`;
    if (ok) correct += 1;
  });
  quizResultBox.classList.remove('d-none');
  quizResultBox.innerHTML = `<p class="mb-1"><strong>Résultat :</strong> ${correct} / ${total}</p><p class="mb-0">Utilisez ce score pour décider si vous passez à l’étape suivante de mémorisation.</p>`;
}

async function copyToClipboard(text, successMessage) {
  try {
    await navigator.clipboard.writeText(text);
    showFeedback(successMessage, 'success');
  } catch {
    showFeedback('Copie impossible dans ce navigateur.', 'danger');
  }
}

function buildDashboardItem(item, withOpenAction = true) {
  const wrapper = document.createElement('div');
  wrapper.className = 'dashboard-item';
  const head = document.createElement('div');
  head.className = 'dashboard-item-head';
  const left = document.createElement('div');
  const title = document.createElement('p');
  title.className = 'dashboard-item-title';
  title.textContent = item.reference || buildReferenceText(item.surah, item.ayah);
  const subtitle = document.createElement('p');
  subtitle.className = 'dashboard-item-subtitle';
  subtitle.textContent = item.note || item.surah_name || 'Activité QVL';
  left.append(title, subtitle);
  const meta = document.createElement('p');
  meta.className = 'dashboard-item-meta';
  meta.textContent = item.created_at ? new Date(item.created_at).toLocaleString('fr-FR') : 'maintenant';
  head.append(left, meta);
  wrapper.appendChild(head);
  if (withOpenAction) {
    const actions = document.createElement('div');
    actions.className = 'dashboard-item-actions';
    const openBtn = document.createElement('button');
    openBtn.type = 'button';
    openBtn.className = 'btn btn-outline-light btn-sm';
    openBtn.textContent = 'Ouvrir';
    openBtn.addEventListener('click', () => openAyahFromReference(item.surah, item.ayah));
    actions.appendChild(openBtn);
    wrapper.appendChild(actions);
  }
  return wrapper;
}

function renderServerSnapshot() {
  const snapshot = dashboardCatalog.snapshot;
  const stats = dashboardCatalog.stats || {};
  if (!snapshot && !Object.keys(stats).length) {
    serverSnapshot.innerHTML = '<p class="mb-0">Aucune synthèse serveur disponible pour le moment.</p>';
    return;
  }
  const parts = [];
  if (snapshot) {
    parts.push(`<p class="mb-1"><strong>Session :</strong> ${snapshot.session_id || 'guest'}</p>`);
    parts.push(`<p class="mb-1"><strong>Dernière mise à jour :</strong> ${snapshot.updated_at ? new Date(snapshot.updated_at).toLocaleString('fr-FR') : '—'}</p>`);
    parts.push(`<p class="mb-0"><strong>Versets suivis :</strong> ${Number(snapshot.progress_count || 0)}</p>`);
  }
  if (Object.keys(stats).length) {
    parts.push('<hr class="my-3 border-secondary-subtle">');
    parts.push(`<p class="mb-1"><strong>Cache visuels :</strong> ${Number(stats.visual_cache_files || 0)}</p>`);
    parts.push(`<p class="mb-1"><strong>Fichiers de progression :</strong> ${Number(stats.progress_files || 0)}</p>`);
    parts.push(`<p class="mb-0"><strong>Séries CTM :</strong> ${Number(stats.series_count || 0)}</p>`);
  }
  serverSnapshot.innerHTML = parts.join('');
}

function renderHistoryList() {
  historyList.innerHTML = '';
  if (!activityState.history.length) {
    historyList.innerHTML = '<p class="dashboard-empty">Aucune activité enregistrée. Consultez un verset pour démarrer.</p>';
    return;
  }
  const labelMap = { consult: 'Consultation QVL', prompt: 'Prompt généré', visual: 'Visuel généré', learning: 'Session Learning', favorite: 'Favori mis à jour', progress: 'Progression enregistrée' };
  activityState.history.slice(0, 8).forEach(item => historyList.appendChild(buildDashboardItem({ ...item, note: labelMap[item.kind] || item.note || 'Activité QVL' })));
}

function renderFavoritesList() {
  favoriteList.innerHTML = '';
  const entries = Object.entries(learningState.favorites || {}).filter(([, value]) => Boolean(value));
  if (!entries.length) {
    favoriteList.innerHTML = '<p class="dashboard-empty">Aucun favori enregistré pour le moment.</p>';
    return;
  }
  entries.slice(0, 8).forEach(([key]) => {
    const [surah, ayah] = key.split(':').map(Number);
    const meta = lookupSurahMeta(surah);
    favoriteList.appendChild(buildDashboardItem({ surah, ayah, reference: meta ? `${meta.name_fr} · ${meta.name_ar} · ${surah}:${ayah}` : `Sourate ${surah} · Verset ${ayah}`, note: learningState.notes[key] || 'Favori QVL', created_at: new Date().toISOString() }));
  });
}

function renderDashboardStats() {
  const favoriteCount = Object.values(learningState.favorites || {}).filter(Boolean).length;
  const consultedCount = Math.max(Number(activityState.metrics.consulted || 0), new Set(activityState.history.filter(item => item.kind === 'consult').map(item => `${item.surah}:${item.ayah}`)).size);
  statConsulted.textContent = String(consultedCount);
  statFavorites.textContent = String(favoriteCount);
  statPrompts.textContent = String(Number(activityState.metrics.prompts || 0));
  statVisuals.textContent = String(Number(activityState.metrics.visuals || 0));
  statLearning.textContent = String(Number(activityState.metrics.learning || 0));
  statStudyTime.textContent = `${Number(activityState.metrics.study_minutes || 0)} min`;
}

function renderVerseOfDay() {
  const verse = dashboardCatalog.verse_of_day;
  if (!verse) {
    verseOfDayCard.innerHTML = '<p class="mb-0 panel-text">Verset du jour indisponible.</p>';
    return;
  }
  verseOfDayCard.innerHTML = `<p class="verse-day-reference">${verse.reference} · ${verse.theme || 'méditation'}</p><div class="verse-day-text" dir="rtl" lang="ar">${verse.text_ar}</div><p class="verse-day-translation">${verse.translation_fr || ''}</p><div class="d-flex gap-2 flex-wrap"><button type="button" class="btn btn-qvl-primary btn-sm" data-open-verse>Ouvrir ce verset</button><button type="button" class="btn btn-outline-light btn-sm" data-copy-verse>Copier</button></div>`;
  verseOfDayCard.querySelector('[data-open-verse]')?.addEventListener('click', () => openAyahFromReference(verse.surah, verse.ayah));
  verseOfDayCard.querySelector('[data-copy-verse]')?.addEventListener('click', async () => {
    const text = `${verse.reference}\n\n${verse.text_ar}\n\n${verse.translation_fr || ''}`.trim();
    await copyToClipboard(text, 'Verset du jour copié dans le presse-papiers.');
  });
}

function renderSeries() {
  seriesGrid.innerHTML = '';
  const series = Array.isArray(dashboardCatalog.series) ? dashboardCatalog.series : [];
  if (!series.length) {
    seriesGrid.innerHTML = '<p class="dashboard-empty">Aucune série thématique disponible.</p>';
    return;
  }
  series.forEach(seriesItem => {
    const card = document.createElement('article');
    card.className = 'series-card';
    card.innerHTML = `<div class="series-card-header"><div><p class="series-title">${seriesItem.title}</p><p class="series-description mb-0">${seriesItem.description || ''}</p></div><span class="series-tag">${seriesItem.tag || 'série'}</span></div><ul class="series-list">${(seriesItem.items || []).slice(0, 3).map(item => `<li>${item.label}</li>`).join('')}</ul><div class="d-flex gap-2 flex-wrap"><button type="button" class="btn btn-qvl-secondary btn-sm" data-open-series>Charger le premier verset</button><button type="button" class="btn btn-outline-light btn-sm" data-copy-series>Copier la série</button></div>`;
    const first = (seriesItem.items || [])[0];
    card.querySelector('[data-open-series]')?.addEventListener('click', () => { if (first) openAyahFromReference(first.surah, first.ayah); });
    card.querySelector('[data-copy-series]')?.addEventListener('click', async () => {
      const text = `${seriesItem.title}\n${seriesItem.description || ''}\n\n${(seriesItem.items || []).map(item => `• ${item.label}`).join('\n')}`.trim();
      await copyToClipboard(text, 'Série copiée dans le presse-papiers.');
    });
    seriesGrid.appendChild(card);
  });
}

function renderTeacherSpace() {
  teacherSpace.innerHTML = '';
  const resources = Array.isArray(dashboardCatalog.teacher_space) ? dashboardCatalog.teacher_space : [];
  if (!resources.length) {
    teacherSpace.innerHTML = '<p class="dashboard-empty">Espace enseignant non chargé.</p>';
    return;
  }
  resources.forEach(resource => {
    const card = document.createElement('article');
    card.className = 'teacher-card';
    card.innerHTML = `<p class="teacher-title">${resource.title}</p><p class="teacher-description">${resource.description || ''}</p><ul class="teacher-list">${(resource.points || []).map(point => `<li>${point}</li>`).join('')}</ul>`;
    teacherSpace.appendChild(card);
  });
}

function renderDashboard() {
  renderDashboardStats();
  renderHistoryList();
  renderFavoritesList();
  renderServerSnapshot();
  renderVerseOfDay();
  renderSeries();
  renderTeacherSpace();
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  hideFeedback();
  promptOutput.value = '';
  copyPromptBtn.disabled = true;
  const surah = surahSelect.value.trim();
  const ayah = ayahInput.value.trim();
  const validationError = validateInput(surah, ayah);
  if (validationError) {
    resetResult();
    showFeedback(validationError, 'danger');
    return;
  }
  try {
    showFeedback('Chargement du verset en cours...', 'success');
    const data = await fetchAyah(surah, ayah);
    currentAyah = data;
    renderAyah(data);
    resetVisual();
    resetLearning();
    createVisualBtn.disabled = false;
    buildLearningBtn.disabled = false;
    toggleFavoriteBtn.disabled = false;
    saveLearningBtn.disabled = false;
    updateLearningWidgets();
    activityState.metrics.consulted += 1;
    activityState.metrics.study_minutes += 2;
    persistActivityState();
    pushHistory('consult', { surah: data.surah.number, ayah: data.ayah.number, surah_name: data.surah.name_fr, reference: `${data.surah.name_fr} · ${data.surah.name_ar} · ${data.surah.number}:${data.ayah.number}`, note: 'Consultation du verset' });
    showFeedback('Verset récupéré avec succès.', 'success');
  } catch (error) {
    resetResult();
    showFeedback(error.message, 'danger');
  }
});

generatePromptBtn.addEventListener('click', async () => {
  try {
    const prompt = await generatePromptFromApi();
    promptOutput.value = prompt;
    copyPromptBtn.disabled = false;
    activityState.metrics.prompts += 1;
    persistActivityState();
    if (currentAyah) pushHistory('prompt', { surah: currentAyah.surah.number, ayah: currentAyah.ayah.number, surah_name: currentAyah.surah.name_fr, reference: `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar} · ${currentAyah.surah.number}:${currentAyah.ayah.number}`, note: 'Prompt maître généré' });
    showFeedback('Prompt Maître avancé généré.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

copyPromptBtn.addEventListener('click', async () => {
  if (!promptOutput.value.trim()) { showFeedback('Le champ du prompt est vide.', 'danger'); return; }
  await copyToClipboard(promptOutput.value, 'Prompt copié dans le presse-papiers.');
});

copyAyahBtn.addEventListener('click', async () => {
  const text = getAyahPlainText();
  if (!text) { showFeedback('Aucun verset à copier.', 'danger'); return; }
  await copyToClipboard(text, 'Verset copié dans le presse-papiers.');
});

exportTxtBtn.addEventListener('click', () => { exportCurrentTxt(); showFeedback('Export TXT déclenché.', 'success'); });

createVisualBtn.addEventListener('click', async () => {
  try {
    showFeedback('Construction du visuel en cours...', 'success');
    const config = await buildVisualConfig();
    renderVisual(config);
    activityState.metrics.visuals += 1;
    activityState.metrics.study_minutes += 1;
    persistActivityState();
    if (currentAyah) pushHistory('visual', { surah: currentAyah.surah.number, ayah: currentAyah.ayah.number, surah_name: currentAyah.surah.name_fr, reference: `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar} · ${currentAyah.surah.number}:${currentAyah.ayah.number}`, note: `Visuel ${config.format.label}` });
    showFeedback('Visuel QVL généré avec succès.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

buildLearningBtn.addEventListener('click', async () => {
  try {
    updateLearningStateFromInputs();
    showFeedback('Préparation du module Learning...', 'success');
    const learning = await buildLearningModule();
    renderLearning(learning);
    activityState.metrics.learning += 1;
    activityState.metrics.study_minutes += 3;
    persistActivityState();
    if (currentAyah) pushHistory('learning', { surah: currentAyah.surah.number, ayah: currentAyah.ayah.number, surah_name: currentAyah.surah.name_fr, reference: `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar} · ${currentAyah.surah.number}:${currentAyah.ayah.number}`, note: 'Module Learning préparé' });
    showFeedback('Learning Lab prêt pour ce verset.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

exportSvgBtn.addEventListener('click', () => { exportSvg(); showFeedback('Export SVG déclenché.', 'success'); });
exportPngBtn.addEventListener('click', () => { exportPng(); showFeedback('Conversion PNG en cours...', 'success'); });

copyCaptionBtn.addEventListener('click', async () => {
  const caption = buildCaptionText();
  if (!caption) { showFeedback('Aucune légende à copier.', 'danger'); return; }
  await copyToClipboard(caption, 'Légende copiée dans le presse-papiers.');
});

revealMaskBtn.addEventListener('click', () => {
  if (!currentLearning?.mask_exercise?.hidden_word) return;
  maskedAyahText.textContent = currentAyah?.ayah?.text_ar || currentLearning.mask_exercise.masked_text;
  maskHint.textContent = `Mot révélé : ${currentLearning.mask_exercise.hidden_word}`;
});

copyMaskedBtn.addEventListener('click', async () => {
  const text = maskedAyahText.textContent.trim();
  if (!text) { showFeedback('Aucun exercice à copier.', 'danger'); return; }
  await copyToClipboard(text, 'Exercice copié dans le presse-papiers.');
});

checkQuizBtn.addEventListener('click', () => { checkQuizAnswers(); showFeedback('Quiz corrigé.', 'success'); });

surahSelect.addEventListener('change', updateAyahLimit);
audioEditionSelect.addEventListener('change', updateBitrateOptions);
memoryLevelSelect.addEventListener('change', updateLearningStateFromInputs);
noteInput.addEventListener('input', updateLearningStateFromInputs);

[visualFormatSelect, visualThemeSelect, visualOrnamentSelect, signatureInput, showReferenceCheck, showTranslationCheck, showBrandCheck].forEach(element => {
  element.addEventListener('change', () => { if (currentAyah && currentVisualConfig) createVisualBtn.click(); });
});

toggleFavoriteBtn.addEventListener('click', () => {
  const key = getAyahKey();
  if (!key) return;
  learningState.favorites[key] = !learningState.favorites[key];
  persistLearningState();
  updateLearningWidgets();
  if (currentAyah) pushHistory('favorite', { surah: currentAyah.surah.number, ayah: currentAyah.ayah.number, surah_name: currentAyah.surah.name_fr, reference: `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar} · ${currentAyah.surah.number}:${currentAyah.ayah.number}`, note: learningState.favorites[key] ? 'Favori ajouté' : 'Favori retiré' });
  showFeedback(learningState.favorites[key] ? 'Verset ajouté aux favoris.' : 'Verset retiré des favoris.', 'success');
});

saveLearningBtn.addEventListener('click', async () => {
  try {
    updateLearningStateFromInputs();
    const result = await saveLearningProgressRemote();
    if (currentAyah) pushHistory('progress', { surah: currentAyah.surah.number, ayah: currentAyah.ayah.number, surah_name: currentAyah.surah.name_fr, reference: `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar} · ${currentAyah.surah.number}:${currentAyah.ayah.number}`, note: 'Progression sauvegardée' });
    await loadDashboardCatalog().catch(() => {});
    renderDashboard();
    showFeedback(`Progression enregistrée (${result.file}).`, 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

clearHistoryBtn?.addEventListener('click', () => {
  activityState.history = [];
  persistActivityState();
  renderDashboard();
  showFeedback('Historique local vidé.', 'success');
});

loadVerseOfDayBtn?.addEventListener('click', () => {
  const verse = dashboardCatalog.verse_of_day;
  if (!verse) { showFeedback('Le verset du jour n’est pas encore chargé.', 'danger'); return; }
  openAyahFromReference(verse.surah, verse.ayah);
  showFeedback('Verset du jour chargé dans le formulaire.', 'success');
});

copyVerseOfDayBtn?.addEventListener('click', async () => {
  const verse = dashboardCatalog.verse_of_day;
  if (!verse) { showFeedback('Aucun verset du jour disponible.', 'danger'); return; }
  const text = `${verse.reference}\n\n${verse.text_ar}\n\n${verse.translation_fr || ''}`.trim();
  await copyToClipboard(text, 'Verset du jour copié dans le presse-papiers.');
});

document.querySelectorAll('.chip-btn').forEach(button => {
  button.addEventListener('click', () => {
    surahSelect.value = button.dataset.surah;
    updateAyahLimit();
    ayahInput.value = button.dataset.ayah;
    form.requestSubmit();
  });
});

(async function init() {
  try {
    loadLearningState();
    loadActivityState();
    await Promise.all([loadSurahs(), loadVisualCatalog(), loadLearningCatalog(), loadDashboardCatalog()]);
    updateAyahLimit();
    renderDashboard();
    showFeedback('QVL Étape 5 prêt. Vous pouvez consulter un verset puis explorer le tableau de bord CTM.', 'success');
  } catch (error) {
    renderDashboard();
    showFeedback(error.message, 'danger');
  }
})();
