const form = document.getElementById('qvl-form');
const surahSelect = document.getElementById('surahSelect');
const ayahInput = document.getElementById('ayahNumber');
const surahHelp = document.getElementById('surahHelp');
const feedbackBox = document.getElementById('feedbackBox');
const resultPlaceholder = document.getElementById('resultPlaceholder');
const resultCard = document.getElementById('resultCard');
const surahBadge = document.getElementById('surahBadge');
const ayahBadge = document.getElementById('ayahBadge');
const revelationBadge = document.getElementById('revelationBadge');
const sourceBadge = document.getElementById('sourceBadge');
const surahTitle = document.getElementById('surahTitle');
const surahSubtitle = document.getElementById('surahSubtitle');
const ayahArabic = document.getElementById('ayahArabic');
const ayahTranslation = document.getElementById('ayahTranslation');
const generatePromptBtn = document.getElementById('generatePromptBtn');
const copyPromptBtn = document.getElementById('copyPromptBtn');
const copyAyahBtn = document.getElementById('copyAyahBtn');
const exportTxtBtn = document.getElementById('exportTxtBtn');
const promptOutput = document.getElementById('promptOutput');
const themeSelect = document.getElementById('themeSelect');
const formatSelect = document.getElementById('formatSelect');
const toneSelect = document.getElementById('toneSelect');

const visualFormatSelect = document.getElementById('visualFormatSelect');
const visualThemeSelect = document.getElementById('visualThemeSelect');
const visualOrnamentSelect = document.getElementById('visualOrnamentSelect');
const signatureInput = document.getElementById('signatureInput');
const showReferenceCheck = document.getElementById('showReferenceCheck');
const showTranslationCheck = document.getElementById('showTranslationCheck');
const showBrandCheck = document.getElementById('showBrandCheck');
const createVisualBtn = document.getElementById('createVisualBtn');
const exportSvgBtn = document.getElementById('exportSvgBtn');
const exportPngBtn = document.getElementById('exportPngBtn');
const copyCaptionBtn = document.getElementById('copyCaptionBtn');
const visualMeta = document.getElementById('visualMeta');
const visualPlaceholder = document.getElementById('visualPlaceholder');
const visualStage = document.getElementById('visualStage');
const visualPreview = document.getElementById('visualPreview');
const svgSourceOutput = document.getElementById('svgSourceOutput');

let surahCatalog = [];
let currentAyah = null;
let visualCatalog = { themes: [], formats: {} };
let currentVisualConfig = null;
let currentSvgMarkup = '';

function showFeedback(message, type = 'success') {
  feedbackBox.textContent = message;
  feedbackBox.className = `alert alert-${type} mt-3 mb-0`;
  feedbackBox.classList.remove('d-none');
}

function hideFeedback() {
  feedbackBox.classList.add('d-none');
}

function resetResult() {
  currentAyah = null;
  resultCard.classList.add('d-none');
  resultPlaceholder.classList.remove('d-none');
  generatePromptBtn.disabled = true;
  copyPromptBtn.disabled = true;
  copyAyahBtn.disabled = true;
  exportTxtBtn.disabled = true;
  resetVisual();
}

function resetVisual() {
  currentVisualConfig = null;
  currentSvgMarkup = '';
  visualMeta.innerHTML = '';
  svgSourceOutput.value = '';
  visualPreview.innerHTML = '';
  visualStage.classList.add('d-none');
  visualPlaceholder.classList.remove('d-none');
  createVisualBtn.disabled = !currentAyah;
  exportSvgBtn.disabled = true;
  exportPngBtn.disabled = true;
  copyCaptionBtn.disabled = true;
}

function getSelectedSurahMeta() {
  const surahNumber = Number(surahSelect.value || 0);
  return surahCatalog.find(item => Number(item.number) === surahNumber) || null;
}

function updateAyahLimit() {
  const meta = getSelectedSurahMeta();

  if (!meta) {
    surahHelp.textContent = 'Choisissez une sourate pour afficher le nombre maximal de versets.';
    ayahInput.removeAttribute('max');
    return;
  }

  ayahInput.max = meta.ayah_count;
  ayahInput.placeholder = `Entre 1 et ${meta.ayah_count}`;
  surahHelp.textContent = `${meta.name_fr} · ${meta.name_ar} · ${meta.ayah_count} versets · ${meta.revelation_type}`;

  if (ayahInput.value && Number(ayahInput.value) > Number(meta.ayah_count)) {
    ayahInput.value = meta.ayah_count;
  }
}

function populateSurahs(list) {
  surahSelect.innerHTML = '<option value="">Sélectionner une sourate</option>';
  list.forEach(item => {
    const option = document.createElement('option');
    option.value = item.number;
    option.textContent = `${item.number}. ${item.name_fr} · ${item.name_ar}`;
    surahSelect.appendChild(option);
  });
}

function populateVisualThemes(themes) {
  visualThemeSelect.innerHTML = '';
  themes.forEach((theme, index) => {
    const option = document.createElement('option');
    option.value = theme.code;
    option.textContent = theme.label;
    if (index === 0) option.selected = true;
    visualThemeSelect.appendChild(option);
  });
}

async function loadSurahs() {
  const response = await fetch('data/surahs.json', { headers: { Accept: 'application/json' } });
  const data = await response.json();
  if (!response.ok || !Array.isArray(data)) {
    throw new Error('Impossible de charger la liste des sourates.');
  }
  surahCatalog = data;
  populateSurahs(data);
}

async function loadVisualCatalog() {
  const response = await fetch('api/visual.php', { headers: { Accept: 'application/json' } });
  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de charger le catalogue visuel.');
  }

  visualCatalog = {
    themes: Array.isArray(data.themes) ? data.themes : [],
    formats: typeof data.formats === 'object' && data.formats !== null ? data.formats : {}
  };

  populateVisualThemes(visualCatalog.themes);
}

function validateInput(surah, ayah) {
  if (!surah || !ayah) {
    return 'Veuillez choisir une sourate et saisir un numéro de verset.';
  }

  const meta = surahCatalog.find(item => Number(item.number) === Number(surah));
  if (!meta) {
    return 'La sourate choisie est invalide.';
  }

  if (Number(ayah) < 1 || Number(ayah) > Number(meta.ayah_count)) {
    return `Le verset doit être compris entre 1 et ${meta.ayah_count} pour cette sourate.`;
  }

  return '';
}

async function fetchAyah(surah, ayah) {
  const url = `api/ayah.php?surah=${encodeURIComponent(surah)}&ayah=${encodeURIComponent(ayah)}`;
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de récupérer ce verset.');
  }

  return data;
}

async function generatePromptFromApi() {
  if (!currentAyah) {
    throw new Error('Aucun verset n’est chargé pour le moment.');
  }

  const payload = {
    template_code: 'prompt_master_visual',
    surah_name: currentAyah.surah.name_fr,
    surah_name_ar: currentAyah.surah.name_ar,
    ayah_number: currentAyah.ayah.number,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr || '',
    theme: themeSelect.value,
    output_format: formatSelect.value,
    tone: toneSelect.value
  };

  const response = await fetch('api/prompt.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de générer le prompt.');
  }

  return data.prompt;
}

async function buildVisualConfig() {
  if (!currentAyah) {
    throw new Error('Chargez d’abord un verset.');
  }

  const payload = {
    surah: currentAyah.surah.number,
    ayah: currentAyah.ayah.number,
    surah_name: currentAyah.surah.name_fr,
    surah_name_ar: currentAyah.surah.name_ar,
    revelation_type: currentAyah.surah.revelation_type,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr || '',
    format: visualFormatSelect.value,
    theme: visualThemeSelect.value,
    ornament: visualOrnamentSelect.value,
    signature: signatureInput.value.trim(),
    show_reference: showReferenceCheck.checked,
    show_translation: showTranslationCheck.checked,
    show_brand: showBrandCheck.checked
  };

  const response = await fetch('api/visual.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de construire le visuel.');
  }

  return data.visual_config;
}

function renderAyah(data) {
  surahBadge.textContent = `Sourate ${data.surah.number}`;
  ayahBadge.textContent = `Verset ${data.ayah.number}`;
  revelationBadge.textContent = data.surah.revelation_type || 'Révélation non précisée';
  sourceBadge.textContent = data.meta?.source_label || 'Source non précisée';
  surahTitle.textContent = `${data.surah.name_fr} · ${data.surah.name_ar}`;
  surahSubtitle.textContent = `${data.surah.name_en} · ${data.surah.ayah_count} versets`;
  ayahArabic.textContent = data.ayah.text_ar;
  ayahTranslation.textContent = data.ayah.translation_fr || 'Traduction non renseignée.';

  resultPlaceholder.classList.add('d-none');
  resultCard.classList.remove('d-none');
  generatePromptBtn.disabled = false;
  copyAyahBtn.disabled = false;
  exportTxtBtn.disabled = false;
  createVisualBtn.disabled = false;
}

function getAyahPlainText() {
  if (!currentAyah) {
    return '';
  }

  return [
    `${currentAyah.surah.name_fr} (${currentAyah.surah.name_ar})`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    '',
    currentAyah.ayah.text_ar,
    '',
    currentAyah.ayah.translation_fr || 'Traduction non renseignée.'
  ].join('\n');
}

function exportCurrentTxt() {
  if (!currentAyah) {
    return;
  }

  const lines = [
    'Quran-Visual-Lab · Export texte',
    `${currentAyah.surah.name_fr} (${currentAyah.surah.name_ar})`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    `Source : ${currentAyah.meta?.source_label || 'non précisée'}`,
    '',
    'Texte arabe :',
    currentAyah.ayah.text_ar,
    '',
    'Traduction française :',
    currentAyah.ayah.translation_fr || 'Traduction non renseignée.',
    '',
    'Prompt Maître :',
    promptOutput.value.trim() || 'Non généré'
  ];

  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  triggerDownload(blob, `qvl-s${currentAyah.surah.number}-v${currentAyah.ayah.number}.txt`);
}

function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function escapeXml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function wrapText(text, maxCharsPerLine) {
  const source = String(text || '').trim();
  if (!source) return [];

  const words = source.split(/\s+/);
  const lines = [];
  let currentLine = '';

  words.forEach(word => {
    const candidate = currentLine ? `${currentLine} ${word}` : word;
    if (candidate.length <= maxCharsPerLine || !currentLine) {
      currentLine = candidate;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  });

  if (currentLine) lines.push(currentLine);
  return lines;
}

function getFontScale(formatCode) {
  const map = {
    square: { title: 40, ref: 24, arabic: 58, translation: 26, footer: 20, lineHeightArabic: 84, lineHeightTranslation: 38 },
    story: { title: 44, ref: 26, arabic: 60, translation: 28, footer: 22, lineHeightArabic: 88, lineHeightTranslation: 40 },
    landscape: { title: 44, ref: 24, arabic: 54, translation: 24, footer: 20, lineHeightArabic: 80, lineHeightTranslation: 36 },
    a4: { title: 38, ref: 24, arabic: 52, translation: 24, footer: 20, lineHeightArabic: 76, lineHeightTranslation: 34 }
  };
  return map[formatCode] || map.square;
}

function buildOrnaments(config) {
  const { width, height } = config.format;
  const accent = config.theme.accent;
  const accentSoft = config.theme.accent_soft;
  const border = config.theme.border;

  if (config.ornament === 'minimal') {
    return `
      <rect x="24" y="24" width="${width - 48}" height="${height - 48}" rx="28" fill="none" stroke="${border}" stroke-width="2" />
    `;
  }

  if (config.ornament === 'rays') {
    return `
      <g opacity="0.22" stroke="${accentSoft}" stroke-width="2">
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.5} 0" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.28} ${height * 0.04}" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.72} ${height * 0.04}" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.16} ${height * 0.12}" />
        <path d="M ${width * 0.5} ${height * 0.18} L ${width * 0.84} ${height * 0.12}" />
      </g>
      <circle cx="${width * 0.5}" cy="${height * 0.18}" r="92" fill="none" stroke="${accent}" stroke-opacity="0.18" stroke-width="3" />
    `;
  }

  if (config.ornament === 'mihrab') {
    return `
      <path d="M ${width * 0.22} ${height * 0.26} Q ${width * 0.5} ${height * 0.04} ${width * 0.78} ${height * 0.26}" fill="none" stroke="${accent}" stroke-opacity="0.35" stroke-width="5" />
      <path d="M ${width * 0.26} ${height * 0.28} L ${width * 0.26} ${height * 0.82}" fill="none" stroke="${border}" stroke-opacity="0.3" stroke-width="2" />
      <path d="M ${width * 0.74} ${height * 0.28} L ${width * 0.74} ${height * 0.82}" fill="none" stroke="${border}" stroke-opacity="0.3" stroke-width="2" />
      <rect x="${width * 0.18}" y="${height * 0.18}" width="${width * 0.64}" height="${height * 0.66}" rx="36" fill="none" stroke="${border}" stroke-opacity="0.2" stroke-width="2" />
    `;
  }

  return `
    <g opacity="0.18">
      <circle cx="${width * 0.16}" cy="${height * 0.12}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <circle cx="${width * 0.84}" cy="${height * 0.12}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <circle cx="${width * 0.16}" cy="${height * 0.88}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <circle cx="${width * 0.84}" cy="${height * 0.88}" r="90" fill="none" stroke="${accentSoft}" stroke-width="2" />
      <path d="M ${width * 0.1} ${height * 0.5} L ${width * 0.9} ${height * 0.5}" stroke="${border}" stroke-opacity="0.12" stroke-width="2" />
      <path d="M ${width * 0.5} ${height * 0.1} L ${width * 0.5} ${height * 0.9}" stroke="${border}" stroke-opacity="0.12" stroke-width="2" />
    </g>
  `;
}

function buildSvgMarkup(config) {
  const { width, height, label } = config.format;
  const scale = getFontScale(config.format.code);
  const arabicMaxChars = config.format.code === 'story' ? 21 : config.format.code === 'landscape' ? 28 : 24;
  const translationMaxChars = config.format.code === 'story' ? 38 : config.format.code === 'landscape' ? 62 : 42;
  const arabicLines = wrapText(config.text_ar, arabicMaxChars).slice(0, 8);
  const translationLines = config.show_translation ? wrapText(config.translation_fr, translationMaxChars).slice(0, 7) : [];
  const arabicBlockHeight = Math.max(arabicLines.length, 1) * scale.lineHeightArabic;
  const translationBlockHeight = translationLines.length * scale.lineHeightTranslation;
  const topBlock = config.format.code === 'story' ? 280 : 170;
  const centerY = config.format.code === 'story' ? 620 : height * 0.42;
  const arabicStartY = centerY;
  const translationStartY = arabicStartY + arabicBlockHeight + (config.show_translation ? 48 : 0);
  const footerY = height - 68;
  const contentWidth = width - 180;
  const arabicX = width / 2;
  const titleY = 110;
  const refY = titleY + 48;
  const ornaments = buildOrnaments(config);
  const titleText = escapeXml(`سورة ${config.surah_name_ar}`);
  const refText = escapeXml(`${config.surah_name} · ${config.reference}`);
  const footerText = escapeXml(config.signature || 'QVL');

  const arabicTspans = arabicLines.map((line, index) => {
    const dy = index === 0 ? 0 : scale.lineHeightArabic;
    return `<tspan x="${arabicX}" dy="${dy}">${escapeXml(line)}</tspan>`;
  }).join('');

  const translationTspans = translationLines.map((line, index) => {
    const dy = index === 0 ? 0 : scale.lineHeightTranslation;
    return `<tspan x="${arabicX}" dy="${dy}">${escapeXml(line)}</tspan>`;
  }).join('');

  const translationBlock = config.show_translation ? `
    <text x="${arabicX}" y="${translationStartY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.translation}" font-weight="500" fill="${config.theme.text_soft}" letter-spacing="0.2">
      ${translationTspans}
    </text>
  ` : '';

  const referenceBlock = config.show_reference ? `
    <text x="${arabicX}" y="${refY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.ref}" font-weight="700" fill="${config.theme.text_soft}" letter-spacing="0.5">${refText}</text>
  ` : '';

  const brandBlock = config.show_brand ? `
    <text x="${arabicX}" y="${footerY}" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="${scale.footer}" font-weight="700" fill="${config.theme.text_muted}" letter-spacing="1.2">${footerText}</text>
  ` : '';

  return `
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeXml(config.reference)}">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${config.theme.bg_start}" />
      <stop offset="100%" stop-color="${config.theme.bg_end}" />
    </linearGradient>
    <radialGradient id="haloGrad" cx="50%" cy="24%" r="48%">
      <stop offset="0%" stop-color="${config.theme.accent}" stop-opacity="0.42" />
      <stop offset="100%" stop-color="${config.theme.accent}" stop-opacity="0" />
    </radialGradient>
    <filter id="shadowSoft" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="18" flood-color="#000000" flood-opacity="0.24" />
    </filter>
  </defs>

  <rect width="100%" height="100%" rx="36" fill="url(#bgGrad)" />
  <rect x="22" y="22" width="${width - 44}" height="${height - 44}" rx="30" fill="none" stroke="${config.theme.border}" stroke-width="2" opacity="0.6" />
  <circle cx="${width / 2}" cy="${Math.max(topBlock - 34, 120)}" r="${config.format.code === 'story' ? 270 : 190}" fill="url(#haloGrad)" />
  ${ornaments}

  <g filter="url(#shadowSoft)">
    <rect x="70" y="${config.format.code === 'story' ? 220 : 180}" width="${width - 140}" height="${Math.min(height * 0.52, arabicBlockHeight + translationBlockHeight + 180)}" rx="32" fill="${config.theme.panel}" fill-opacity="0.26" stroke="${config.theme.border}" stroke-opacity="0.28" />
  </g>

  <text x="${arabicX}" y="${titleY}" text-anchor="middle" font-family="Amiri, serif" font-size="${scale.title}" font-weight="700" fill="${config.theme.text_main}" letter-spacing="0.2">${titleText}</text>
  ${referenceBlock}

  <text x="${arabicX}" y="${arabicStartY}" text-anchor="middle" font-family="Amiri, serif" font-size="${scale.arabic}" font-weight="700" fill="${config.theme.text_main}" direction="rtl" unicode-bidi="plaintext">
    ${arabicTspans}
  </text>

  ${translationBlock}
  ${brandBlock}
</svg>`.trim();
}

function renderVisualMeta(config) {
  visualMeta.innerHTML = '';
  const pills = [
    config.format.label,
    config.theme.label,
    config.ornament_label,
    config.reference
  ];

  pills.forEach(text => {
    const span = document.createElement('span');
    span.className = 'visual-pill';
    span.textContent = text;
    visualMeta.appendChild(span);
  });
}

function renderVisual(config) {
  currentVisualConfig = config;
  currentSvgMarkup = buildSvgMarkup(config);
  visualPreview.innerHTML = currentSvgMarkup;
  svgSourceOutput.value = currentSvgMarkup;
  renderVisualMeta(config);
  visualPlaceholder.classList.add('d-none');
  visualStage.classList.remove('d-none');
  exportSvgBtn.disabled = false;
  exportPngBtn.disabled = false;
  copyCaptionBtn.disabled = false;
}

function exportSvg() {
  if (!currentSvgMarkup || !currentVisualConfig) return;
  const blob = new Blob([currentSvgMarkup], { type: 'image/svg+xml;charset=utf-8' });
  triggerDownload(blob, currentVisualConfig.export_base + '.svg');
}

function exportPng() {
  if (!currentSvgMarkup || !currentVisualConfig) return;

  const svgBlob = new Blob([currentSvgMarkup], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(svgBlob);
  const img = new Image();
  img.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = currentVisualConfig.format.width;
    canvas.height = currentVisualConfig.format.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    canvas.toBlob(blob => {
      if (blob) {
        triggerDownload(blob, currentVisualConfig.export_base + '.png');
      } else {
        showFeedback('Export PNG impossible sur ce navigateur.', 'danger');
      }
      URL.revokeObjectURL(url);
    }, 'image/png');
  };
  img.onerror = () => {
    URL.revokeObjectURL(url);
    showFeedback('Le visuel SVG n’a pas pu être converti en PNG.', 'danger');
  };
  img.src = url;
}

function buildCaptionText() {
  if (!currentAyah) return '';
  const parts = [
    `${currentAyah.surah.name_fr} · ${currentAyah.surah.name_ar}`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    '',
    currentAyah.ayah.text_ar
  ];

  if (showTranslationCheck.checked && currentAyah.ayah.translation_fr) {
    parts.push('', currentAyah.ayah.translation_fr);
  }

  parts.push('', 'Carte générée avec Quran-Visual-Lab · QVL');
  return parts.join('\n');
}

async function copyToClipboard(text, successMessage) {
  try {
    await navigator.clipboard.writeText(text);
    showFeedback(successMessage, 'success');
  } catch (error) {
    showFeedback('Copie impossible dans ce navigateur.', 'danger');
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  hideFeedback();
  promptOutput.value = '';
  copyPromptBtn.disabled = true;

  const surah = surahSelect.value.trim();
  const ayah = ayahInput.value.trim();
  const validationError = validateInput(surah, ayah);

  if (validationError) {
    resetResult();
    showFeedback(validationError, 'danger');
    return;
  }

  try {
    showFeedback('Chargement du verset en cours...', 'success');
    const data = await fetchAyah(surah, ayah);
    currentAyah = data;
    renderAyah(data);
    resetVisual();
    createVisualBtn.disabled = false;
    showFeedback('Verset récupéré avec succès.', 'success');
  } catch (error) {
    resetResult();
    showFeedback(error.message, 'danger');
  }
});

generatePromptBtn.addEventListener('click', async () => {
  try {
    const prompt = await generatePromptFromApi();
    promptOutput.value = prompt;
    copyPromptBtn.disabled = false;
    showFeedback('Prompt Maître avancé généré.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

copyPromptBtn.addEventListener('click', async () => {
  if (!promptOutput.value.trim()) {
    showFeedback('Le champ du prompt est vide.', 'danger');
    return;
  }

  await copyToClipboard(promptOutput.value, 'Prompt copié dans le presse-papiers.');
});

copyAyahBtn.addEventListener('click', async () => {
  const text = getAyahPlainText();
  if (!text) {
    showFeedback('Aucun verset à copier.', 'danger');
    return;
  }

  await copyToClipboard(text, 'Verset copié dans le presse-papiers.');
});

exportTxtBtn.addEventListener('click', () => {
  exportCurrentTxt();
  showFeedback('Export TXT déclenché.', 'success');
});

createVisualBtn.addEventListener('click', async () => {
  try {
    showFeedback('Construction du visuel en cours...', 'success');
    const config = await buildVisualConfig();
    renderVisual(config);
    showFeedback('Visuel QVL généré avec succès.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

exportSvgBtn.addEventListener('click', () => {
  exportSvg();
  showFeedback('Export SVG déclenché.', 'success');
});

exportPngBtn.addEventListener('click', () => {
  exportPng();
  showFeedback('Conversion PNG en cours...', 'success');
});

copyCaptionBtn.addEventListener('click', async () => {
  const caption = buildCaptionText();
  if (!caption) {
    showFeedback('Aucune légende à copier.', 'danger');
    return;
  }
  await copyToClipboard(caption, 'Légende copiée dans le presse-papiers.');
});

surahSelect.addEventListener('change', updateAyahLimit);

[visualFormatSelect, visualThemeSelect, visualOrnamentSelect, signatureInput, showReferenceCheck, showTranslationCheck, showBrandCheck].forEach(element => {
  element.addEventListener('change', () => {
    if (currentAyah && currentVisualConfig) {
      createVisualBtn.click();
    }
  });
});

document.querySelectorAll('.chip-btn').forEach(button => {
  button.addEventListener('click', () => {
    surahSelect.value = button.dataset.surah;
    updateAyahLimit();
    ayahInput.value = button.dataset.ayah;
    form.requestSubmit();
  });
});

(async function init() {
  try {
    await Promise.all([loadSurahs(), loadVisualCatalog()]);
    updateAyahLimit();
    showFeedback('QVL Étape 3 prêt. Vous pouvez consulter un verset puis créer une carte visuelle.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
})();
