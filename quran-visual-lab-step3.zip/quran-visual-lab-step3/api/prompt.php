<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, [
        'success' => false,
        'message' => 'Utilisez une requête POST pour générer un prompt.'
    ]);
}

$payload = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($payload)) {
    respond(422, [
        'success' => false,
        'message' => 'Corps JSON invalide.'
    ]);
}

$templateCode = trim((string) ($payload['template_code'] ?? 'prompt_master_visual'));
$surahName = trim((string) ($payload['surah_name'] ?? ''));
$surahNameAr = trim((string) ($payload['surah_name_ar'] ?? ''));
$ayahNumber = (int) ($payload['ayah_number'] ?? 0);
$textAr = trim((string) ($payload['text_ar'] ?? ''));
$translation = trim((string) ($payload['translation_fr'] ?? ''));
$theme = trim((string) ($payload['theme'] ?? 'méditation et contemplation'));
$outputFormat = trim((string) ($payload['output_format'] ?? 'carte visuelle carrée'));
$tone = trim((string) ($payload['tone'] ?? 'spirituel, sobre et pédagogique'));

if ($surahName === '' || $ayahNumber < 1 || $textAr === '') {
    respond(422, [
        'success' => false,
        'message' => 'Données insuffisantes pour générer le prompt.'
    ]);
}

$templatesPath = dirname(__DIR__) . '/data/templates.json';
$templates = json_decode((string) @file_get_contents($templatesPath), true);
if (!is_array($templates)) {
    respond(500, [
        'success' => false,
        'message' => 'Le catalogue de templates est introuvable ou invalide.'
    ]);
}

$template = null;
foreach ($templates as $item) {
    if ((string) ($item['code'] ?? '') === $templateCode && !empty($item['is_active'])) {
        $template = $item;
        break;
    }
}

if ($template === null) {
    respond(404, [
        'success' => false,
        'message' => 'Le template demandé est introuvable ou désactivé.'
    ]);
}

$replacements = [
    '{{surah_name}}' => $surahName,
    '{{surah_name_ar}}' => $surahNameAr,
    '{{ayah_number}}' => (string) $ayahNumber,
    '{{text_ar}}' => $textAr,
    '{{translation_fr}}' => $translation !== '' ? $translation : 'Traduction non renseignée.',
    '{{theme}}' => $theme,
    '{{output_format}}' => $outputFormat,
    '{{tone}}' => $tone,
];

$content = strtr((string) ($template['content_template'] ?? ''), $replacements);

$prompt = implode("\n", [
    'PROMPT MAÎTRE QVL — ÉTAPE 2',
    sprintf('Template : %s', (string) ($template['title'] ?? $templateCode)),
    sprintf('Sourate : %s (%s)', $surahName, $surahNameAr),
    sprintf('Verset : %d', $ayahNumber),
    sprintf('Thème : %s', $theme),
    sprintf('Format ciblé : %s', $outputFormat),
    sprintf('Ton : %s', $tone),
    '',
    'Texte arabe exact :',
    $textAr,
    '',
    'Traduction française :',
    $translation !== '' ? $translation : 'Traduction non renseignée.',
    '',
    'Instruction de production :',
    $content,
    '',
    'Exigence absolue : respecter strictement le texte coranique, sans altération, sans paraphrase, sans suppression.'
]);

respond(200, [
    'success' => true,
    'prompt' => $prompt,
    'template_code' => $templateCode,
]);
