# Quran-Visual-Lab · Étape 3

Cette étape ajoute le module Visual Lab à la base QVL.

## Nouveautés principales

- atelier visuel complet dans `index.html`
- `api/visual.php` pour charger le catalogue des thèmes et construire la configuration du visuel
- `data/visual_themes.json` pour les palettes QVL
- composition SVG dynamique côté client
- export SVG natif
- export PNG par conversion Canvas
- formats intégrés : carré, story, paysage, A4
- cache JSON des configurations visuelles dans `cache/visuals/`

## Dossier concerné

Déployer le contenu dans :

`/quran-visual-lab/`

## Fichiers clés

- `index.html`
- `assets/css/style.css`
- `assets/js/app.js`
- `api/ayah.php`
- `api/prompt.php`
- `api/visual.php`
- `data/surahs.json`
- `data/ayahs.json`
- `data/templates.json`
- `data/visual_themes.json`

## Flux de test recommandé

1. ouvrir `index.html`
2. choisir une sourate et un verset
3. cliquer sur `Afficher le verset`
4. cliquer sur `Créer visuel`
5. tester `Exporter SVG`
6. tester `Exporter PNG`

## Conseils de déploiement

- conserver l’encodage UTF-8 sur tous les fichiers
- vérifier que PHP 8 est actif
- laisser le dossier `cache/visuals/` accessible en écriture si vous voulez garder les configurations générées
- conserver la police arabe Amiri côté interface

## Étape suivante

Étape 4 : audio, répétition, quiz, progression et favoris.
