const feedbackBox = document.getElementById('adminFeedback');
const statsBox = document.getElementById('adminStats');
const sessionBox = document.getElementById('adminSessionState');
const templatesBox = document.getElementById('adminTemplates');
const themesBox = document.getElementById('adminThemes');
const publicationsBox = document.getElementById('adminPublications');
const healthBox = document.getElementById('adminHealth');
const configBox = document.getElementById('adminConfig');
let adminCsrfToken = '';

function showAdminFeedback(message, type = 'success') {
  feedbackBox.textContent = message;
  feedbackBox.className = `alert alert-${type} mb-4`;
  feedbackBox.classList.remove('d-none');
}

async function loadAdmin() {
  const response = await fetch('../api/admin.php', { credentials: 'same-origin' });
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.message || 'Chargement admin impossible.');
  if (data.csrf_token) adminCsrfToken = data.csrf_token;
  renderAdmin(data);
}

function renderStats(stats) {
  statsBox.innerHTML = '';
  Object.entries(stats || {}).forEach(([key, value]) => {
    const div = document.createElement('div');
    div.className = 'stat-tile';
    div.innerHTML = `<span class="stat-label">${key.replaceAll('_', ' ')}</span><strong class="stat-value">${value}</strong>`;
    statsBox.appendChild(div);
  });
}

function renderSession(user, canAdmin) {
  if (!user) {
    sessionBox.innerHTML = '<p class="mb-0">Aucune session active. Connectez-vous depuis la page principale avec le compte admin.</p>';
    return;
  }
  sessionBox.innerHTML = `<p class="mb-2"><strong>${user.display_name}</strong></p><p class="mb-2">Rôle : ${user.role}</p><p class="mb-0">${canAdmin ? 'Accès administrateur confirmé.' : 'Session active sans privilèges administrateur.'}</p>`;
}

function renderHealth(health = []) {
  if (!healthBox) return;
  healthBox.innerHTML = '';
  if (!health.length) {
    healthBox.innerHTML = '<p class="dashboard-empty">Aucun diagnostic disponible.</p>';
    return;
  }
  health.forEach(item => {
    const row = document.createElement('div');
    row.className = 'history-item';
    row.innerHTML = `<div><p class="history-title mb-1">${item.path}</p><p class="history-meta mb-0">${item.exists ? 'présent' : 'absent'} · ${item.is_writable ? 'écriture ok' : 'lecture seule'}</p></div>`;
    healthBox.appendChild(row);
  });
}

function renderConfig(config = {}) {
  if (!configBox) return;
  configBox.innerHTML = `<div class="dashboard-stats-grid"><div class="stat-tile"><span class="stat-label">Application</span><strong class="stat-value">${config.app_name || 'QVL'}</strong></div><div class="stat-tile"><span class="stat-label">Version</span><strong class="stat-value">${config.version || '-'}</strong></div><div class="stat-tile"><span class="stat-label">Environnement</span><strong class="stat-value">${config.environment || '-'}</strong></div><div class="stat-tile"><span class="stat-label">Base path</span><strong class="stat-value">${config.base_path || '-'}</strong></div></div>`;
}

function renderToggleList(box, items, action) {
  box.innerHTML = '';
  if (!items?.length) {
    box.innerHTML = '<p class="dashboard-empty">Aucune donnée.</p>';
    return;
  }
  items.forEach(item => {
    const row = document.createElement('div');
    row.className = 'history-item';
    row.innerHTML = `<div><p class="history-title mb-1">${item.title || item.label || item.code}</p><p class="history-meta mb-0">${item.code}</p></div><div class="form-check form-switch"><input class="form-check-input admin-toggle" type="checkbox" ${item.is_active ? 'checked' : ''}></div>`;
    row.querySelector('.admin-toggle').addEventListener('change', async (event) => {
      try {
        const response = await fetch('../api/admin.php', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': adminCsrfToken },
          body: JSON.stringify({ action, code: item.code, is_active: event.target.checked })
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Mise à jour impossible.');
        showAdminFeedback(data.message, 'success');
      } catch (error) {
        event.target.checked = !event.target.checked;
        showAdminFeedback(error.message, 'danger');
      }
    });
    box.appendChild(row);
  });
}

function renderPublications(publications) {
  publicationsBox.innerHTML = '';
  if (!publications?.length) {
    publicationsBox.innerHTML = '<p class="dashboard-empty">Aucune publication.</p>';
    return;
  }
  publications.forEach(item => {
    const card = document.createElement('article');
    card.className = 'history-item';
    card.innerHTML = `<div><p class="history-title mb-1">${item.title}</p><p class="history-meta mb-1">${item.slug} · ${item.status}</p><p class="mb-0">${item.summary}</p></div>`;
    publicationsBox.appendChild(card);
  });
}

function renderAdmin(data) {
  renderStats(data.stats || {});
  renderSession(data.user, data.can_admin);
  renderToggleList(templatesBox, data.templates || [], 'toggle_template');
  renderToggleList(themesBox, data.themes || [], 'toggle_theme');
  renderPublications(data.publications || []);
  renderHealth(data.health || []);
  renderConfig(data.config || {});
  if (!data.can_admin) showAdminFeedback('Connectez-vous avec le compte admin pour modifier les réglages.', 'danger');
}

loadAdmin().catch(error => showAdminFeedback(error.message, 'danger'));
