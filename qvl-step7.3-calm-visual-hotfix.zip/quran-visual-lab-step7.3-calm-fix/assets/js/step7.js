
const qvlBridge = window.qvlApp || null;
let qvlCsrfToken = '';
let qvlMeta = null;

const authStatusBadge = document.getElementById('authStatusBadge');
const authInfoBox = document.getElementById('authInfoBox');
const authLoginInput = document.getElementById('authLoginInput');
const authPasswordInput = document.getElementById('authPasswordInput');
const authDisplayNameInput = document.getElementById('authDisplayNameInput');
const authUsernameInput = document.getElementById('authUsernameInput');
const authEmailInput = document.getElementById('authEmailInput');
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');
const logoutBtn = document.getElementById('logoutBtn');
const adminLink = document.getElementById('adminLink');

const exportDocxBtn = document.getElementById('exportDocxBtn');
const exportPdfBtn = document.getElementById('exportPdfBtn');
const printSheetBtn = document.getElementById('printSheetBtn');
const refreshExportListBtn = document.getElementById('refreshExportListBtn');
const serverExportList = document.getElementById('serverExportList');

const publicationList = document.getElementById('publicationList');
const publicationTitleInput = document.getElementById('publicationTitle');
const publicationSlugInput = document.getElementById('publicationSlug');
const publicationSummaryInput = document.getElementById('publicationSummary');
const publicationStatusSelect = document.getElementById('publicationStatus');
const savePublicationBtn = document.getElementById('savePublicationBtn');
const publicationAdminBox = document.getElementById('publicationAdminBox');
const adminStatsPreview = document.getElementById('adminStatsPreview');

let authState = { authenticated: false, user: null, demo_accounts: [] };
let adminState = { can_admin: false, stats: {}, publications: [], templates: [], themes: [] };

function getCsrfHeaders() {
  return qvlCsrfToken ? { 'X-CSRF-Token': qvlCsrfToken } : {};
}

async function loadMeta() {
  try {
    const response = await fetch('api/meta.php', { credentials: 'same-origin' });
    const data = await response.json();
    if (response.ok && data.success) {
      qvlMeta = data;
      if (data.csrf_token) qvlCsrfToken = data.csrf_token;
      const deployBox = document.getElementById('deployStatusList');
      if (deployBox && Array.isArray(data.health)) {
        deployBox.innerHTML = data.health.map(item => `<li>${item.path} · ${item.exists ? 'ok' : 'absent'} · ${item.is_writable ? 'écriture ok' : 'lecture seule'}</li>`).join('');
      }
      const versionBox = document.getElementById('appVersionBadge');
      if (versionBox && data.app?.version) {
        versionBox.textContent = `Version ${data.app.version}`;
      }
    }
  } catch (error) {
    console.warn('QVL meta unavailable', error);
  }
}

function appState() {
  return qvlBridge?.getState ? qvlBridge.getState() : {};
}

function appFeedback(message, type = 'success') {
  if (qvlBridge?.showFeedback) qvlBridge.showFeedback(message, type);
}

async function authRequest(payload = null) {
  const options = { credentials: 'same-origin' };
  if (payload) {
    options.method = 'POST';
    options.headers = { 'Content-Type': 'application/json', ...getCsrfHeaders() };
    options.body = JSON.stringify(payload);
  }
  const response = await fetch('api/auth.php', options);
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.message || 'Erreur d’authentification.');
  if (data.csrf_token) qvlCsrfToken = data.csrf_token;
  return data;
}

async function adminRequest(payload = null) {
  const options = { credentials: 'same-origin' };
  if (payload) {
    options.method = 'POST';
    options.headers = { 'Content-Type': 'application/json', ...getCsrfHeaders() };
    options.body = JSON.stringify(payload);
  }
  const response = await fetch('api/admin.php', options);
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.message || 'Erreur API admin.');
  if (data.csrf_token) qvlCsrfToken = data.csrf_token;
  return data;
}

async function exportRequest(payload = null) {
  const options = {};
  if (payload) {
    options.method = 'POST';
    options.headers = { 'Content-Type': 'application/json', ...getCsrfHeaders() };
    options.body = JSON.stringify(payload);
  }
  const response = await fetch('api/export.php', options);
  const data = await response.json();
  if (!response.ok || !data.success) throw new Error(data.message || 'Erreur API export.');
  if (data.csrf_token) qvlCsrfToken = data.csrf_token;
  return data;
}

function renderAuth() {
  authStatusBadge.textContent = authState.authenticated ? `Connecté · ${authState.user?.role || 'user'}` : 'Session invitée';
  if (authState.authenticated && authState.user) {
    authInfoBox.innerHTML = `<p class="mb-1"><strong>${authState.user.display_name}</strong></p><p class="mb-1">${authState.user.username} · ${authState.user.email}</p><p class="mb-0">Rôle : ${authState.user.role}</p>`;
    logoutBtn.disabled = false;
    adminLink.classList.toggle('d-none', authState.user.role !== 'admin');
  } else {
    const hints = (authState.demo_accounts || []).map(item => `<li>${item.username} · ${item.password_hint}</li>`).join('');
    authInfoBox.innerHTML = `<p class="mb-2">Aucune session active.</p><p class="mb-2">Comptes de démonstration inclus :</p><ul class="mb-0">${hints}</ul>`;
    logoutBtn.disabled = true;
    adminLink.classList.add('d-none');
  }
  publicationAdminBox.classList.toggle('d-none', !adminState.can_admin);
}

function renderPublications() {
  publicationList.innerHTML = '';
  const publications = Array.isArray(adminState.publications) ? adminState.publications : [];
  if (!publications.length) {
    publicationList.innerHTML = '<p class="dashboard-empty">Aucune publication structurée pour le moment.</p>';
    return;
  }
  publications.forEach(item => {
    const card = document.createElement('article');
    card.className = 'history-item';
    card.innerHTML = `<div><p class="history-title mb-1">${item.title}</p><p class="history-meta mb-1">${item.slug} · ${item.status}</p><p class="mb-0">${item.summary}</p></div>`;
    publicationList.appendChild(card);
  });
}

function renderAdminPreview() {
  const stats = adminState.stats || {};
  adminStatsPreview.innerHTML = `
    <div class="dashboard-stats-grid">
      <div class="stat-tile"><span class="stat-label">Utilisateurs</span><strong class="stat-value">${stats.users || 0}</strong></div>
      <div class="stat-tile"><span class="stat-label">Exports</span><strong class="stat-value">${stats.exports || 0}</strong></div>
      <div class="stat-tile"><span class="stat-label">Publications</span><strong class="stat-value">${stats.publications || 0}</strong></div>
      <div class="stat-tile"><span class="stat-label">Templates actifs</span><strong class="stat-value">${stats.templates_active || 0}</strong></div>
    </div>`;
}

function renderExportCatalog(files) {
  serverExportList.innerHTML = '';
  if (!files?.length) {
    serverExportList.innerHTML = '<p class="dashboard-empty">Aucun export serveur enregistré.</p>';
    return;
  }
  files.forEach(file => {
    const row = document.createElement('article');
    row.className = 'history-item';
    row.innerHTML = `<div><p class="history-title mb-1">${file.name}</p><p class="history-meta mb-0">${Math.round((file.size || 0) / 1024)} Ko · ${new Date(file.updated_at).toLocaleString('fr-FR')}</p></div><a class="btn btn-outline-light btn-sm" href="${file.url}" download>Télécharger</a>`;
    serverExportList.appendChild(row);
  });
}

async function refreshAuthAndAdmin() {
  authState = await authRequest();
  const adminData = await adminRequest();
  adminState = {
    can_admin: !!adminData.can_admin,
    stats: adminData.stats || {},
    publications: adminData.publications || [],
    templates: adminData.templates || [],
    themes: adminData.themes || [],
  };
  renderAuth();
  renderPublications();
  renderAdminPreview();
}

async function refreshExportCatalog() {
  const data = await exportRequest();
  renderExportCatalog(data.files || []);
}

function buildExportPayload() {
  const state = appState();
  const ayahData = state.currentAyah;
  if (!ayahData) throw new Error('Chargez d’abord un verset avant de lancer un export avancé.');
  return {
    surah: ayahData.surah.number,
    ayah: ayahData.ayah.number,
    surah_name: ayahData.surah.name_fr,
    surah_name_ar: ayahData.surah.name_ar,
    text_ar: ayahData.ayah.text_ar,
    translation_fr: ayahData.ayah.translation_fr || '',
    reference: `${ayahData.surah.number}:${ayahData.ayah.number}`,
    svg_markup: state.currentSvgMarkup || '',
  };
}

function openInNewTab(url) {
  window.open(url, '_blank', 'noopener');
}

async function exportDocx() {
  const payload = buildExportPayload();
  const data = await exportRequest({ action: 'docx', ...payload });
  openInNewTab(data.file_url);
  await refreshExportCatalog();
  if (qvlBridge?.pushHistory && payload.surah && payload.ayah) {
    qvlBridge.pushHistory('export', {
      surah: payload.surah,
      ayah: payload.ayah,
      reference: `${payload.surah_name} · ${payload.surah_name_ar} · ${payload.reference}`,
      surah_name: payload.surah_name,
      note: 'Export DOCX serveur'
    });
  }
  appFeedback('Export DOCX généré côté serveur.', 'success');
}

async function openPrintSheet() {
  const payload = buildExportPayload();
  const data = await exportRequest({ action: 'print_sheet', ...payload });
  openInNewTab(data.file_url);
  await refreshExportCatalog();
  appFeedback('Feuille d’impression prête. Vous pouvez l’enregistrer en PDF depuis le navigateur.', 'success');
}

async function exportPdf() {
  const state = appState();
  const ayahData = state.currentAyah;
  if (!ayahData) throw new Error('Chargez d’abord un verset avant de générer le PDF.');
  const visualMarkup = state.currentSvgMarkup;
  if (window.jspdf?.jsPDF && window.html2canvas) {
    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.left = '-9999px';
    container.style.top = '0';
    container.style.width = '1080px';
    container.style.background = '#ffffff';
    container.style.padding = '24px';
    container.style.color = '#0a1a3a';
    container.style.fontFamily = 'Inter, Arial, sans-serif';
    container.innerHTML = visualMarkup
      ? `<div>${visualMarkup}</div>`
      : `<div style="padding:24px;border:1px solid #dcc79f;border-radius:18px"><h1 style="margin:0 0 12px;font-size:28px">${ayahData.surah.name_fr} · ${ayahData.surah.name_ar}</h1><p style="font-family:Amiri, serif;font-size:38px;line-height:2;direction:rtl;text-align:right">${ayahData.ayah.text_ar}</p><p style="font-size:18px;line-height:1.7">${ayahData.ayah.translation_fr || ''}</p></div>`;
    document.body.appendChild(container);
    const canvas = await window.html2canvas(container, { scale: 2, backgroundColor: '#ffffff' });
    container.remove();
    const pdf = new window.jspdf.jsPDF({ orientation: canvas.width > canvas.height ? 'landscape' : 'portrait', unit: 'pt', format: 'a4' });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = canvas.height * imgWidth / canvas.width;
    const y = Math.max(20, (pageHeight - imgHeight) / 2);
    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 20, y, imgWidth, Math.min(imgHeight, pageHeight - 40));
    pdf.save(`qvl-${ayahData.surah.number}-${ayahData.ayah.number}.pdf`);
    appFeedback('PDF généré côté navigateur.', 'success');
    return;
  }
  await openPrintSheet();
}

async function handleLogin() {
  const login = authLoginInput.value.trim();
  const password = authPasswordInput.value;
  const data = await authRequest({ action: 'login', login, password });
  authPasswordInput.value = '';
  await refreshAuthAndAdmin();
  appFeedback(data.message, 'success');
}

async function handleRegister() {
  const payload = {
    action: 'register',
    display_name: authDisplayNameInput.value.trim(),
    username: authUsernameInput.value.trim(),
    email: authEmailInput.value.trim(),
    password: authPasswordInput.value,
  };
  const data = await authRequest(payload);
  authPasswordInput.value = '';
  await refreshAuthAndAdmin();
  appFeedback(data.message, 'success');
}

async function handleLogout() {
  const data = await authRequest({ action: 'logout' });
  await refreshAuthAndAdmin();
  appFeedback(data.message, 'success');
}

function slugify(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

publicationTitleInput?.addEventListener('input', () => {
  if (!publicationSlugInput.value.trim()) {
    publicationSlugInput.value = slugify(publicationTitleInput.value);
  }
});

savePublicationBtn?.addEventListener('click', async () => {
  try {
    const payload = {
      action: 'create_publication',
      title: publicationTitleInput.value.trim(),
      slug: publicationSlugInput.value.trim(),
      summary: publicationSummaryInput.value.trim(),
      status: publicationStatusSelect.value
    };
    const data = await adminRequest(payload);
    publicationTitleInput.value = '';
    publicationSlugInput.value = '';
    publicationSummaryInput.value = '';
    const adminData = await adminRequest();
    adminState = { ...adminState, ...{ can_admin: !!adminData.can_admin, stats: adminData.stats || {}, publications: adminData.publications || [] } };
    renderPublications();
    renderAdminPreview();
    appFeedback(data.message, 'success');
  } catch (error) {
    appFeedback(error.message, 'danger');
  }
});

loginBtn?.addEventListener('click', () => handleLogin().catch(error => appFeedback(error.message, 'danger')));
registerBtn?.addEventListener('click', () => handleRegister().catch(error => appFeedback(error.message, 'danger')));
logoutBtn?.addEventListener('click', () => handleLogout().catch(error => appFeedback(error.message, 'danger')));
exportDocxBtn?.addEventListener('click', () => exportDocx().catch(error => appFeedback(error.message, 'danger')));
exportPdfBtn?.addEventListener('click', () => exportPdf().catch(error => appFeedback(error.message, 'danger')));
printSheetBtn?.addEventListener('click', () => openPrintSheet().catch(error => appFeedback(error.message, 'danger')));
refreshExportListBtn?.addEventListener('click', () => refreshExportCatalog().catch(error => appFeedback(error.message, 'danger')));

(async function initStep7() {
  try {
    await loadMeta();
    await Promise.all([refreshAuthAndAdmin(), refreshExportCatalog()]);
  } catch (error) {
    appFeedback(error.message, 'danger');
  }
})();
