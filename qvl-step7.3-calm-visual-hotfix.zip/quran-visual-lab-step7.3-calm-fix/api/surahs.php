<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/helpers/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    qvl_json_response([
        'success' => false,
        'message' => 'Méthode non autorisée.'
    ], 405);
}

$surahsPath = qvl_path('data/surahs.json');
if (!is_file($surahsPath)) {
    qvl_json_response([
        'success' => false,
        'message' => 'Catalogue des sourates introuvable.'
    ], 500);
}

$raw = file_get_contents($surahsPath);
$data = json_decode($raw ?: '[]', true);
if (!is_array($data)) {
    qvl_json_response([
        'success' => false,
        'message' => 'Catalogue des sourates invalide.'
    ], 500);
}

qvl_json_response([
    'success' => true,
    'surahs' => $data,
]);
