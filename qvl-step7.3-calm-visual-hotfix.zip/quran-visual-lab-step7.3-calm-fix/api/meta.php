<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/helpers/bootstrap.php';
qvl_boot();
$config = qvl_config();
qvl_json_response(200, [
    'success' => true,
    'app' => [
        'name' => (string) ($config['app_name'] ?? 'QVL'),
        'sigle' => (string) ($config['app_sigle'] ?? 'QVL'),
        'version' => (string) ($config['version'] ?? '7.0.0'),
        'environment' => (string) ($config['environment'] ?? 'production-ready'),
        'base_path' => (string) ($config['base_path'] ?? '/quran-visual-lab'),
    ],
    'csrf_token' => qvl_csrf_token(),
    'health' => [
        qvl_dir_info('cache'),
        qvl_dir_info('cache/visuals'),
        qvl_dir_info('cache/progress'),
        qvl_dir_info('exports'),
        qvl_dir_info('logs'),
    ],
]);
