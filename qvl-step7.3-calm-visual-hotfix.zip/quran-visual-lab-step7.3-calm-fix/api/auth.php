<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/helpers/bootstrap.php';
qvl_boot();
$config = qvl_config();
$limit = (int) (($config['security']['auth_rate_limit']['limit'] ?? 8));
$window = (int) (($config['security']['auth_rate_limit']['window'] ?? 900));
$usersPath = qvl_path('data/users.json');
$users = qvl_load_json($usersPath);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $currentUser = qvl_current_user();
    qvl_json_response(200, [
        'success' => true,
        'authenticated' => is_array($currentUser),
        'user' => qvl_clean_user($currentUser),
        'csrf_token' => qvl_csrf_token(),
        'demo_accounts' => [
            ['username' => 'admin', 'password_hint' => 'QVL-Admin-2026'],
            ['username' => 'demo', 'password_hint' => 'QVL-Demo-2026'],
        ],
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    qvl_json_response(405, ['success' => false, 'message' => 'Utilisez GET ou POST.']);
}

qvl_rate_limit('auth', $limit, $window);
qvl_require_csrf();
$payload = $GLOBALS['qvl_request_payload'] ?? qvl_request_data();
if (!is_array($payload)) {
    qvl_json_response(422, ['success' => false, 'message' => 'Corps JSON invalide.']);
}
$action = trim((string) ($payload['action'] ?? ''));

if ($action === 'logout') {
    unset($_SESSION['qvl_user']);
    session_regenerate_id(true);
    qvl_json_response(200, ['success' => true, 'message' => 'Déconnexion effectuée.', 'csrf_token' => qvl_csrf_token()]);
}

if ($action === 'login') {
    $login = trim((string) ($payload['login'] ?? ''));
    $password = (string) ($payload['password'] ?? '');
    if ($login === '' || $password === '') {
        qvl_json_response(422, ['success' => false, 'message' => 'Identifiant et mot de passe requis.']);
    }
    foreach ($users as $user) {
        $username = (string) ($user['username'] ?? '');
        $email = (string) ($user['email'] ?? '');
        $isActive = (bool) ($user['is_active'] ?? true);
        if (!$isActive) {
            continue;
        }
        if ($login !== $username && $login !== $email) {
            continue;
        }
        if (!password_verify($password, (string) ($user['password_hash'] ?? ''))) {
            continue;
        }
        $_SESSION['qvl_user'] = $user;
        session_regenerate_id(true);
        qvl_log('auth', 'Connexion réussie', ['username' => $username]);
        qvl_json_response(200, [
            'success' => true,
            'message' => 'Connexion réussie.',
            'user' => qvl_clean_user($user),
            'csrf_token' => qvl_csrf_token(),
        ]);
    }
    qvl_log('security', 'Échec de connexion', ['login' => $login]);
    qvl_json_response(401, ['success' => false, 'message' => 'Identifiant ou mot de passe incorrect.']);
}

if ($action === 'register') {
    $username = strtolower(trim((string) ($payload['username'] ?? '')));
    $displayName = trim((string) ($payload['display_name'] ?? ''));
    $email = strtolower(trim((string) ($payload['email'] ?? '')));
    $password = (string) ($payload['password'] ?? '');

    if ($username === '' || $displayName === '' || $email === '' || $password === '') {
        qvl_json_response(422, ['success' => false, 'message' => 'Tous les champs sont requis pour créer un compte.']);
    }
    if (!preg_match('/^[a-z0-9._-]{3,24}$/', $username)) {
        qvl_json_response(422, ['success' => false, 'message' => 'Nom d’utilisateur invalide. Utilisez 3 à 24 caractères simples.']);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        qvl_json_response(422, ['success' => false, 'message' => 'Adresse e-mail invalide.']);
    }
    if (mb_strlen($password) < 8) {
        qvl_json_response(422, ['success' => false, 'message' => 'Le mot de passe doit contenir au moins 8 caractères.']);
    }
    foreach ($users as $existingUser) {
        if ($username === strtolower((string) ($existingUser['username'] ?? '')) || $email === strtolower((string) ($existingUser['email'] ?? ''))) {
            qvl_json_response(409, ['success' => false, 'message' => 'Ce nom d’utilisateur ou cet e-mail existe déjà.']);
        }
    }
    $newUser = [
        'id' => 'u_' . bin2hex(random_bytes(6)),
        'username' => $username,
        'display_name' => $displayName,
        'email' => $email,
        'role' => 'user',
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'created_at' => gmdate('c'),
        'is_active' => true,
    ];
    $users[] = $newUser;
    qvl_save_json($usersPath, $users);
    $_SESSION['qvl_user'] = $newUser;
    session_regenerate_id(true);
    qvl_log('auth', 'Inscription', ['username' => $username]);
    qvl_json_response(201, [
        'success' => true,
        'message' => 'Compte créé et connecté.',
        'user' => qvl_clean_user($newUser),
        'csrf_token' => qvl_csrf_token(),
    ]);
}

qvl_json_response(400, ['success' => false, 'message' => 'Action inconnue.']);
