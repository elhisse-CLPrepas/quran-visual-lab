<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/helpers/bootstrap.php';
qvl_boot();
$config = qvl_config();
$limit = (int) (($config['security']['write_rate_limit']['limit'] ?? 40));
$window = (int) (($config['security']['write_rate_limit']['window'] ?? 900));
$templatesPath = qvl_path('data/templates.json');
$themesPath = qvl_path('data/visual_themes.json');
$usersPath = qvl_path('data/users.json');
$publicationsPath = qvl_path('data/publications.json');
$exportsDir = qvl_path('exports');
$progressDir = qvl_path('cache/progress');
$visualDir = qvl_path('cache/visuals');
$currentUser = qvl_current_user();
$templates = qvl_load_json($templatesPath);
$themes = qvl_load_json($themesPath);
$users = qvl_load_json($usersPath);
$publications = qvl_load_json($publicationsPath);

$exportFiles = glob($exportsDir . '/*') ?: [];
$stats = [
    'users' => count($users),
    'exports' => count(array_filter($exportFiles, 'is_file')),
    'progress_files' => is_dir($progressDir) ? count(glob($progressDir . '/*.json') ?: []) : 0,
    'visual_cache_files' => is_dir($visualDir) ? count(glob($visualDir . '/*.json') ?: []) : 0,
    'publications' => count($publications),
    'templates_active' => count(array_filter($templates, static fn(array $item): bool => !empty($item['is_active']))),
    'themes_total' => count($themes),
];
$normalizedThemes = array_map(static function (array $theme): array {
    $theme['is_active'] = array_key_exists('is_active', $theme) ? (bool) $theme['is_active'] : true;
    return $theme;
}, $themes);
$health = [
    qvl_dir_info('exports'),
    qvl_dir_info('cache'),
    qvl_dir_info('cache/progress'),
    qvl_dir_info('cache/visuals'),
    qvl_dir_info('logs'),
];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    qvl_json_response(200, [
        'success' => true,
        'user' => qvl_clean_user($currentUser),
        'can_admin' => is_array($currentUser) && (string) ($currentUser['role'] ?? '') === 'admin',
        'csrf_token' => qvl_csrf_token(),
        'stats' => $stats,
        'health' => $health,
        'config' => [
            'app_name' => (string) ($config['app_name'] ?? 'QVL'),
            'version' => (string) ($config['version'] ?? '7.0.0'),
            'environment' => (string) ($config['environment'] ?? 'production-ready'),
            'base_path' => (string) ($config['base_path'] ?? '/quran-visual-lab'),
        ],
        'templates' => array_map(static fn(array $item): array => [
            'code' => (string) ($item['code'] ?? ''),
            'title' => (string) ($item['title'] ?? ''),
            'type' => (string) ($item['type'] ?? ''),
            'is_active' => (bool) ($item['is_active'] ?? false),
        ], $templates),
        'themes' => array_map(static fn(array $item): array => [
            'code' => (string) ($item['code'] ?? ''),
            'label' => (string) ($item['label'] ?? ''),
            'is_active' => (bool) ($item['is_active'] ?? true),
        ], $normalizedThemes),
        'publications' => $publications,
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    qvl_json_response(405, ['success' => false, 'message' => 'Utilisez GET ou POST.']);
}

qvl_rate_limit('admin', $limit, $window);
qvl_require_csrf();
$currentUser = qvl_require_admin();
$payload = $GLOBALS['qvl_request_payload'] ?? qvl_request_data();
if (!is_array($payload)) {
    qvl_json_response(422, ['success' => false, 'message' => 'Corps JSON invalide.']);
}
$action = trim((string) ($payload['action'] ?? ''));

if ($action === 'toggle_template') {
    $code = trim((string) ($payload['code'] ?? ''));
    $state = filter_var($payload['is_active'] ?? false, FILTER_VALIDATE_BOOLEAN);
    $updated = false;
    foreach ($templates as &$template) {
        if ((string) ($template['code'] ?? '') === $code) {
            $template['is_active'] = $state;
            $updated = true;
            break;
        }
    }
    unset($template);
    if (!$updated) {
        qvl_json_response(404, ['success' => false, 'message' => 'Template introuvable.']);
    }
    qvl_save_json($templatesPath, $templates);
    qvl_log('admin', 'Template mis à jour', ['code' => $code, 'state' => $state, 'by' => $currentUser['username'] ?? 'admin']);
    qvl_json_response(200, ['success' => true, 'message' => 'Template mis à jour.']);
}

if ($action === 'toggle_theme') {
    $code = trim((string) ($payload['code'] ?? ''));
    $state = filter_var($payload['is_active'] ?? false, FILTER_VALIDATE_BOOLEAN);
    $updated = false;
    foreach ($themes as &$theme) {
        if ((string) ($theme['code'] ?? '') === $code) {
            $theme['is_active'] = $state;
            $updated = true;
            break;
        }
    }
    unset($theme);
    if (!$updated) {
        qvl_json_response(404, ['success' => false, 'message' => 'Thème introuvable.']);
    }
    qvl_save_json($themesPath, $themes);
    qvl_log('admin', 'Thème mis à jour', ['code' => $code, 'state' => $state, 'by' => $currentUser['username'] ?? 'admin']);
    qvl_json_response(200, ['success' => true, 'message' => 'Thème mis à jour.']);
}

if ($action === 'create_publication') {
    $title = trim((string) ($payload['title'] ?? ''));
    $slug = trim((string) ($payload['slug'] ?? ''));
    $summary = trim((string) ($payload['summary'] ?? ''));
    $status = trim((string) ($payload['status'] ?? 'draft'));
    if ($title === '' || $slug === '' || $summary === '') {
        qvl_json_response(422, ['success' => false, 'message' => 'Titre, slug et résumé sont requis.']);
    }
    foreach ($publications as $publication) {
        if ((string) ($publication['slug'] ?? '') === $slug) {
            qvl_json_response(409, ['success' => false, 'message' => 'Ce slug existe déjà.']);
        }
    }
    $record = [
        'id' => 'pub-' . bin2hex(random_bytes(5)),
        'title' => $title,
        'slug' => $slug,
        'summary' => $summary,
        'author' => (string) ($currentUser['display_name'] ?? 'Administrateur QVL'),
        'status' => in_array($status, ['draft', 'published'], true) ? $status : 'draft',
        'created_at' => gmdate('c'),
        'updated_at' => gmdate('c'),
    ];
    array_unshift($publications, $record);
    qvl_save_json($publicationsPath, $publications);
    qvl_log('admin', 'Publication créée', ['slug' => $slug, 'by' => $currentUser['username'] ?? 'admin']);
    qvl_json_response(201, ['success' => true, 'message' => 'Publication enregistrée.', 'publication' => $record]);
}

qvl_json_response(400, ['success' => false, 'message' => 'Action administrateur inconnue.']);
