<?php
declare(strict_types=1);

function qvl_config(): array
{
    static $config = null;
    if (is_array($config)) {
        return $config;
    }
    $path = dirname(__DIR__, 2) . '/config/app.php';
    $config = is_file($path) ? require $path : [];
    date_default_timezone_set((string) ($config['timezone'] ?? 'UTC'));
    return is_array($config) ? $config : [];
}

function qvl_base_dir(): string
{
    return dirname(__DIR__, 2);
}

function qvl_path(string $relative = ''): string
{
    $relative = ltrim($relative, '/');
    return $relative === '' ? qvl_base_dir() : qvl_base_dir() . '/' . $relative;
}

function qvl_send_security_headers(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
}

function qvl_boot(bool $json = true): void
{
    $config = qvl_config();
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_name((string) ($config['session_name'] ?? 'QVLSESSID'));
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $https,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
    if ($json) {
        qvl_send_security_headers();
    }
    if (!isset($_SESSION['qvl_csrf_token']) || !is_string($_SESSION['qvl_csrf_token']) || strlen($_SESSION['qvl_csrf_token']) < 32) {
        $_SESSION['qvl_csrf_token'] = bin2hex(random_bytes(32));
    }
}

function qvl_json_response(int $status, array $payload): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function qvl_load_json(string $path): array
{
    if (!is_file($path)) {
        return [];
    }
    $content = file_get_contents($path);
    $decoded = json_decode((string) $content, true);
    return is_array($decoded) ? $decoded : [];
}

function qvl_save_json(string $path, array $data): bool
{
    return false !== @file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

function qvl_request_data(): array
{
    $body = json_decode((string) file_get_contents('php://input'), true);
    return is_array($body) ? $body : [];
}

function qvl_clean_user(?array $user): ?array
{
    if (!is_array($user)) {
        return null;
    }
    unset($user['password_hash']);
    return $user;
}

function qvl_current_user(): ?array
{
    $user = $_SESSION['qvl_user'] ?? null;
    return is_array($user) ? $user : null;
}

function qvl_csrf_token(): string
{
    return (string) ($_SESSION['qvl_csrf_token'] ?? '');
}

function qvl_verify_csrf(?string $token): bool
{
    $sessionToken = qvl_csrf_token();
    return $sessionToken !== '' && is_string($token) && hash_equals($sessionToken, trim($token));
}

function qvl_require_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
    if (!$token) {
        $payload = qvl_request_data();
        $token = is_string($payload['csrf_token'] ?? null) ? $payload['csrf_token'] : null;
        $GLOBALS['qvl_request_payload'] = $payload;
    }
    if (!qvl_verify_csrf($token)) {
        qvl_json_response(419, ['success' => false, 'message' => 'Jeton CSRF invalide ou absent.']);
    }
}

function qvl_require_admin(): array
{
    $user = qvl_current_user();
    if (!is_array($user) || (string) ($user['role'] ?? '') !== 'admin') {
        qvl_json_response(403, ['success' => false, 'message' => 'Accès administrateur requis.']);
    }
    return $user;
}

function qvl_ensure_dir(string $path): void
{
    if (!is_dir($path)) {
        @mkdir($path, 0775, true);
    }
}

function qvl_log(string $channel, string $message, array $context = []): void
{
    $dir = qvl_path('logs');
    qvl_ensure_dir($dir);
    $file = $dir . '/' . preg_replace('/[^a-z0-9_-]/i', '-', strtolower($channel)) . '.log';
    $line = sprintf("[%s] %s %s\n", gmdate('c'), $message, $context ? json_encode($context, JSON_UNESCAPED_UNICODE) : '');
    @file_put_contents($file, $line, FILE_APPEND);
}

function qvl_rate_limit(string $bucket, int $limit, int $windowSeconds): void
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'cli');
    $key = hash('sha256', $bucket . '|' . $ip);
    $dir = qvl_path('cache/rate-limit');
    qvl_ensure_dir($dir);
    $file = $dir . '/' . $key . '.json';
    $now = time();
    $data = qvl_load_json($file);
    $hits = array_values(array_filter($data['hits'] ?? [], static fn($timestamp): bool => is_int($timestamp) && $timestamp > ($now - $windowSeconds)));
    if (count($hits) >= $limit) {
        qvl_log('security', 'Rate limit triggered', ['bucket' => $bucket, 'ip' => $ip]);
        qvl_json_response(429, ['success' => false, 'message' => 'Trop de requêtes. Réessayez un peu plus tard.']);
    }
    $hits[] = $now;
    qvl_save_json($file, ['hits' => $hits]);
}

function qvl_dir_info(string $relative): array
{
    $path = qvl_path($relative);
    return [
        'path' => $relative,
        'exists' => file_exists($path),
        'is_writable' => is_writable($path),
    ];
}
