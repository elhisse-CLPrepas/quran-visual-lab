# Quran-Visual-Lab · Étape 7

Cette étape transforme QVL en pack premium prêt à publier sur `clprepas.com`.

## Ce que cette version ajoute

- configuration centrale `config/app.php`
- helper de sécurité `app/helpers/bootstrap.php`
- jeton CSRF pour les écritures sensibles
- limitation anti-abus simple par fichiers dans `cache/rate-limit/`
- journalisation serveur dans `logs/`
- protections `.htaccess` pour `data/`, `cache/`, `logs/`, `config/`
- `manifest.webmanifest` et `sw.js`
- `api/meta.php` pour le diagnostic du pack
- console admin premium enrichie
- branding QVL finalisé pour favicon, manifest et interface

## Déploiement conseillé

1. téléverser tout le dossier dans `/public_html/quran-visual-lab/`
2. vérifier que PHP 8 est actif
3. vérifier l’écriture sur :
   - `exports/`
   - `cache/`
   - `cache/progress/`
   - `cache/visuals/`
   - `logs/`
4. laisser les fichiers `.htaccess` en place
5. modifier les comptes de démonstration après test

## Comptes de démonstration

- `admin` / `QVL-Admin-2026`
- `demo` / `QVL-Demo-2026`

## Vérification rapide après mise en ligne

- ouvrir `index.html`
- consulter un verset
- générer un prompt
- créer un visuel
- lancer un export DOCX
- se connecter en admin
- ouvrir `admin/index.html`
- vérifier la santé du déploiement

## Fichiers nouveaux ou clés

- `.htaccess`
- `config/app.php`
- `app/helpers/bootstrap.php`
- `api/meta.php`
- `api/auth.php`
- `api/admin.php`
- `api/export.php`
- `manifest.webmanifest`
- `sw.js`
- `assets/js/step7.js`
- `admin/index.html`

## Point utile

Le pack reste fidèle à la stack V1 recommandée pour QVL : `HTML + Bootstrap + JavaScript + PHP 8 + JSON + export navigateur`.
