<?php
declare(strict_types=1);

return [
    'app_name' => 'Quran-Visual-Lab',
    'app_sigle' => 'QVL',
    'version' => '7.0.0',
    'environment' => 'production-ready',
    'base_path' => '/quran-visual-lab',
    'session_name' => 'QVLSESSID',
    'timezone' => 'Africa/Casablanca',
    'security' => [
        'auth_rate_limit' => ['limit' => 8, 'window' => 900],
        'write_rate_limit' => ['limit' => 40, 'window' => 900],
    ],
    'branding' => [
        'primary' => '#0a1a3a',
        'accent' => '#c9a96e',
        'paper' => '#f7f1e3',
        'secondary' => '#0f5c4d',
    ],
];
