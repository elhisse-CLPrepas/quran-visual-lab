# Quran-Visual-Lab · Étape 1

## Contenu livré

Cette étape pose le socle réel du projet QVL :

- structure de dossiers compatible avec `clprepas.com`
- page `index.html`
- styles `assets/css/style.css`
- logique front `assets/js/app.js`
- API locale `api/ayah.php`
- API initiale `api/prompt.php`
- données JSON de démarrage dans `data/`

## Démarrage local

1. Placez le dossier dans votre environnement local PHP.
2. Servez le projet avec Apache, XAMPP ou le serveur PHP intégré.
3. Ouvrez `index.html` depuis le dossier du projet via HTTP.

### Exemple avec PHP intégré

```bash
php -S localhost:8080
```

Puis ouvrez :

```text
http://localhost:8080/quran-visual-lab-step1/
```

## Important

Le jeu de données livré est un **jeu de démarrage**.
Il contient quelques sourates et versets de test pour lancer la structure.
La phase suivante devra intégrer :

- les 114 sourates complètes
- une source coranique locale vérifiée
- un cache plus robuste
- un export texte réel
- la génération avancée du Prompt Maître

## Prochaine étape recommandée

Étape 2 :

- enrichir `surahs.json`
- intégrer un `ayahs.json` complet ou un service API fiable
- ajouter validation avancée
- préparer le bouton export `.txt`
