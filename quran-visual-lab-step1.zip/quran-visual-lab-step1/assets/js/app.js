const form = document.getElementById('qvl-form');
const surahInput = document.getElementById('surahNumber');
const ayahInput = document.getElementById('ayahNumber');
const feedbackBox = document.getElementById('feedbackBox');
const resultPlaceholder = document.getElementById('resultPlaceholder');
const resultCard = document.getElementById('resultCard');
const surahBadge = document.getElementById('surahBadge');
const ayahBadge = document.getElementById('ayahBadge');
const revelationBadge = document.getElementById('revelationBadge');
const surahTitle = document.getElementById('surahTitle');
const surahSubtitle = document.getElementById('surahSubtitle');
const ayahArabic = document.getElementById('ayahArabic');
const ayahTranslation = document.getElementById('ayahTranslation');
const generatePromptBtn = document.getElementById('generatePromptBtn');
const copyPromptBtn = document.getElementById('copyPromptBtn');
const promptOutput = document.getElementById('promptOutput');

let currentAyah = null;

function showFeedback(message, type = 'success') {
  feedbackBox.textContent = message;
  feedbackBox.className = `alert alert-${type} mt-3 mb-0`;
  feedbackBox.classList.remove('d-none');
}

function hideFeedback() {
  feedbackBox.classList.add('d-none');
}

function resetResult() {
  currentAyah = null;
  resultCard.classList.add('d-none');
  resultPlaceholder.classList.remove('d-none');
  generatePromptBtn.disabled = true;
}

function buildPrompt(data) {
  return [
    'PROMPT MAÎTRE QVL — VERSION INITIALE',
    `Titre : Verset coranique visuel`,
    `Sourate : ${data.surah.name_fr} (${data.surah.name_ar})`,
    `Verset : ${data.ayah.number}`,
    '',
    'Texte arabe exact :',
    data.ayah.text_ar,
    '',
    'Traduction française :',
    data.ayah.translation_fr || 'Traduction non renseignée.',
    '',
    'Direction créative :',
    '- style : spirituel, premium, pédagogique',
    '- palette : bleu nuit, doré doux, ivoire, vert profond',
    '- composition : titre, référence, bloc central arabe, traduction, motif géométrique discret',
    '- respect absolu du texte coranique sans altération',
    '',
    'Objectif :',
    'Créer un support visuel propre, lisible, mobile-first, compatible publication et apprentissage.'
  ].join('\n');
}

async function fetchAyah(surah, ayah) {
  const url = `api/ayah.php?surah=${encodeURIComponent(surah)}&ayah=${encodeURIComponent(ayah)}`;
  const response = await fetch(url, {
    headers: {
      'Accept': 'application/json'
    }
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de récupérer ce verset.');
  }

  return data;
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  hideFeedback();
  promptOutput.value = '';
  copyPromptBtn.disabled = true;

  const surah = surahInput.value.trim();
  const ayah = ayahInput.value.trim();

  if (!surah || !ayah) {
    resetResult();
    showFeedback('Veuillez saisir un numéro de sourate et un numéro de verset.', 'danger');
    return;
  }

  try {
    showFeedback('Chargement du verset en cours...', 'success');
    const data = await fetchAyah(surah, ayah);
    currentAyah = data;

    surahBadge.textContent = `Sourate ${data.surah.number}`;
    ayahBadge.textContent = `Verset ${data.ayah.number}`;
    revelationBadge.textContent = data.surah.revelation_type || 'Révélation non précisée';
    surahTitle.textContent = `${data.surah.name_fr} · ${data.surah.name_ar}`;
    surahSubtitle.textContent = `${data.surah.name_en} · ${data.surah.ayah_count} versets`;
    ayahArabic.textContent = data.ayah.text_ar;
    ayahTranslation.textContent = data.ayah.translation_fr || 'Traduction non renseignée.';

    resultPlaceholder.classList.add('d-none');
    resultCard.classList.remove('d-none');
    generatePromptBtn.disabled = false;

    showFeedback('Verset récupéré avec succès.', 'success');
  } catch (error) {
    resetResult();
    showFeedback(error.message, 'danger');
  }
});

generatePromptBtn.addEventListener('click', async () => {
  if (!currentAyah) {
    showFeedback('Aucun verset n’est chargé pour le moment.', 'danger');
    return;
  }

  promptOutput.value = buildPrompt(currentAyah);
  copyPromptBtn.disabled = false;
  showFeedback('Prompt Maître initial généré.', 'success');
});

copyPromptBtn.addEventListener('click', async () => {
  if (!promptOutput.value.trim()) {
    showFeedback('Le champ du prompt est vide.', 'danger');
    return;
  }

  try {
    await navigator.clipboard.writeText(promptOutput.value);
    showFeedback('Prompt copié dans le presse-papiers.', 'success');
  } catch (error) {
    showFeedback('Copie impossible dans ce navigateur.', 'danger');
  }
});
