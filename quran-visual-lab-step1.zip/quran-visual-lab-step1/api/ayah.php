<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$surah = filter_input(INPUT_GET, 'surah', FILTER_VALIDATE_INT);
$ayah = filter_input(INPUT_GET, 'ayah', FILTER_VALIDATE_INT);

if (!$surah || !$ayah || $surah < 1 || $ayah < 1) {
    respond(422, [
        'success' => false,
        'message' => 'Les paramètres sourate et verset doivent être des entiers positifs.'
    ]);
}

$baseDir = dirname(__DIR__);
$surahsPath = $baseDir . '/data/surahs.json';
$ayahsPath = $baseDir . '/data/ayahs.json';

if (!is_file($surahsPath) || !is_file($ayahsPath)) {
    respond(500, [
        'success' => false,
        'message' => 'Les fichiers de données JSON sont introuvables.'
    ]);
}

$surahs = json_decode((string) file_get_contents($surahsPath), true);
$ayahs = json_decode((string) file_get_contents($ayahsPath), true);

if (!is_array($surahs) || !is_array($ayahs)) {
    respond(500, [
        'success' => false,
        'message' => 'Les fichiers JSON sont invalides.'
    ]);
}

$surahData = null;
foreach ($surahs as $item) {
    if ((int) ($item['number'] ?? 0) === $surah) {
        $surahData = $item;
        break;
    }
}

if ($surahData === null) {
    respond(404, [
        'success' => false,
        'message' => 'Sourate non disponible dans le jeu de données local de démarrage.'
    ]);
}

$ayahData = null;
foreach ($ayahs as $item) {
    if ((int) ($item['surah'] ?? 0) === $surah && (int) ($item['ayah'] ?? 0) === $ayah) {
        $ayahData = $item;
        break;
    }
}

if ($ayahData === null) {
    respond(404, [
        'success' => false,
        'message' => 'Verset non disponible dans le jeu de données local de démarrage.'
    ]);
}

respond(200, [
    'success' => true,
    'surah' => [
        'number' => (int) $surahData['number'],
        'name_ar' => (string) $surahData['name_ar'],
        'name_fr' => (string) $surahData['name_fr'],
        'name_en' => (string) $surahData['name_en'],
        'ayah_count' => (int) $surahData['ayah_count'],
        'revelation_type' => (string) $surahData['revelation_type'],
    ],
    'ayah' => [
        'number' => (int) $ayahData['ayah'],
        'text_ar' => (string) $ayahData['text_ar'],
        'translation_fr' => (string) $ayahData['translation_fr'],
        'transliteration' => (string) ($ayahData['transliteration'] ?? ''),
    ]
]);
