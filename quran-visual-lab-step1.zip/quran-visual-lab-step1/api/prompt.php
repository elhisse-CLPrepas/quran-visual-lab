<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Utilisez une requête POST pour générer un prompt.'
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$payload = json_decode((string) file_get_contents('php://input'), true);

if (!is_array($payload)) {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'message' => 'Corps JSON invalide.'
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$surahName = trim((string) ($payload['surah_name'] ?? ''));
$surahNameAr = trim((string) ($payload['surah_name_ar'] ?? ''));
$ayahNumber = (int) ($payload['ayah_number'] ?? 0);
$textAr = trim((string) ($payload['text_ar'] ?? ''));
$translation = trim((string) ($payload['translation_fr'] ?? ''));

if ($surahName === '' || $ayahNumber < 1 || $textAr === '') {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'message' => 'Données insuffisantes pour générer le prompt.'
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$prompt = implode("\n", [
    'PROMPT MAÎTRE QVL — API INITIALE',
    'Créer une carte visuelle pédagogique et spirituelle.',
    "Sourate : {$surahName} ({$surahNameAr})",
    "Verset : {$ayahNumber}",
    'Texte arabe exact :',
    $textAr,
    'Traduction :',
    $translation !== '' ? $translation : 'Non fournie',
    'Palette : bleu nuit, doré doux, ivoire, vert profond.',
    'Exigence : ne jamais altérer le texte coranique.'
]);

echo json_encode([
    'success' => true,
    'prompt' => $prompt
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
