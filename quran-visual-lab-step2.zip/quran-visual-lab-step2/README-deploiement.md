# Quran-Visual-Lab · Étape 2

## Contenu livré

- 114 sourates dans `data/surahs.json`
- validation automatique du nombre maximal de versets par sourate
- récupération d’un verset via `api/ayah.php`
- cache local par sourate dans `cache/`
- jeu local de secours dans `data/ayahs.json`
- génération avancée du Prompt Maître via `api/prompt.php`
- copie du verset et export `.txt`

## Déploiement

1. Déposer le dossier `quran-visual-lab-step2` dans `public_html/quran-visual-lab/` ou dans un sous-dossier de test.
2. Vérifier que PHP 8+ est actif.
3. Vérifier que le dossier `cache/` est accessible en écriture si vous voulez activer le cache de sourates.
4. Ouvrir `index.html` dans le navigateur via le serveur.

## Fonctionnement des données

- Le catalogue des 114 sourates est local.
- Lorsqu’un verset est demandé, l’API tente d’abord de lire un cache local de la sourate.
- Si le cache n’existe pas, l’API tente de récupérer la sourate depuis une API distante puis construit un cache local.
- Si la récupération distante échoue, l’API essaie le jeu local de secours.

## Points importants

- En environnement local sans accès internet, seuls les versets présents dans `data/ayahs.json` seront garantis.
- En hébergement connecté, n’importe quel verset peut être récupéré puis mis en cache.
- Ajouter `?refresh=1` à l’appel API pour forcer la reconstruction du cache d’une sourate.

## Tests rapides

- `api/ayah.php?surah=1&ayah=1`
- `api/ayah.php?surah=2&ayah=255`
- `api/ayah.php?surah=112&ayah=1`

## Étape suivante recommandée

Étape 3 : moteur de composition visuelle SVG/HTML prêt pour export PNG.
