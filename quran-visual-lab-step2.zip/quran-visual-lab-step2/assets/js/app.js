const form = document.getElementById('qvl-form');
const surahSelect = document.getElementById('surahSelect');
const ayahInput = document.getElementById('ayahNumber');
const surahHelp = document.getElementById('surahHelp');
const feedbackBox = document.getElementById('feedbackBox');
const resultPlaceholder = document.getElementById('resultPlaceholder');
const resultCard = document.getElementById('resultCard');
const surahBadge = document.getElementById('surahBadge');
const ayahBadge = document.getElementById('ayahBadge');
const revelationBadge = document.getElementById('revelationBadge');
const sourceBadge = document.getElementById('sourceBadge');
const surahTitle = document.getElementById('surahTitle');
const surahSubtitle = document.getElementById('surahSubtitle');
const ayahArabic = document.getElementById('ayahArabic');
const ayahTranslation = document.getElementById('ayahTranslation');
const generatePromptBtn = document.getElementById('generatePromptBtn');
const copyPromptBtn = document.getElementById('copyPromptBtn');
const copyAyahBtn = document.getElementById('copyAyahBtn');
const exportTxtBtn = document.getElementById('exportTxtBtn');
const promptOutput = document.getElementById('promptOutput');
const themeSelect = document.getElementById('themeSelect');
const formatSelect = document.getElementById('formatSelect');
const toneSelect = document.getElementById('toneSelect');

let surahCatalog = [];
let currentAyah = null;

function showFeedback(message, type = 'success') {
  feedbackBox.textContent = message;
  feedbackBox.className = `alert alert-${type} mt-3 mb-0`;
  feedbackBox.classList.remove('d-none');
}

function hideFeedback() {
  feedbackBox.classList.add('d-none');
}

function resetResult() {
  currentAyah = null;
  resultCard.classList.add('d-none');
  resultPlaceholder.classList.remove('d-none');
  generatePromptBtn.disabled = true;
  copyPromptBtn.disabled = true;
  copyAyahBtn.disabled = true;
  exportTxtBtn.disabled = true;
}

function getSelectedSurahMeta() {
  const surahNumber = Number(surahSelect.value || 0);
  return surahCatalog.find(item => Number(item.number) === surahNumber) || null;
}

function updateAyahLimit() {
  const meta = getSelectedSurahMeta();

  if (!meta) {
    surahHelp.textContent = 'Choisissez une sourate pour afficher le nombre maximal de versets.';
    ayahInput.removeAttribute('max');
    return;
  }

  ayahInput.max = meta.ayah_count;
  ayahInput.placeholder = `Entre 1 et ${meta.ayah_count}`;
  surahHelp.textContent = `${meta.name_fr} · ${meta.name_ar} · ${meta.ayah_count} versets · ${meta.revelation_type}`;

  if (ayahInput.value && Number(ayahInput.value) > Number(meta.ayah_count)) {
    ayahInput.value = meta.ayah_count;
  }
}

function populateSurahs(list) {
  surahSelect.innerHTML = '<option value="">Sélectionner une sourate</option>';
  list.forEach(item => {
    const option = document.createElement('option');
    option.value = item.number;
    option.textContent = `${item.number}. ${item.name_fr} · ${item.name_ar}`;
    surahSelect.appendChild(option);
  });
}

async function loadSurahs() {
  const response = await fetch('data/surahs.json', { headers: { Accept: 'application/json' } });
  const data = await response.json();
  if (!response.ok || !Array.isArray(data)) {
    throw new Error('Impossible de charger la liste des sourates.');
  }
  surahCatalog = data;
  populateSurahs(data);
}

function validateInput(surah, ayah) {
  if (!surah || !ayah) {
    return 'Veuillez choisir une sourate et saisir un numéro de verset.';
  }

  const meta = surahCatalog.find(item => Number(item.number) === Number(surah));
  if (!meta) {
    return 'La sourate choisie est invalide.';
  }

  if (Number(ayah) < 1 || Number(ayah) > Number(meta.ayah_count)) {
    return `Le verset doit être compris entre 1 et ${meta.ayah_count} pour cette sourate.`;
  }

  return '';
}

async function fetchAyah(surah, ayah) {
  const url = `api/ayah.php?surah=${encodeURIComponent(surah)}&ayah=${encodeURIComponent(ayah)}`;
  const response = await fetch(url, {
    headers: { Accept: 'application/json' }
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de récupérer ce verset.');
  }

  return data;
}

async function generatePromptFromApi() {
  if (!currentAyah) {
    throw new Error('Aucun verset n’est chargé pour le moment.');
  }

  const payload = {
    template_code: 'prompt_master_visual',
    surah_name: currentAyah.surah.name_fr,
    surah_name_ar: currentAyah.surah.name_ar,
    ayah_number: currentAyah.ayah.number,
    text_ar: currentAyah.ayah.text_ar,
    translation_fr: currentAyah.ayah.translation_fr || '',
    theme: themeSelect.value,
    output_format: formatSelect.value,
    tone: toneSelect.value
  };

  const response = await fetch('api/prompt.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || 'Impossible de générer le prompt.');
  }

  return data.prompt;
}

function renderAyah(data) {
  surahBadge.textContent = `Sourate ${data.surah.number}`;
  ayahBadge.textContent = `Verset ${data.ayah.number}`;
  revelationBadge.textContent = data.surah.revelation_type || 'Révélation non précisée';
  sourceBadge.textContent = data.meta?.source_label || 'Source non précisée';
  surahTitle.textContent = `${data.surah.name_fr} · ${data.surah.name_ar}`;
  surahSubtitle.textContent = `${data.surah.name_en} · ${data.surah.ayah_count} versets`;
  ayahArabic.textContent = data.ayah.text_ar;
  ayahTranslation.textContent = data.ayah.translation_fr || 'Traduction non renseignée.';

  resultPlaceholder.classList.add('d-none');
  resultCard.classList.remove('d-none');
  generatePromptBtn.disabled = false;
  copyAyahBtn.disabled = false;
  exportTxtBtn.disabled = false;
}

function getAyahPlainText() {
  if (!currentAyah) {
    return '';
  }

  return [
    `${currentAyah.surah.name_fr} (${currentAyah.surah.name_ar})`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    '',
    currentAyah.ayah.text_ar,
    '',
    currentAyah.ayah.translation_fr || 'Traduction non renseignée.'
  ].join('\n');
}

function exportCurrentTxt() {
  if (!currentAyah) {
    return;
  }

  const lines = [
    'Quran-Visual-Lab · Export texte',
    `${currentAyah.surah.name_fr} (${currentAyah.surah.name_ar})`,
    `Sourate ${currentAyah.surah.number} · Verset ${currentAyah.ayah.number}`,
    `Source : ${currentAyah.meta?.source_label || 'non précisée'}`,
    '',
    'Texte arabe :',
    currentAyah.ayah.text_ar,
    '',
    'Traduction française :',
    currentAyah.ayah.translation_fr || 'Traduction non renseignée.',
    '',
    'Prompt Maître :',
    promptOutput.value.trim() || 'Non généré'
  ];

  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `qvl-s${currentAyah.surah.number}-v${currentAyah.ayah.number}.txt`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  hideFeedback();
  promptOutput.value = '';
  copyPromptBtn.disabled = true;

  const surah = surahSelect.value.trim();
  const ayah = ayahInput.value.trim();
  const validationError = validateInput(surah, ayah);

  if (validationError) {
    resetResult();
    showFeedback(validationError, 'danger');
    return;
  }

  try {
    showFeedback('Chargement du verset en cours...', 'success');
    const data = await fetchAyah(surah, ayah);
    currentAyah = data;
    renderAyah(data);
    showFeedback('Verset récupéré avec succès.', 'success');
  } catch (error) {
    resetResult();
    showFeedback(error.message, 'danger');
  }
});

generatePromptBtn.addEventListener('click', async () => {
  try {
    const prompt = await generatePromptFromApi();
    promptOutput.value = prompt;
    copyPromptBtn.disabled = false;
    showFeedback('Prompt Maître avancé généré.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
});

copyPromptBtn.addEventListener('click', async () => {
  if (!promptOutput.value.trim()) {
    showFeedback('Le champ du prompt est vide.', 'danger');
    return;
  }

  try {
    await navigator.clipboard.writeText(promptOutput.value);
    showFeedback('Prompt copié dans le presse-papiers.', 'success');
  } catch (error) {
    showFeedback('Copie impossible dans ce navigateur.', 'danger');
  }
});

copyAyahBtn.addEventListener('click', async () => {
  const text = getAyahPlainText();
  if (!text) {
    showFeedback('Aucun verset à copier.', 'danger');
    return;
  }

  try {
    await navigator.clipboard.writeText(text);
    showFeedback('Verset copié dans le presse-papiers.', 'success');
  } catch (error) {
    showFeedback('Copie impossible dans ce navigateur.', 'danger');
  }
});

exportTxtBtn.addEventListener('click', () => {
  exportCurrentTxt();
  showFeedback('Export TXT déclenché.', 'success');
});

surahSelect.addEventListener('change', updateAyahLimit);

document.querySelectorAll('.chip-btn').forEach(button => {
  button.addEventListener('click', () => {
    surahSelect.value = button.dataset.surah;
    updateAyahLimit();
    ayahInput.value = button.dataset.ayah;
    form.requestSubmit();
  });
});

(async function init() {
  try {
    await loadSurahs();
    updateAyahLimit();
    showFeedback('QVL Étape 2 prêt. Vous pouvez consulter n’importe quelle sourate.', 'success');
  } catch (error) {
    showFeedback(error.message, 'danger');
  }
})();
