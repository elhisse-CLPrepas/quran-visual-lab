# Plan de retour arrière QVL

En cas de problème après mise en ligne :

1. renommer le dossier courant en `quran-visual-lab_failed_DATE`
2. restaurer le dossier précédent `quran-visual-lab_backup_DATE` en `quran-visual-lab`
3. vérifier immédiatement :
   - page d'accueil
   - API meta
   - admin
4. conserver les logs de la version échouée pour diagnostic

Ne jamais écraser la sauvegarde précédente avant validation complète de la nouvelle version.
