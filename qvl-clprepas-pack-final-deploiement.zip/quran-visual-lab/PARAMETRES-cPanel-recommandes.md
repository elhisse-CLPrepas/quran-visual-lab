# Paramètres cPanel recommandés pour QVL

## Domaine
- domaine : `clprepas.com`
- répertoire cible : `/public_html/quran-visual-lab/`

## PHP
- version recommandée : PHP 8.x
- extensions utiles côté hébergement : JSON, mbstring, session, openssl, zip

## Permissions conseillées
- dossiers : 0755
- fichiers : 0644
- dossiers d'écriture : 0775 seulement si nécessaire

## Dossiers à protéger
- `config/`
- `data/`
- `cache/`
- `logs/`

## Dossiers à surveiller
- `exports/`
- `cache/progress/`
- `cache/visuals/`
- `cache/rate-limit/`
