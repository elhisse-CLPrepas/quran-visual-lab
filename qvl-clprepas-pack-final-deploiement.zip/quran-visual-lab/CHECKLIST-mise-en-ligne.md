# Checklist QVL · Mise en ligne

## Avant upload
- [ ] Le ZIP final est présent
- [ ] La sauvegarde de l'ancienne version existe
- [ ] La version PHP 8.x est disponible sur le domaine
- [ ] Le dossier cible est `/public_html/quran-visual-lab/`

## Après extraction
- [ ] `index.html` existe
- [ ] `api/meta.php` répond
- [ ] `admin/index.html` s'ouvre
- [ ] Les fichiers `.htaccess` sont en place
- [ ] Les dossiers `exports/`, `cache/`, `logs/` sont écrivable si nécessaire

## Tests fonctionnels
- [ ] Consultation d'un verset
- [ ] Génération de prompt
- [ ] Création visuelle
- [ ] Audio
- [ ] Learning Lab
- [ ] Dashboard
- [ ] Connexion admin
- [ ] Export TXT
- [ ] Export DOCX
- [ ] Feuille d'impression PDF

## Après validation
- [ ] Changement des mots de passe de démonstration
- [ ] Sauvegarde de la version déployée
- [ ] Nettoyage des anciens ZIP du serveur
