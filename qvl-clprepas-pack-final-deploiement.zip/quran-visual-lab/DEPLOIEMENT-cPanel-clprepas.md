# QVL · Déploiement final sur cPanel / clprepas.com

Ce guide s'applique au pack `quran-visual-lab/` prêt à déposer dans :

`/public_html/quran-visual-lab/`

## 1. Contenu du pack

Le dossier contient déjà :
- l'application QVL
- l'interface publique
- l'espace admin
- les API PHP
- les fichiers JSON de données
- les protections `.htaccess`
- le manifest et le service worker
- les dossiers d'écriture : `exports/`, `cache/`, `logs/`

## 2. Préparation côté cPanel

Avant l'envoi :
1. ouvrez **MultiPHP Manager**
2. sélectionnez le domaine `clprepas.com`
3. choisissez une version PHP 8.x disponible
4. appliquez la version

Ensuite, dans **File Manager** :
1. ouvrez `public_html`
2. activez l'affichage des fichiers cachés
3. vérifiez qu'aucun ancien dossier `quran-visual-lab` ne bloque le nouveau déploiement

## 3. Sauvegarde avant remplacement

Si une ancienne version existe :
1. renommez le dossier existant en `quran-visual-lab_backup_DATE`
2. ou compressez l'ancien dossier en ZIP depuis cPanel
3. gardez cette sauvegarde tant que la nouvelle version n'est pas validée

## 4. Mise en ligne pas à pas

### Méthode A — recommandée
1. téléversez le fichier ZIP final dans `/public_html/`
2. sélectionnez le ZIP dans **File Manager**
3. cliquez **Extract**
4. vérifiez que le dossier extrait est bien :

`/public_html/quran-visual-lab/`

5. supprimez le ZIP si l'extraction est correcte

### Méthode B — manuelle
1. créez le dossier `quran-visual-lab`
2. envoyez les sous-dossiers un par un
3. gardez exactement cette arborescence :
   - `api/`
   - `app/`
   - `assets/`
   - `cache/`
   - `config/`
   - `data/`
   - `exports/`
   - `logs/`
   - `admin/`

## 5. Permissions à vérifier

Réglage simple recommandé :
- dossiers : `0755`
- fichiers : `0644`

Dossiers qui doivent être écrivable par l'application :
- `exports/`
- `cache/`
- `cache/progress/`
- `cache/visuals/`
- `cache/rate-limit/`
- `logs/`

Si l'hébergement l'exige, passez uniquement ces dossiers d'écriture en `0775`.

## 6. Contrôle de configuration

Ouvrez :
- `https://clprepas.com/quran-visual-lab/`
- `https://clprepas.com/quran-visual-lab/admin/`
- `https://clprepas.com/quran-visual-lab/api/meta.php`

Puis vérifiez :
- page d'accueil visible
- aucun caractère arabe cassé
- API meta répond en JSON
- authentification possible
- génération de prompt fonctionnelle
- export DOCX/TXT fonctionnel

## 7. Comptes de démonstration à changer

Après test, remplacez immédiatement les comptes fournis :
- `admin / QVL-Admin-2026`
- `demo / QVL-Demo-2026`

Le fichier à modifier est :
`data/users.json`

## 8. Fichiers sensibles à conserver tels quels

Ne supprimez pas :
- `.htaccess`
- `config/.htaccess`
- `data/.htaccess`
- `cache/.htaccess`
- `logs/.htaccess`

Ils protègent les fichiers internes et l'accès direct aux données.

## 9. Première recette de validation

1. consulter `1:1`
2. générer un prompt
3. créer un visuel
4. lancer un export `.txt`
5. lancer un export `.docx`
6. ouvrir l'admin
7. mettre à jour un template
8. vérifier la création d'un log

## 10. Après mise en production

À faire le jour même :
- modifier les mots de passe de démonstration
- vider le cache navigateur puis retester
- vérifier la version mobile
- contrôler le service worker
- faire une sauvegarde de la version publiée validée

## 11. Point d'attention

Le projet QVL repose sur :
- texte arabe fidèle
- validation serveur
- cache local
- stack V1 simple : HTML + Bootstrap + JavaScript + PHP 8 + JSON

Ne changez pas la structure sans tester les API et les chemins.
