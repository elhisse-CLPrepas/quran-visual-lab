<?php
declare(strict_types=1);

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function loadJsonFile(string $path): array
{
    if (!is_file($path)) {
        return [];
    }
    $content = file_get_contents($path);
    $decoded = json_decode((string) $content, true);
    return is_array($decoded) ? $decoded : [];
}

function saveJsonFile(string $path, array $data): bool
{
    return false !== @file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

function sanitizeUser(array $user): array
{
    unset($user['password_hash']);
    return $user;
}

$baseDir = dirname(__DIR__);
$usersPath = $baseDir . '/data/users.json';
$users = loadJsonFile($usersPath);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $currentUser = $_SESSION['qvl_user'] ?? null;
    respond(200, [
        'success' => true,
        'authenticated' => is_array($currentUser),
        'user' => is_array($currentUser) ? sanitizeUser($currentUser) : null,
        'demo_accounts' => [
            ['username' => 'admin', 'password_hint' => 'QVL-Admin-2026'],
            ['username' => 'demo', 'password_hint' => 'QVL-Demo-2026'],
        ],
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, ['success' => false, 'message' => 'Utilisez GET ou POST.']);
}

$payload = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($payload)) {
    respond(422, ['success' => false, 'message' => 'Corps JSON invalide.']);
}

$action = trim((string) ($payload['action'] ?? ''));

if ($action === 'logout') {
    unset($_SESSION['qvl_user']);
    session_regenerate_id(true);
    respond(200, ['success' => true, 'message' => 'Déconnexion effectuée.']);
}

if ($action === 'login') {
    $login = trim((string) ($payload['login'] ?? ''));
    $password = (string) ($payload['password'] ?? '');
    if ($login === '' || $password === '') {
        respond(422, ['success' => false, 'message' => 'Identifiant et mot de passe requis.']);
    }

    foreach ($users as $user) {
        $username = (string) ($user['username'] ?? '');
        $email = (string) ($user['email'] ?? '');
        $isActive = (bool) ($user['is_active'] ?? true);
        if (!$isActive) {
            continue;
        }
        if ($login !== $username && $login !== $email) {
            continue;
        }
        if (!password_verify($password, (string) ($user['password_hash'] ?? ''))) {
            continue;
        }
        $_SESSION['qvl_user'] = $user;
        session_regenerate_id(true);
        respond(200, [
            'success' => true,
            'message' => 'Connexion réussie.',
            'user' => sanitizeUser($user),
        ]);
    }

    respond(401, ['success' => false, 'message' => 'Identifiant ou mot de passe incorrect.']);
}

if ($action === 'register') {
    $username = strtolower(trim((string) ($payload['username'] ?? '')));
    $displayName = trim((string) ($payload['display_name'] ?? ''));
    $email = strtolower(trim((string) ($payload['email'] ?? '')));
    $password = (string) ($payload['password'] ?? '');

    if ($username === '' || $displayName === '' || $email === '' || $password === '') {
        respond(422, ['success' => false, 'message' => 'Tous les champs sont requis pour créer un compte.']);
    }

    if (!preg_match('/^[a-z0-9._-]{3,24}$/', $username)) {
        respond(422, ['success' => false, 'message' => 'Nom d’utilisateur invalide. Utilisez 3 à 24 caractères simples.']);
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        respond(422, ['success' => false, 'message' => 'Adresse e-mail invalide.']);
    }

    if (mb_strlen($password) < 6) {
        respond(422, ['success' => false, 'message' => 'Le mot de passe doit contenir au moins 6 caractères.']);
    }

    foreach ($users as $existingUser) {
        if ($username === strtolower((string) ($existingUser['username'] ?? '')) || $email === strtolower((string) ($existingUser['email'] ?? ''))) {
            respond(409, ['success' => false, 'message' => 'Ce nom d’utilisateur ou cet e-mail existe déjà.']);
        }
    }

    $newUser = [
        'id' => 'u_' . bin2hex(random_bytes(6)),
        'username' => $username,
        'display_name' => $displayName,
        'email' => $email,
        'role' => 'user',
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'created_at' => gmdate('c'),
        'is_active' => true,
    ];
    $users[] = $newUser;
    saveJsonFile($usersPath, $users);
    $_SESSION['qvl_user'] = $newUser;
    session_regenerate_id(true);

    respond(201, [
        'success' => true,
        'message' => 'Compte créé et connecté.',
        'user' => sanitizeUser($newUser),
    ]);
}

respond(400, ['success' => false, 'message' => 'Action inconnue.']);
