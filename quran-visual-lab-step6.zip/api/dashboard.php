<?php

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
function respond(int $statusCode, array $payload): void { http_response_code($statusCode); echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); exit; }
function loadJsonFile(string $path): array { if (!is_file($path)) return []; $content = file_get_contents($path); $decoded = json_decode((string) $content, true); return is_array($decoded) ? $decoded : []; }
function buildVerseMap(array $surahs, array $ayahs): array {
    $surahMap = []; foreach ($surahs as $surah) { $surahMap[(int) ($surah['number'] ?? 0)] = $surah; }
    $result = []; foreach ($ayahs as $ayah) { $surahNumber = (int) ($ayah['surah'] ?? 0); $ayahNumber = (int) ($ayah['ayah'] ?? 0); if ($surahNumber < 1 || $ayahNumber < 1) continue; $surahMeta = $surahMap[$surahNumber] ?? []; $result[] = ['surah'=>$surahNumber,'ayah'=>$ayahNumber,'reference'=>sprintf('%s · %s · %d:%d',(string) ($surahMeta['name_fr'] ?? ('Sourate ' . $surahNumber)),(string) ($surahMeta['name_ar'] ?? ''),$surahNumber,$ayahNumber),'theme'=>(string) ($ayah['theme'] ?? 'méditation'),'text_ar'=>(string) ($ayah['text_ar'] ?? ''),'translation_fr'=>(string) ($ayah['translation_fr'] ?? '')]; }
    return $result;
}
$baseDir = dirname(__DIR__);
$surahs = loadJsonFile($baseDir . '/data/surahs.json');
$ayahs = loadJsonFile($baseDir . '/data/ayahs.json');
$series = loadJsonFile($baseDir . '/data/community_series.json');
$teacherSpace = loadJsonFile($baseDir . '/data/teacher_space.json');
$progressDir = $baseDir . '/cache/progress';
$visualDir = $baseDir . '/cache/visuals';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') respond(405, ['success'=>false,'message'=>'Utilisez GET pour le tableau de bord QVL.']);
$sessionId = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($_GET['session_id'] ?? 'guest')) ?: 'guest';
$daySeed = (string) ($_GET['day'] ?? gmdate('Y-m-d'));
$versePool = buildVerseMap($surahs, $ayahs);
if (!$versePool) respond(500, ['success'=>false,'message'=>'Aucun verset local disponible pour alimenter le dashboard.']);
$index = abs(crc32($daySeed)) % count($versePool);
$verseOfDay = $versePool[$index];
$snapshotFile = $progressDir . '/' . $sessionId . '.json';
$snapshot = loadJsonFile($snapshotFile); if ($snapshot) { $snapshot['progress_count'] = is_array($snapshot['progress'] ?? null) ? count($snapshot['progress']) : 0; }
$visualCount = is_dir($visualDir) ? max(0, count(glob($visualDir . '/*.json') ?: [])) : 0;
$progressCount = is_dir($progressDir) ? max(0, count(glob($progressDir . '/*.json') ?: [])) : 0;
respond(200, ['success'=>true,'verse_of_day'=>$verseOfDay,'series'=>$series,'teacher_space'=>$teacherSpace,'snapshot'=>$snapshot ?: null,'stats'=>['visual_cache_files'=>$visualCount,'progress_files'=>$progressCount,'series_count'=>is_array($series) ? count($series) : 0]]);
