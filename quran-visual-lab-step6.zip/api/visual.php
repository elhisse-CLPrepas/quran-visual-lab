<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function loadJsonFile(string $path): array
{
    if (!is_file($path)) {
        return [];
    }

    $content = file_get_contents($path);
    $decoded = json_decode((string) $content, true);

    return is_array($decoded) ? $decoded : [];
}

function findTheme(array $themes, string $code): ?array
{
    foreach ($themes as $theme) {
        if ((string) ($theme['code'] ?? '') === $code) {
            return $theme;
        }
    }

    return null;
}

function formatCatalog(): array
{
    return [
        'square' => [
            'code' => 'square',
            'label' => 'Carré 1080×1080',
            'width' => 1080,
            'height' => 1080,
        ],
        'story' => [
            'code' => 'story',
            'label' => 'Story 1080×1920',
            'width' => 1080,
            'height' => 1920,
        ],
        'landscape' => [
            'code' => 'landscape',
            'label' => 'Paysage 1600×900',
            'width' => 1600,
            'height' => 900,
        ],
        'a4' => [
            'code' => 'a4',
            'label' => 'A4 pédagogique',
            'width' => 1240,
            'height' => 1754,
        ],
    ];
}

$baseDir = dirname(__DIR__);
$themesPath = $baseDir . '/data/visual_themes.json';
$themes = loadJsonFile($themesPath);
$formats = formatCatalog();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    respond(200, [
        'success' => true,
        'themes' => $themes,
        'formats' => $formats,
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, [
        'success' => false,
        'message' => 'Utilisez GET pour le catalogue ou POST pour construire un visuel.'
    ]);
}

$payload = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($payload)) {
    respond(422, [
        'success' => false,
        'message' => 'Corps JSON invalide.'
    ]);
}

$surah = (int) ($payload['surah'] ?? 0);
$ayah = (int) ($payload['ayah'] ?? 0);
$surahName = trim((string) ($payload['surah_name'] ?? ''));
$surahNameAr = trim((string) ($payload['surah_name_ar'] ?? ''));
$textAr = trim((string) ($payload['text_ar'] ?? ''));
$translation = trim((string) ($payload['translation_fr'] ?? ''));
$formatCode = trim((string) ($payload['format'] ?? ($payload['format_code'] ?? 'square')));
$themeCode = trim((string) ($payload['theme'] ?? ($payload['theme_code'] ?? 'night_gold')));
$ornament = trim((string) ($payload['ornament'] ?? ($payload['ornament_code'] ?? 'geometry')));
$signature = trim((string) ($payload['signature'] ?? 'QVL · Club Tiriens Maroc'));
$showReference = filter_var($payload['show_reference'] ?? true, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
$showTranslation = filter_var($payload['show_translation'] ?? true, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
$showBrand = filter_var($payload['show_brand'] ?? true, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

if ($surah < 1 || $ayah < 1 || $surahName === '' || $surahNameAr === '' || $textAr === '') {
    respond(422, [
        'success' => false,
        'message' => 'Données insuffisantes pour composer le visuel.'
    ]);
}

if (!isset($formats[$formatCode])) {
    respond(422, [
        'success' => false,
        'message' => 'Format visuel invalide.'
    ]);
}

$theme = findTheme($themes, $themeCode);
$activeTheme = array_key_exists('is_active', $theme ?? []) ? (bool) ($theme['is_active'] ?? true) : true;
if ($theme === null) {
    respond(422, [
        'success' => false,
        'message' => 'Thème graphique introuvable.'
    ]);
}

if (!$activeTheme) {
    respond(422, [
        'success' => false,
        'message' => 'Ce thème graphique est désactivé par l’administration QVL.'
    ]);
}

$ornamentLabels = [
    'geometry' => 'Motif géométrique',
    'mihrab' => 'Arc mihrab',
    'rays' => 'Rayons lumineux',
    'minimal' => 'Minimal',
];

$reference = sprintf('Sourate %d · Verset %d', $surah, $ayah);
$exportBase = sprintf('qvl-card-s%03d-v%03d-%s-%s', $surah, $ayah, $formatCode, $themeCode);

$visualConfig = [
    'surah' => $surah,
    'ayah' => $ayah,
    'surah_name' => $surahName,
    'surah_name_ar' => $surahNameAr,
    'revelation_type' => trim((string) ($payload['revelation_type'] ?? '')),
    'text_ar' => $textAr,
    'translation_fr' => $translation,
    'reference' => $reference,
    'format' => $formats[$formatCode],
    'theme' => $theme,
    'ornament' => $ornament,
    'ornament_label' => $ornamentLabels[$ornament] ?? 'Motif géométrique',
    'signature' => $signature !== '' ? $signature : 'QVL · Club Tiriens Maroc',
    'show_reference' => $showReference !== false,
    'show_translation' => $showTranslation !== false,
    'show_brand' => $showBrand !== false,
    'export_base' => $exportBase,
    'generated_at' => gmdate('c'),
];

$cacheDir = $baseDir . '/cache/visuals';
if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0775, true);
}

$cacheKey = md5(json_encode($visualConfig, JSON_UNESCAPED_UNICODE));
$cachePath = $cacheDir . '/' . $cacheKey . '.json';
@file_put_contents($cachePath, json_encode($visualConfig, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

respond(200, [
    'success' => true,
    'visual' => $visualConfig,
    'visual_config' => $visualConfig,
    'cache_path' => basename($cachePath),
]);
