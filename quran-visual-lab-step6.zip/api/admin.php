<?php
declare(strict_types=1);

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
function loadJsonFile(string $path): array
{
    if (!is_file($path)) return [];
    $content = file_get_contents($path);
    $decoded = json_decode((string) $content, true);
    return is_array($decoded) ? $decoded : [];
}
function saveJsonFile(string $path, array $data): bool
{
    return false !== @file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}
function sanitizeUser(?array $user): ?array
{
    if (!is_array($user)) return null;
    unset($user['password_hash']);
    return $user;
}
function requireAdmin(?array $user): void
{
    if (!is_array($user) || (string) ($user['role'] ?? '') !== 'admin') {
        respond(403, ['success' => false, 'message' => 'Accès administrateur requis.']);
    }
}

$baseDir = dirname(__DIR__);
$templatesPath = $baseDir . '/data/templates.json';
$themesPath = $baseDir . '/data/visual_themes.json';
$usersPath = $baseDir . '/data/users.json';
$publicationsPath = $baseDir . '/data/publications.json';
$exportsDir = $baseDir . '/exports';
$progressDir = $baseDir . '/cache/progress';
$visualDir = $baseDir . '/cache/visuals';

$currentUser = $_SESSION['qvl_user'] ?? null;
$templates = loadJsonFile($templatesPath);
$themes = loadJsonFile($themesPath);
$users = loadJsonFile($usersPath);
$publications = loadJsonFile($publicationsPath);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $exportFiles = glob($exportsDir . '/*') ?: [];
    $stats = [
        'users' => count($users),
        'exports' => count(array_filter($exportFiles, 'is_file')),
        'progress_files' => is_dir($progressDir) ? count(glob($progressDir . '/*.json') ?: []) : 0,
        'visual_cache_files' => is_dir($visualDir) ? count(glob($visualDir . '/*.json') ?: []) : 0,
        'publications' => count($publications),
        'templates_active' => count(array_filter($templates, static fn(array $item): bool => !empty($item['is_active']))),
        'themes_total' => count($themes),
    ];

    $normalizedThemes = array_map(static function (array $theme): array {
        $theme['is_active'] = array_key_exists('is_active', $theme) ? (bool) $theme['is_active'] : true;
        return $theme;
    }, $themes);

    respond(200, [
        'success' => true,
        'user' => sanitizeUser($currentUser),
        'can_admin' => is_array($currentUser) && (string) ($currentUser['role'] ?? '') === 'admin',
        'stats' => $stats,
        'templates' => array_map(static fn(array $item): array => [
            'code' => (string) ($item['code'] ?? ''),
            'title' => (string) ($item['title'] ?? ''),
            'type' => (string) ($item['type'] ?? ''),
            'is_active' => (bool) ($item['is_active'] ?? false),
        ], $templates),
        'themes' => array_map(static fn(array $item): array => [
            'code' => (string) ($item['code'] ?? ''),
            'label' => (string) ($item['label'] ?? ''),
            'is_active' => (bool) ($item['is_active'] ?? true),
        ], $normalizedThemes),
        'publications' => $publications,
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, ['success' => false, 'message' => 'Utilisez GET ou POST.']);
}

$payload = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($payload)) {
    respond(422, ['success' => false, 'message' => 'Corps JSON invalide.']);
}

$action = trim((string) ($payload['action'] ?? ''));
requireAdmin($currentUser);

if ($action === 'toggle_template') {
    $code = trim((string) ($payload['code'] ?? ''));
    $state = filter_var($payload['is_active'] ?? false, FILTER_VALIDATE_BOOLEAN);
    $updated = false;
    foreach ($templates as &$template) {
        if ((string) ($template['code'] ?? '') === $code) {
            $template['is_active'] = $state;
            $updated = true;
            break;
        }
    }
    unset($template);
    if (!$updated) {
        respond(404, ['success' => false, 'message' => 'Template introuvable.']);
    }
    saveJsonFile($templatesPath, $templates);
    respond(200, ['success' => true, 'message' => 'Template mis à jour.']);
}

if ($action === 'toggle_theme') {
    $code = trim((string) ($payload['code'] ?? ''));
    $state = filter_var($payload['is_active'] ?? false, FILTER_VALIDATE_BOOLEAN);
    $updated = false;
    foreach ($themes as &$theme) {
        if ((string) ($theme['code'] ?? '') === $code) {
            $theme['is_active'] = $state;
            $updated = true;
            break;
        }
    }
    unset($theme);
    if (!$updated) {
        respond(404, ['success' => false, 'message' => 'Thème introuvable.']);
    }
    saveJsonFile($themesPath, $themes);
    respond(200, ['success' => true, 'message' => 'Thème mis à jour.']);
}

if ($action === 'create_publication') {
    $title = trim((string) ($payload['title'] ?? ''));
    $slug = trim((string) ($payload['slug'] ?? ''));
    $summary = trim((string) ($payload['summary'] ?? ''));
    $status = trim((string) ($payload['status'] ?? 'draft'));
    if ($title === '' || $slug === '' || $summary === '') {
        respond(422, ['success' => false, 'message' => 'Titre, slug et résumé sont requis.']);
    }
    foreach ($publications as $publication) {
        if ((string) ($publication['slug'] ?? '') === $slug) {
            respond(409, ['success' => false, 'message' => 'Ce slug existe déjà.']);
        }
    }
    $record = [
        'id' => 'pub-' . bin2hex(random_bytes(5)),
        'title' => $title,
        'slug' => $slug,
        'summary' => $summary,
        'author' => (string) ($currentUser['display_name'] ?? 'Administrateur QVL'),
        'status' => in_array($status, ['draft', 'published'], true) ? $status : 'draft',
        'created_at' => gmdate('c'),
        'updated_at' => gmdate('c'),
    ];
    array_unshift($publications, $record);
    saveJsonFile($publicationsPath, $publications);
    respond(201, ['success' => true, 'message' => 'Publication enregistrée.', 'publication' => $record]);
}

respond(400, ['success' => false, 'message' => 'Action administrateur inconnue.']);
