<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function ensureDir(string $path): void
{
    if (!is_dir($path)) {
        @mkdir($path, 0775, true);
    }
}

function sanitizeFilename(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9_-]+/i', '-', $value) ?? 'qvl-export';
    $value = trim($value, '-');
    return $value !== '' ? $value : 'qvl-export';
}

function xmlSafe(string $value): string
{
    return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
}

function buildDocx(string $targetPath, string $title, array $lines): bool
{
    $documentParagraphs = '';
    foreach ($lines as $line) {
        $rtl = preg_match('/[\x{0600}-\x{06FF}]/u', $line) === 1;
        $safeLine = xmlSafe($line !== '' ? $line : ' ');
        if ($rtl) {
            $documentParagraphs .= '<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:rtl/></w:rPr><w:t xml:space="preserve">' . $safeLine . '</w:t></w:r></w:p>';
        } else {
            $documentParagraphs .= '<w:p><w:r><w:t xml:space="preserve">' . $safeLine . '</w:t></w:r></w:p>';
        }
    }

    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
        . '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
        . '</Types>';

    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
        . '</Relationships>';

    $document = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" '
        . 'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
        . 'xmlns:o="urn:schemas-microsoft-com:office:office" '
        . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        . 'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
        . 'xmlns:v="urn:schemas-microsoft-com:vml" '
        . 'xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" '
        . 'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
        . 'xmlns:w10="urn:schemas-microsoft-com:office:word" '
        . 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        . 'xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" '
        . 'xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" '
        . 'xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" '
        . 'xmlns:wne="http://schemas.microsoft.com/office/2006/wordml" '
        . 'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">'
        . '<w:body>'
        . '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">' . xmlSafe($title) . '</w:t></w:r></w:p>'
        . $documentParagraphs
        . '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>'
        . '</w:body></w:document>';

    $core = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        . 'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
        . 'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        . '<dc:title>' . xmlSafe($title) . '</dc:title>'
        . '<dc:creator>Quran-Visual-Lab</dc:creator>'
        . '<cp:lastModifiedBy>Quran-Visual-Lab</cp:lastModifiedBy>'
        . '<dcterms:created xsi:type="dcterms:W3CDTF">' . gmdate('c') . '</dcterms:created>'
        . '<dcterms:modified xsi:type="dcterms:W3CDTF">' . gmdate('c') . '</dcterms:modified>'
        . '</cp:coreProperties>';

    $app = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        . 'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        . '<Application>Quran-Visual-Lab</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop>'
        . '</Properties>';

    $files = [
        '[Content_Types].xml' => $contentTypes,
        '_rels/.rels' => $rels,
        'word/document.xml' => $document,
        'docProps/core.xml' => $core,
        'docProps/app.xml' => $app,
    ];

    $zipData = '';
    $centralDirectory = '';
    $offset = 0;

    foreach ($files as $name => $data) {
        $crc = crc32($data);
        $size = strlen($data);
        $nameLength = strlen($name);

        $localHeader = pack('VvvvvvVVVvv',
            0x04034b50,
            20,
            0,
            0,
            0,
            0,
            $crc,
            $size,
            $size,
            $nameLength,
            0
        );

        $zipData .= $localHeader . $name . $data;

        $centralDirectory .= pack('VvvvvvvVVVvvvvvVV',
            0x02014b50,
            20,
            20,
            0,
            0,
            0,
            0,
            $crc,
            $size,
            $size,
            $nameLength,
            0,
            0,
            0,
            0,
            0,
            $offset
        ) . $name;

        $offset += strlen($localHeader) + $nameLength + $size;
    }

    $endRecord = pack('VvvvvVVv',
        0x06054b50,
        0,
        0,
        count($files),
        count($files),
        strlen($centralDirectory),
        strlen($zipData),
        0
    );

    return false !== @file_put_contents($targetPath, $zipData . $centralDirectory . $endRecord);
}

$baseDir = dirname(__DIR__);
$exportsDir = $baseDir . '/exports';
ensureDir($exportsDir);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $files = glob($exportsDir . '/*') ?: [];
    usort($files, static fn(string $a, string $b): int => filemtime($b) <=> filemtime($a));
    $catalog = [];
    foreach (array_slice($files, 0, 20) as $file) {
        if (!is_file($file)) {
            continue;
        }
        $catalog[] = [
            'name' => basename($file),
            'size' => filesize($file),
            'updated_at' => gmdate('c', (int) filemtime($file)),
            'url' => '../exports/' . rawurlencode(basename($file)),
        ];
    }
    respond(200, ['success' => true, 'files' => $catalog]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, ['success' => false, 'message' => 'Utilisez GET ou POST.']);
}

$payload = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($payload)) {
    respond(422, ['success' => false, 'message' => 'Corps JSON invalide.']);
}

$action = trim((string) ($payload['action'] ?? ''));
$surah = (int) ($payload['surah'] ?? 0);
$ayah = (int) ($payload['ayah'] ?? 0);
$surahName = trim((string) ($payload['surah_name'] ?? 'Sourate'));
$surahNameAr = trim((string) ($payload['surah_name_ar'] ?? ''));
$textAr = trim((string) ($payload['text_ar'] ?? ''));
$translation = trim((string) ($payload['translation_fr'] ?? ''));
$reference = trim((string) ($payload['reference'] ?? sprintf('%d:%d', $surah, $ayah)));
$timestamp = gmdate('Ymd-His');
$baseName = sanitizeFilename(sprintf('qvl-s%03d-v%03d-%s', max($surah, 0), max($ayah, 0), $timestamp));
$title = sprintf('%s · %s · %s', $surahName, $surahNameAr, $reference);

$lines = [
    $title,
    '',
    'Texte arabe exact :',
    $textAr,
    '',
    'Traduction française :',
    $translation !== '' ? $translation : 'Traduction non disponible.',
    '',
    'Produit par Quran-Visual-Lab · QVL',
];

if ($action === 'txt') {
    $filename = $baseName . '.txt';
    $target = $exportsDir . '/' . $filename;
    file_put_contents($target, implode(PHP_EOL, $lines));
    respond(200, ['success' => true, 'file_name' => $filename, 'file_url' => '../exports/' . rawurlencode($filename), 'message' => 'Export TXT prêt.']);
}

if ($action === 'docx') {
    $filename = $baseName . '.docx';
    $target = $exportsDir . '/' . $filename;
    if (!buildDocx($target, $title, $lines)) {
        respond(500, ['success' => false, 'message' => 'Export DOCX impossible sur ce serveur.']);
    }
    respond(200, ['success' => true, 'file_name' => $filename, 'file_url' => '../exports/' . rawurlencode($filename), 'message' => 'Export DOCX prêt.']);
}

if ($action === 'print_sheet') {
    $svgMarkup = trim((string) ($payload['svg_markup'] ?? ''));
    $safeTitle = htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeTranslation = nl2br(htmlspecialchars($translation, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
    $safeReference = htmlspecialchars($reference, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $html = '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">'
        . '<title>' . $safeTitle . '</title>'
        . '<style>body{font-family:Inter,Arial,sans-serif;background:#f3eee2;color:#0a1a3a;margin:0;padding:24px}main{max-width:880px;margin:0 auto;background:#fff;border:1px solid #dcc79f;border-radius:18px;padding:24px}h1{margin:0 0 8px}p.meta{color:#5f6d84}section.card{margin-top:18px;padding:18px;border-radius:16px;border:1px solid #eadfca;background:#fffdf7}.arabic{font-family:Amiri,serif;font-size:34px;line-height:2;text-align:right;direction:rtl}.svg-wrap{margin-top:16px;border:1px solid #e8ddc5;border-radius:18px;padding:16px;background:#0a1a3a}.note{margin-top:16px;color:#48607b}</style></head><body><main>'
        . '<h1>' . $safeTitle . '</h1><p class="meta">' . $safeReference . '</p>'
        . '<section class="card"><div class="arabic">' . htmlspecialchars($textAr, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</div><p>' . $safeTranslation . '</p></section>';
    if ($svgMarkup !== '') {
        $html .= '<div class="svg-wrap">' . $svgMarkup . '</div>';
    }
    $html .= '<p class="note">Utilisez l’impression du navigateur pour enregistrer cette page en PDF si la génération directe n’est pas disponible.</p></main></body></html>';
    $filename = $baseName . '.html';
    file_put_contents($exportsDir . '/' . $filename, $html);
    respond(200, ['success' => true, 'file_name' => $filename, 'file_url' => '../exports/' . rawurlencode($filename), 'message' => 'Feuille d’impression prête.']);
}

respond(400, ['success' => false, 'message' => 'Action d’export inconnue.']);
