# Quran-Visual-Lab · Étape 5

Cette étape ajoute le tableau de bord utilisateur et la couche Community / CTM à la base QVL.

## Nouveautés principales

- tableau de bord intégré dans `index.html`
- API `api/dashboard.php` pour le verset du jour, les séries et la synthèse serveur
- `data/community_series.json` pour les collections thématiques
- `data/teacher_space.json` pour l’espace enseignant CTM
- historique local des activités : consultation, prompt, visuel, learning
- statistiques locales : versets consultés, favoris, prompts, visuels, temps d’étude
- bloc Community / CTM avec verset du jour, séries thématiques et ressources enseignant

## Dossier concerné

Déployer le contenu dans :

`/quran-visual-lab/`

## Fichiers clés

- `index.html`
- `assets/css/style.css`
- `assets/js/app.js`
- `api/ayah.php`
- `api/prompt.php`
- `api/visual.php`
- `api/learning.php`
- `api/dashboard.php`
- `data/community_series.json`
- `data/teacher_space.json`

## Flux de test recommandé

1. ouvrir `index.html`
2. consulter un verset
3. générer un prompt puis un visuel
4. préparer le module Learning
5. enregistrer la progression
6. vérifier la mise à jour du dashboard et du bloc CTM

## Conseils de déploiement

- conserver l’encodage UTF-8 sur tous les fichiers
- vérifier que PHP 8 est actif
- laisser les dossiers `cache/progress/` et `cache/visuals/` accessibles en écriture
- garder l’API locale comme source de pilotage du dashboard

## Étape suivante

Étape 6 : comptes utilisateurs, administration avancée, exports DOCX/PDF et publication CTM.


## Étape 6 — nouveautés

- comptes utilisateurs locaux via `api/auth.php`
- console d’administration légère via `admin/index.html` et `api/admin.php`
- exports serveurs via `api/export.php`
- export DOCX natif côté serveur via `ZipArchive`
- export PDF côté navigateur via `html2canvas` + `jsPDF`
- feuille d’impression HTML comme secours PDF
- publications CTM structurées dans `data/publications.json`

## Comptes de démonstration

- admin / QVL-Admin-2026
- demo / QVL-Demo-2026

Pensez à modifier ces comptes après déploiement.
